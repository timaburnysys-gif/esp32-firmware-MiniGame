#pragma once
#include <Arduino.h>
#include "pins.h"

#define SSD1306_BLACK 0
#define SSD1306_WHITE 1
#define SSD1306_SWITCHCAPVCC 0x02
#define SSD1306_DISPLAYOFF 0xAE
#define OLED_BUS_HZ 1000000UL          // if the picture glitches: 400000UL
#define OLED_CONTRAST_NORMAL 207

class Oled : public Print {
public:
  bool begin(uint8_t = 0, uint8_t = 0);
  using Print::write;
  size_t write(uint8_t c) override;

  void clearDisplay() { memset(fb, 0, sizeof(fb)); }
  void display();                       // send the frame (async, second core)
  void flush();                         // wait until the last frame is sent
  uint8_t* getBuffer() { return fb; }   // 128x64, page format (x + (y/8)*128, bit y&7)

  void setContrast(uint8_t v);
  void dim(bool d) { setContrast(d ? 1 : OLED_CONTRAST_NORMAL); }
  void invertDisplay(bool inv);
  void powerOff();
  void powerOn();
  void ssd1306_command(uint8_t c) { if (c == SSD1306_DISPLAYOFF) powerOff(); }

  void drawPixel(int x, int y, uint16_t c);
  void drawFastHLine(int x, int y, int w, uint16_t c);
  void drawFastVLine(int x, int y, int h, uint16_t c) { fillRect(x, y, 1, h, c); }
  void fillRect(int x, int y, int w, int h, uint16_t c);
  void drawRect(int x, int y, int w, int h, uint16_t c);
  void drawLine(int x0, int y0, int x1, int y1, uint16_t c);
  void drawCircle(int x, int y, int r, uint16_t c);
  void fillCircle(int x, int y, int r, uint16_t c);
  void fillRoundRect(int x, int y, int w, int h, int r, uint16_t c);
  void fillTriangle(int x0, int y0, int x1, int y1, int x2, int y2, uint16_t c);

  void setCursor(int x, int y) { cx = x; cy = y; }
  void setTextSize(int s) { tsz = s < 1 ? 1 : s; }
  void setTextColor(uint16_t f) { fg = f; opaque = false; }
  void setTextColor(uint16_t f, uint16_t b) { fg = f; bg = b; opaque = true; }

private:
  uint8_t fb[1024], txb[1024];
  int cx = 0, cy = 0, tsz = 1;
  uint16_t fg = 1, bg = 0;
  bool opaque = false;
  volatile bool busy = false;
  TaskHandle_t th = nullptr;
  static void taskEntry(void* self);
  void pushFrame();
  void glyph(int x, int y, char ch);
};