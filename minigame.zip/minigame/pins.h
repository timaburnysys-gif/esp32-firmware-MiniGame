#ifndef PINS_H
#define PINS_H
#include <Arduino.h>

// ===== OLED SSD1306 (I2C) =====
#define PIN_SDA    20
#define PIN_SCL    21
#define OLED_ADDR  0x3C

// ===== Buttons (pin <-> GND, INPUT_PULLUP) =====
#define PIN_UP     18
#define PIN_DOWN   10
#define PIN_LEFT   15
#define PIN_RIGHT  12
#define PIN_SELECT 2     // strapping pin: do not hold it at power-up
#define PIN_BOOT   0     // on-board BOOT button
#define PIN_BACK   40

// ===== Battery divider (ADC) =====
#define PIN_BAT    4

#define BUTTON_COUNT 7

void pinsInit();

struct Combo { uint8_t a, b; };
struct Ent { float x, y; bool alive; int hp; unsigned long t; };

#endif