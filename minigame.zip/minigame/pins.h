#ifndef PINS_H
#define PINS_H

#include <Arduino.h>

// ===== I2C OLED SSD1306 =====
#define PIN_SDA    20
#define PIN_SCL    21
#define OLED_ADDR  0x3C

// ===== Кнопки (между пином и GND, INPUT_PULLUP) =====
#define PIN_UP     18
#define PIN_DOWN   10
#define PIN_LEFT   15
#define PIN_RIGHT  12
#define PIN_SELECT 2    // strapping-пин: не зажимать при включении
#define PIN_BOOT   0    // штатная кнопка BOOT на плате
#define PIN_BACK   40

#define BUTTON_COUNT 7

// Инициализирует кнопки (INPUT_PULLUP) и шину I2C
void pinsInit();

#endif