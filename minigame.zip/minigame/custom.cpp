#include <Arduino.h>
#include <Preferences.h>
// ===================== DISPLAY: GyverOLED ONLY =====================
// By default this file creates and initialises its own GyverOLED object, so it
// builds and runs even if minigame.ino still uses Adafruit_SSD1306 for its own screens
// (both talk to the same physical SSD1306; every frame is a full-buffer redraw).
// If minigame.ino already owns "GyverOLED<...> oled;", add before this include:
//     #define GYVER_OLED_EXTERNAL
// (the type must then be exactly the same as GYVER_OLED_TYPE below).
#include <Wire.h>
#include <GyverOLED.h>
// If the picture is garbage / shifted and your screen is a 1.3" SH1106 (not SSD1306), add
//     #define BP_SH1106
// before this include.
#ifndef GYVER_OLED_TYPE
#ifdef BP_SH1106
#define GYVER_OLED_TYPE GyverOLED<SSH1106_128x64, OLED_BUFFER>
#else
#define GYVER_OLED_TYPE GyverOLED<SSD1306_128x64, OLED_BUFFER>
#endif
#endif
#ifndef BP_OLED_ADDR
#define BP_OLED_ADDR 0x3C
#endif
#ifndef BP_SDA
#define BP_SDA 20                                                // I2C pins of the console
#define BP_SCL 21
#endif
#ifdef GYVER_OLED_EXTERNAL
extern GYVER_OLED_TYPE oled;
#else
static GYVER_OLED_TYPE oled(BP_OLED_ADDR);
#endif

// Thin adapter: games use Adafruit-style calls (display.fillRect, ...), they are
// translated to GyverOLED here and clipped to 128x64.
struct GyverGfx {
  GYVER_OLED_TYPE& o;
  explicit GyverGfx(GYVER_OLED_TYPE& d) : o(d) {}
  static int imin(int a, int b) { return a < b ? a : b; }
  static int imax(int a, int b) { return a > b ? a : b; }
  static int iabs(int a) { return a < 0 ? -a : a; }

  void clearDisplay() { o.clear(); }
  // GyverOLED needs VERTICAL addressing (0x20,0x01); Adafruit-based screens of minigame.ino need
  // HORIZONTAL (0x20,0x00). Switch around every frame so both can share the panel (no dot garbage).
  static void addrMode(uint8_t m) {
    Wire.beginTransmission(BP_OLED_ADDR);
    Wire.write((uint8_t)0x00); Wire.write((uint8_t)0x20); Wire.write(m);
    Wire.endTransmission();
  }
  void display() { addrMode(0x01); o.update(); addrMode(0x00); }

  // text: color 1 = white, 0 = black (erase), (1,0) = white on opaque black
  uint8_t sc = 1;
  void setTextSize(uint8_t s) { sc = s; o.setScale(s); }
  void setTextColor(uint16_t c) { o.textMode(c ? BUF_ADD : BUF_SUBTRACT); }
  void setTextColor(uint16_t c, uint16_t bg) { o.textMode(c ? (bg ? BUF_ADD : BUF_REPLACE) : BUF_SUBTRACT); }
  void setCursor(int x, int y) {                                // pixels, like Adafruit
    int maxY = 64 - 8 * sc; if (y > maxY) y = maxY;             // GyverOLED drops text that overflows the bottom
    if (y < 0) y = 0;
    o.setCursorXY(x, y);
  }
  template <class T> size_t print(T v) { return o.print(v); }

  void drawPixel(int x, int y, uint16_t c) { o.dot(x, y, c ? 1 : 0); }
  void drawFastHLine(int x, int y, int w, uint16_t c) {
    if (w <= 0 || y < 0 || y > 63) return;
    int x0 = imax(x, 0), x1 = imin(x + w - 1, 127);
    if (x0 <= x1) o.fastLineH(y, x0, x1, c ? 1 : 0);
  }
  void drawFastVLine(int x, int y, int h, uint16_t c) {
    if (h <= 0 || x < 0 || x > 127) return;
    int y0 = imax(y, 0), y1 = imin(y + h - 1, 63);
    if (y0 <= y1) o.fastLineV(x, y0, y1, c ? 1 : 0);
  }
  void fillRect(int x, int y, int w, int h, uint16_t c) {
    if (w <= 0 || h <= 0) return;
    int x0 = imax(x, 0), y0 = imax(y, 0), x1 = imin(x + w - 1, 127), y1 = imin(y + h - 1, 63);
    if (x0 > x1 || y0 > y1) return;
    o.rect(x0, y0, x1, y1, c ? OLED_FILL : OLED_CLEAR);
  }
  void drawRect(int x, int y, int w, int h, uint16_t c) {
    if (w <= 0 || h <= 0) return;
    drawFastHLine(x, y, w, c); if (h > 1) drawFastHLine(x, y + h - 1, w, c);
    drawFastVLine(x, y, h, c); if (w > 1) drawFastVLine(x + w - 1, y, h, c);
  }
  void drawLine(int x0, int y0, int x1, int y1, uint16_t c) {   // Bresenham
    int dx = iabs(x1 - x0), sx = x0 < x1 ? 1 : -1;
    int dy = -iabs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
    for (;;) {
      drawPixel(x0, y0, c);
      if (x0 == x1 && y0 == y1) break;
      int e2 = 2 * err;
      if (e2 >= dy) { err += dy; x0 += sx; }
      if (e2 <= dx) { err += dx; y0 += sy; }
    }
  }
  void drawCircle(int cx, int cy, int r, uint16_t c) {          // midpoint circle
    int x = r, y = 0, err = 1 - r;
    while (x >= y) {
      drawPixel(cx + x, cy + y, c); drawPixel(cx - x, cy + y, c); drawPixel(cx + x, cy - y, c); drawPixel(cx - x, cy - y, c);
      drawPixel(cx + y, cy + x, c); drawPixel(cx - y, cy + x, c); drawPixel(cx + y, cy - x, c); drawPixel(cx - y, cy - x, c);
      y++;
      if (err < 0) err += 2 * y + 1; else { x--; err += 2 * (y - x) + 1; }
    }
  }
  void fillCircle(int cx, int cy, int r, uint16_t c) {
    for (int dy = -r; dy <= r; dy++) {
      int dx = (int)(sqrtf((float)(r * r - dy * dy)) + 0.5f);
      drawFastHLine(cx - dx, cy + dy, 2 * dx + 1, c);
    }
  }
  void fillTriangle(int x0, int y0, int x1, int y1, int x2, int y2, uint16_t c) {   // scanline
    int top = imin(y0, imin(y1, y2)), bot = imax(y0, imax(y1, y2));
    const int ex[3][2] = {{x0, x1}, {x1, x2}, {x2, x0}};
    const int ey[3][2] = {{y0, y1}, {y1, y2}, {y2, y0}};
    for (int y = top; y <= bot; y++) {
      int xl = 10000, xr = -10000;
      for (int e = 0; e < 3; e++) {
        int ax = ex[e][0], bx = ex[e][1], ay = ey[e][0], by = ey[e][1];
        if ((y < ay && y < by) || (y > ay && y > by)) continue;
        if (ay == by) { xl = imin(xl, imin(ax, bx)); xr = imax(xr, imax(ax, bx)); continue; }
        int x = ax + (bx - ax) * (y - ay) / (by - ay);
        xl = imin(xl, x); xr = imax(xr, x);
      }
      if (xl <= xr) drawFastHLine(xl, y, xr - xl + 1, c);
    }
  }
};
static GyverGfx display(oled);

extern bool btnPressed[7];
extern bool isHeld(int idx);
extern bool checkExitToMenu();

#define BTN_UP     0
#define BTN_DOWN   1
#define BTN_LEFT   2
#define BTN_RIGHT  3
#define BTN_SELECT 4
#define BTN_BOOT   5
#define BTN_BACK   6

const char* CUSTOM_GAME_NAME = "Bonus Pack";

// ================= SAVE DATA (NVS, namespace "bonus") =================
enum Sub { S_MENU, S_GD, S_CLK, S_SIM, S_DGE, S_RCT, S_2048, S_STK, S_AST, S_MIN, S_SNK, S_FLP, S_BRK, S_TET, S_PNG, S_INV };
static Sub sub;
static Preferences sv;
static uint32_t gdBest, gdAtt, gdJumps, clkCoins, clkTotal, clkP, clkA;
static uint32_t simBest, dgeBest, rctBest, best48, stkBest, astBest, mnBest;
static uint32_t snkBest, flpBest, brkBest, tetBest, pngWins, invBest;
static bool dirty;
static int cur;
static bool resetArm;

static void loadAll() {
  sv.begin("bonus", false);
  gdBest = sv.getUInt("gdBest", 0);  gdAtt = sv.getUInt("gdAtt", 0);  gdJumps = sv.getUInt("gdJumps", 0);
  clkCoins = sv.getUInt("coins", 0); clkTotal = sv.getUInt("total", 0);
  clkP = sv.getUInt("clkP", 0);      clkA = sv.getUInt("clkA", 0);
  simBest = sv.getUInt("simB", 0);   dgeBest = sv.getUInt("dgeB", 0); rctBest = sv.getUInt("rctB", 0);
  best48 = sv.getUInt("b2048", 0);   stkBest = sv.getUInt("stkB", 0); astBest = sv.getUInt("astB", 0);
  mnBest = sv.getUInt("minB", 0);
  snkBest = sv.getUInt("snkB", 0);   flpBest = sv.getUInt("flpB", 0); brkBest = sv.getUInt("brkB", 0);
  tetBest = sv.getUInt("tetB", 0);   pngWins = sv.getUInt("pngW", 0); invBest = sv.getUInt("invB", 0);
  sv.end(); dirty = false;
}
static void saveAll() {
  sv.begin("bonus", false);
  sv.putUInt("gdBest", gdBest);  sv.putUInt("gdAtt", gdAtt);  sv.putUInt("gdJumps", gdJumps);
  sv.putUInt("coins", clkCoins); sv.putUInt("total", clkTotal);
  sv.putUInt("clkP", clkP);      sv.putUInt("clkA", clkA);
  sv.putUInt("simB", simBest);   sv.putUInt("dgeB", dgeBest); sv.putUInt("rctB", rctBest);
  sv.putUInt("b2048", best48);   sv.putUInt("stkB", stkBest); sv.putUInt("astB", astBest);
  sv.putUInt("minB", mnBest);
  sv.putUInt("snkB", snkBest);   sv.putUInt("flpB", flpBest); sv.putUInt("brkB", brkBest);
  sv.putUInt("tetB", tetBest);   sv.putUInt("pngW", pngWins); sv.putUInt("invB", invBest);
  sv.end(); dirty = false;
}
static void wipeAll() {
  sv.begin("bonus", false); sv.clear(); sv.end();
  gdBest = gdAtt = gdJumps = clkCoins = clkTotal = clkP = clkA = 0;
  simBest = dgeBest = rctBest = best48 = stkBest = astBest = mnBest = 0;
  snkBest = flpBest = brkBest = tetBest = pngWins = invBest = 0; dirty = false;
}
static bool backPressed() { return btnPressed[BTN_BACK] || btnPressed[BTN_BOOT]; }

// ================= SHARED UI HELPERS =================
static void bpText(int cx, int y, const char* t) {                // centered text
  display.setCursor(cx - (int)strlen(t) * 3, y); display.print(t);
}
static void bpIcon(int x, int y, const uint8_t* r, uint16_t c) {   // 8x8 bitmap, MSB = left pixel
  for (int j = 0; j < 8; j++) for (int i = 0; i < 8; i++) if (r[j] & (0x80 >> i)) display.drawPixel(x + i, y + j, c);
}
// Popup: inverted title bar, rounded corners, two lines of text.
static void bpPanel(const char* title, const char* l1, const char* l2) {
  const int x = 10, y = 13, w = 108, h = 38;
  display.fillRect(x - 1, y - 1, w + 2, h + 2, 0);
  display.drawRect(x, y, w, h, 1);
  display.fillRect(x + 1, y + 1, w - 2, 10, 1);
  display.drawPixel(x, y, 0); display.drawPixel(x + w - 1, y, 0);
  display.drawPixel(x, y + h - 1, 0); display.drawPixel(x + w - 1, y + h - 1, 0);
  display.setTextSize(1);
  display.setTextColor(0); bpText(64, y + 2, title);
  display.setTextColor(1);
  if (l1) bpText(64, y + 16, l1);
  if (l2) bpText(64, y + 27, l2);
}
static void bpPanelSB(const char* title, uint32_t score, uint32_t best, const char* hint) {
  char b[24]; snprintf(b, sizeof(b), "%u  best %u", (unsigned)score, (unsigned)best);
  bpPanel(title, b, hint);
}

// ================= GD DASH =================
#define GD_G 54
#define GD_MAX 60
#define GD_LEN 3200
struct GdOb { int16_t x; uint8_t t; };      // 0 spike, 1 double spike, 2 block 8, 3 block 16
static GdOb gdOb[GD_MAX];
static int gdN, gdState;                     // 0 run, 1 dead, 2 win
static float gdX, gdPy, gdVy;
static bool gdOnG;
static unsigned long gdLast, gdT;

static int obW(uint8_t t) { return (t == 1 || t == 3) ? 16 : 8; }
static int obH(uint8_t t) { return t == 3 ? 16 : 8; }
static void gdBuild() {
  uint32_t s = 12345; int x = 170; gdN = 0;
  while (gdN < GD_MAX && x < GD_LEN - 90) {
    s = s * 1103515245u + 12345u; uint8_t r = (s >> 16) & 7;
    uint8_t t = r < 3 ? 0 : r < 5 ? 1 : r < 7 ? 2 : 3;
    gdOb[gdN++] = { (int16_t)x, t };
    s = s * 1103515245u + 12345u; x += obW(t) + 70 + ((s >> 16) % 50);
  }
}
static void gdStart() { gdX = 0; gdPy = GD_G - 8; gdVy = 0; gdOnG = true; gdState = 0; gdAtt++; dirty = true; gdLast = millis(); }
static int gdPct() { int p = (int)(gdX * 100 / GD_LEN); return p > 100 ? 100 : p; }
static void gdDie() { gdState = 1; gdT = millis(); if ((uint32_t)gdPct() > gdBest) gdBest = gdPct(); saveAll(); }

static void gdUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (gdState == 1) { if (millis() - gdT > 500) gdStart(); return; }
  if (gdState == 2) { if (btnPressed[BTN_SELECT]) gdStart(); return; }
  if (millis() - gdLast < 25) return; gdLast = millis();

  if (gdOnG && isHeld(BTN_SELECT)) { gdVy = -5.2f; gdJumps++; dirty = true; }
  gdVy += 0.55f; gdPy += gdVy; gdOnG = false; gdX += 2.2f;
  if (gdPy >= GD_G - 8) { gdPy = GD_G - 8; gdVy = 0; gdOnG = true; }

  for (int i = 0; i < gdN; i++) {                         // landing on blocks
    float sx = gdOb[i].x - gdX; if (sx > 45 || sx < -20 || gdOb[i].t < 2) continue;
    int w = obW(gdOb[i].t), top = GD_G - obH(gdOb[i].t);
    if (31 < sx + w && 37 > sx && gdVy >= 0 && gdPy + 8 >= top && gdPy + 8 - gdVy <= top + 2) { gdPy = top - 8; gdVy = 0; gdOnG = true; }
  }
  for (int i = 0; i < gdN; i++) {                         // deaths
    float sx = gdOb[i].x - gdX; if (sx > 45 || sx < -20) continue;
    int w = obW(gdOb[i].t), h = obH(gdOb[i].t);
    float rx = sx, ry = GD_G - h, rw = w, rh = h;
    if (gdOb[i].t < 2) { rx = sx + 2; ry = GD_G - 6; rw = w - 4; rh = 6; }
    if (31 < rx + rw && 37 > rx && gdPy + 1 < ry + rh && gdPy + 7 > ry) { gdDie(); return; }
  }
  if (gdX >= GD_LEN) { gdState = 2; gdBest = 100; saveAll(); }
}
static void gdDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  display.drawFastHLine(0, GD_G, 128, 1);
  for (int i = 0; i < 9; i++) display.drawPixel(i * 16 - ((int)gdX % 16), GD_G + 3, 1);
  for (int i = 0; i < gdN; i++) {
    int sx = (int)(gdOb[i].x - gdX); if (sx > 128 || sx < -20) continue;
    uint8_t t = gdOb[i].t;
    if (t < 2) { for (int k = 0; k < (t == 1 ? 2 : 1); k++) display.fillTriangle(sx + k * 8, GD_G, sx + k * 8 + 8, GD_G, sx + k * 8 + 4, GD_G - 8, 1); }
    else { int h = obH(t), w = obW(t); display.drawRect(sx, GD_G - h, w, h, 1); display.drawRect(sx + 2, GD_G - h + 2, w - 4, h - 4, 1); }
  }
  display.fillRect(30, (int)gdPy, 8, 8, 1); display.fillRect(34, (int)gdPy + 2, 2, 2, 0);
  if (gdState == 1) { display.drawLine(28, (int)gdPy - 2, 40, (int)gdPy + 10, 1); display.drawLine(40, (int)gdPy - 2, 28, (int)gdPy + 10, 1); }
  display.setCursor(0, 0); display.print(gdPct()); display.print('%');
  display.drawRect(26, 1, 100, 5, 1); display.fillRect(27, 2, gdPct() * 98 / 100, 3, 1);
  display.setCursor(0, 56); display.print(F("Att ")); display.print(gdAtt); display.print(F("  Best ")); display.print(gdBest); display.print('%');
  if (gdState == 2) bpPanel("LEVEL COMPLETE", "100%", "SELECT: again");
  display.display();
}

// ================= CLICKER =================
static unsigned long clkLastAuto, clkLastSave, clkAnim;
static uint32_t costP() { return 15 + clkP * clkP * 8; }
static uint32_t costA() { return 50 + clkA * clkA * 25; }
static void clkUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (btnPressed[BTN_SELECT]) { clkCoins += 1 + clkP; clkTotal += 1 + clkP; clkAnim = millis(); dirty = true; }
  if (btnPressed[BTN_UP] && clkCoins >= costP()) { clkCoins -= costP(); clkP++; dirty = true; }
  if (btnPressed[BTN_DOWN] && clkCoins >= costA()) { clkCoins -= costA(); if (!clkA) clkLastAuto = millis(); clkA++; dirty = true; }
  if (clkA && millis() - clkLastAuto >= 1000) { clkLastAuto += 1000; clkCoins += clkA; clkTotal += clkA; dirty = true; }
  if (dirty && millis() - clkLastSave > 5000) { saveAll(); clkLastSave = millis(); }
}
static void clkDraw() {
  display.clearDisplay(); display.setTextColor(1); display.setTextSize(1);
  display.fillRect(0, 0, 128, 9, 1); display.setTextColor(0);
  char tot[16]; snprintf(tot, sizeof(tot), "total %u", (unsigned)clkTotal);
  display.setCursor(3, 1); display.print(F("CLICKER"));
  display.setCursor(125 - (int)strlen(tot) * 6, 1); display.print(tot);
  display.setTextColor(1);
  int r = (millis() - clkAnim < 120) ? 6 : 4; display.fillCircle(116, 20, r, 1);
  display.setTextSize(2); display.setCursor(2, 12); display.print(clkCoins); display.setTextSize(1);
  display.setCursor(0, 29); display.print('+'); display.print(1 + clkP); display.print(F("/click  auto ")); display.print(clkA); display.print(F("/s"));
  display.setCursor(0, 38); display.print(clkCoins >= costP() ? '*' : ' '); display.print(F("UP click+1 $")); display.print(costP());
  display.setCursor(0, 47); display.print(clkCoins >= costA() ? '*' : ' '); display.print(F("DOWN auto+1 $")); display.print(costA());
  display.setCursor(0, 56); display.print(F("SELECT = click"));
  display.display();
}

// ================= SIMON =================
static uint8_t simSeq[50];
static int simLen, simShow, simIn, simState, simLit;   // state: 0 show, 1 input, 2 fail
static unsigned long simT;
static void simStart() { simLen = 1; simSeq[0] = random(4); simState = 0; simShow = 0; simLit = -1; simT = millis() + 600; }
static void simUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (simState == 2) { if (btnPressed[BTN_SELECT]) simStart(); return; }
  if (simState == 0) {
    if (millis() < simT) return;
    if (simLit == -1) {
      if (simShow < simLen) { simLit = simSeq[simShow]; simT = millis() + 450; }
      else { simState = 1; simIn = 0; }
    } else { simLit = -1; simShow++; simT = millis() + 200; }
    return;
  }
  if (simLit != -1 && millis() > simT) simLit = -1;
  int d = -1;                                           // UP=0 RIGHT=1 DOWN=2 LEFT=3
  if (btnPressed[BTN_UP]) d = 0; else if (btnPressed[BTN_RIGHT]) d = 1;
  else if (btnPressed[BTN_DOWN]) d = 2; else if (btnPressed[BTN_LEFT]) d = 3;
  if (d < 0) return;
  simLit = d; simT = millis() + 150;
  if (d != simSeq[simIn]) { simState = 2; simLit = -1; saveAll(); return; }
  if (++simIn == simLen) {
    if ((uint32_t)simLen > simBest) { simBest = simLen; dirty = true; }
    if (simLen < 50) simSeq[simLen++] = random(4);
    simState = 0; simShow = 0; simLit = -1; simT = millis() + 700;
  }
}
static void simDraw() {
  display.clearDisplay(); display.setTextColor(1); display.setTextSize(1);
  const int px[4] = {46, 84, 46, 20}, py[4] = {10, 22, 42, 22}, pw[4] = {36, 24, 36, 24}, ph[4] = {12, 20, 12, 20};
  for (int i = 0; i < 4; i++) { if (simLit == i) display.fillRect(px[i], py[i], pw[i], ph[i], 1); else display.drawRect(px[i], py[i], pw[i], ph[i], 1); }
  display.setCursor(0, 0); display.print(F("R")); display.print(simLen - (simState == 2 ? 1 : 0));
  display.setCursor(0, 56); display.print(F("Best ")); display.print(simBest);
  display.setCursor(72, 56);
  display.print(simState == 0 ? F("watch...") : simState == 1 ? F("your turn") : F("SEL:retry"));
  display.display();
}

// ================= DODGE =================
struct DgBlk { float x, y, v; bool on; };
static DgBlk dgB[8];
static float dgX;
static int dgTick, dgState;                             // 0 run, 1 dead
static unsigned long dgLast, dgSpawn;
static int dgScore() { return dgTick / 20; }
static void dgStart() { dgX = 59; dgTick = 0; dgState = 0; for (auto& b : dgB) b.on = false; dgLast = dgSpawn = millis(); }
static void dgUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (dgState == 1) { if (btnPressed[BTN_SELECT]) dgStart(); return; }
  if (millis() - dgLast < 25) return; dgLast = millis(); dgTick++;
  if (isHeld(BTN_LEFT))  dgX -= 2.5f;
  if (isHeld(BTN_RIGHT)) dgX += 2.5f;
  if (dgX < 0) dgX = 0;
  if (dgX > 118) dgX = 118;
  int sc = dgScore(); long iv = 700 - sc * 3; if (iv < 220) iv = 220;
  if ((long)(millis() - dgSpawn) > iv) {
    dgSpawn = millis();
    for (auto& b : dgB) if (!b.on) { b.on = true; b.x = random(0, 120); b.y = -8; b.v = 1.3f + sc * 0.02f; if (b.v > 3.6f) b.v = 3.6f; break; }
  }
  for (auto& b : dgB) {
    if (!b.on) continue;
    b.y += b.v; if (b.y > 64) { b.on = false; continue; }
    if (b.x < dgX + 10 && b.x + 8 > dgX && b.y + 8 > 56 && b.y < 62) {
      dgState = 1; if ((uint32_t)sc > dgeBest) dgeBest = sc; saveAll(); return;
    }
  }
}
static void dgDraw() {
  display.clearDisplay(); display.setTextColor(1); display.setTextSize(1);
  for (auto& b : dgB) if (b.on) display.fillRect((int)b.x, (int)b.y, 8, 8, 1);
  display.fillRect((int)dgX, 56, 10, 6, 1);
  display.setCursor(0, 0); display.print(dgScore()); display.print(F("  best ")); display.print(dgeBest);
  if (dgState == 1) bpPanelSB(dgScore() < 10 ? "LOSER!" : "CRASHED!", dgScore(), dgeBest, "SELECT: retry");
  display.display();
}

// ================= REACTION =================
static int rctState;                                    // 0 idle, 1 wait, 2 go, 3 result
static unsigned long rctWait, rctGo, rctMs;
static void rctUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (rctState == 0 || rctState == 3) { if (btnPressed[BTN_SELECT]) { rctState = 1; rctWait = millis() + random(1500, 4000); } return; }
  if (rctState == 1) {
    if (btnPressed[BTN_SELECT]) { rctMs = 0; rctState = 3; }            // false start
    else if (millis() >= rctWait) { rctState = 2; rctGo = millis(); }
    return;
  }
  if (btnPressed[BTN_SELECT]) {
    rctMs = millis() - rctGo; rctState = 3;
    if (rctBest == 0 || rctMs < rctBest) { rctBest = rctMs; saveAll(); }
  }
}
static void rctDraw() {
  display.clearDisplay(); display.setTextSize(1);
  if (rctState == 2) { display.fillRect(0, 0, 128, 64, 1); display.setTextColor(0); display.setTextSize(2); display.setCursor(30, 24); display.print(F("PRESS!")); display.display(); return; }
  display.setTextColor(1);
  display.setCursor(34, 0); display.print(F("REACTION")); display.drawFastHLine(0, 9, 128, 1);
  display.setCursor(4, 18);
  if (rctState == 0) display.print(F("SELECT to start"));
  else if (rctState == 1) display.print(F("Wait for it..."));
  else if (rctMs == 0) display.print(F("Too early!"));
  else { display.setTextSize(2); display.print(rctMs); display.print(F(" ms")); display.setTextSize(1); }
  display.setCursor(4, 44); display.print(F("Best: ")); if (rctBest) { display.print(rctBest); display.print(F(" ms")); } else display.print(F("--"));
  display.setCursor(4, 56); display.print(F("BACK: menu"));
  display.display();
}

// ================= 2048 =================
static uint32_t t48[4][4];
static uint32_t sc48;
static bool over48, won48;
static void t48Add() {
  int er[16], ec[16], n = 0;
  for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) if (!t48[r][c]) { er[n] = r; ec[n] = c; n++; }
  if (!n) return;
  int k = random(n); t48[er[k]][ec[k]] = random(10) == 0 ? 4 : 2;
}
static bool t48Can() {
  for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
    if (!t48[r][c]) return true;
    if (c < 3 && t48[r][c] == t48[r][c + 1]) return true;
    if (r < 3 && t48[r][c] == t48[r + 1][c]) return true;
  }
  return false;
}
static bool t48Move(int dir) {                          // 0 up, 1 down, 2 left, 3 right
  bool moved = false;
  for (int i = 0; i < 4; i++) {
    uint32_t a[4]; int pr[4], pc[4];
    for (int k = 0; k < 4; k++) {
      int r, c;
      if (dir == 2) { r = i; c = k; } else if (dir == 3) { r = i; c = 3 - k; }
      else if (dir == 0) { r = k; c = i; } else { r = 3 - k; c = i; }
      pr[k] = r; pc[k] = c; a[k] = t48[r][c];
    }
    uint32_t o[4] = {0, 0, 0, 0}; int n = 0; bool mergedLast = false;
    for (int k = 0; k < 4; k++) {
      if (!a[k]) continue;
      if (n > 0 && o[n - 1] == a[k] && !mergedLast) { o[n - 1] *= 2; sc48 += o[n - 1]; if (o[n - 1] == 2048) won48 = true; mergedLast = true; }
      else { o[n++] = a[k]; mergedLast = false; }
    }
    for (int k = 0; k < 4; k++) { if (t48[pr[k]][pc[k]] != o[k]) moved = true; t48[pr[k]][pc[k]] = o[k]; }
  }
  return moved;
}
static void t48Start() { memset(t48, 0, sizeof(t48)); sc48 = 0; over48 = won48 = false; t48Add(); t48Add(); }
static void t48Update() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (over48) { if (btnPressed[BTN_SELECT]) t48Start(); return; }
  int d = -1;
  if (btnPressed[BTN_UP]) d = 0; else if (btnPressed[BTN_DOWN]) d = 1;
  else if (btnPressed[BTN_LEFT]) d = 2; else if (btnPressed[BTN_RIGHT]) d = 3;
  if (d < 0) return;
  if (t48Move(d)) {
    t48Add();
    if (sc48 > best48) { best48 = sc48; dirty = true; }
    if (!t48Can()) { over48 = true; saveAll(); }
  }
}
static void t48Draw() {
  display.clearDisplay(); display.setTextSize(1);
  for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
    int x = 2 + c * 24, y = 2 + r * 15; uint32_t v = t48[r][c];
    if (!v) { display.drawPixel(x + 11, y + 7, 1); continue; }
    bool inv = v >= 128;
    if (inv) display.fillRect(x, y, 24, 15, 1); else display.drawRect(x, y, 24, 15, 1);
    char b[8]; snprintf(b, 8, "%u", (unsigned)v); int w = strlen(b) * 6;
    display.setTextColor(inv ? 0 : 1, inv ? 1 : 0);
    display.setCursor(x + (24 - w) / 2, y + 4); display.print(b);
  }
  display.setTextColor(1);
  display.setCursor(99, 2);  display.print(F("Sc"));
  display.setCursor(99, 11); display.print(sc48);
  display.setCursor(99, 26); display.print(F("Best"));
  display.setCursor(99, 35); display.print(best48);
  if (won48) { display.setCursor(99, 52); display.print(F("2048!")); }
  if (over48) bpPanelSB("NO MOVES", sc48, best48, "SELECT: new");
  display.display();
}

// ================= STACK =================
#define STK_MAX 120
static int16_t stkX[STK_MAX], stkW[STK_MAX];
static int stkN, stkState, stkStreak;                   // state: 0 run, 1 over
static uint32_t stkScore;
static float stkCx, stkCw, stkDir;
static unsigned long stkLast;
static void stkStart() {
  stkN = 1; stkX[0] = 44; stkW[0] = 40; stkCw = 40; stkCx = 0; stkDir = 1;
  stkState = 0; stkStreak = 0; stkScore = 0; stkLast = millis();
}
static void stkUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (stkState) { if (btnPressed[BTN_SELECT]) stkStart(); return; }
  if (millis() - stkLast >= 20) {
    stkLast = millis();
    float v = 1.2f + stkScore * 0.07f; if (v > 3.6f) v = 3.6f;
    stkCx += stkDir * v;
    if (stkCx < 0) { stkCx = 0; stkDir = 1; }
    if (stkCx + stkCw > 128) { stkCx = 128 - stkCw; stkDir = -1; }
  }
  if (!btnPressed[BTN_SELECT]) return;
  int px = stkX[stkN - 1], pw = stkW[stkN - 1], x = (int)stkCx, w = (int)stkCw;
  int l = max(x, px), r = min(x + w, px + pw), ov = r - l;
  if (ov <= 0) { stkState = 1; if (stkScore > stkBest) stkBest = stkScore; saveAll(); return; }
  if (abs(x - px) <= 1) {                               // perfect drop
    l = px; ov = pw; stkStreak++;
    if (stkStreak >= 3 && ov < 56) { l -= 1; ov += 2; }
  } else stkStreak = 0;
  stkX[stkN] = l; stkW[stkN] = ov; stkN++; stkScore++;
  stkCw = ov; stkCx = stkDir > 0 ? 0 : 128 - ov;
  if (stkScore > stkBest) { stkBest = stkScore; dirty = true; }
  if (stkN >= STK_MAX) {                                // keep going: drop the oldest 20 levels
    memmove(stkX, stkX + 20, (STK_MAX - 20) * sizeof(int16_t));
    memmove(stkW, stkW + 20, (STK_MAX - 20) * sizeof(int16_t));
    stkN -= 20;
  }
}
static void stkDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  int base = stkN > 10 ? stkN - 10 : 0;
  for (int i = base; i < stkN; i++) display.fillRect(stkX[i], 58 - (i - base) * 4, stkW[i], 3, 1);
  if (stkState == 0) display.drawRect((int)stkCx, 58 - (stkN - base) * 4, (int)stkCw, 3, 1);
  display.setCursor(0, 0); display.print(stkScore);
  display.setCursor(70, 0); display.print(F("best ")); display.print(stkBest);
  if (stkStreak >= 3 && stkState == 0) { display.setCursor(0, 10); display.print(F("PERFECT x")); display.print(stkStreak); }
  if (stkState == 1) bpPanelSB("TOWER FELL", stkScore, stkBest, "SELECT: retry");
  display.display();
}

// ================= ASTEROIDS =================
struct AstR { float x, y, vx, vy; uint8_t r; bool on; };
struct AstB { float x, y, vx, vy; uint8_t life; bool on; };
static AstR ar[14];
static AstB ab[4];
static float asx, asy, asvx, asvy, asa;
static int asLives, asWave, asState;                    // state: 0 run, 1 over
static uint32_t asScore;
static unsigned long asInv, asShot, asLast;
static float frand(float a, float b) { return a + (b - a) * (random(1000) / 1000.0f); }
static void asSpawnWave() {
  for (auto& a : ar) a.on = false;
  int n = 3 + asWave; if (n > 7) n = 7;
  for (int i = 0; i < n; i++) {
    float x, y;
    do { x = random(128); y = random(64); } while ((x - asx) * (x - asx) + (y - asy) * (y - asy) < 900);
    float ang = frand(0, 6.283f), sp = frand(0.3f, 0.8f) + asWave * 0.05f;
    ar[i].x = x; ar[i].y = y; ar[i].vx = cosf(ang) * sp; ar[i].vy = sinf(ang) * sp; ar[i].r = 8; ar[i].on = true;
  }
}
static void asStart() {
  asx = 64; asy = 32; asvx = asvy = 0; asa = -1.57f; asLives = 3; asWave = 1; asScore = 0; asState = 0;
  for (auto& b : ab) b.on = false;
  asSpawnWave(); asInv = millis() + 2000; asShot = 0; asLast = millis();
}
static void asSplit(AstR p, int nr) {   // by value: slot of the parent may be reused
  for (int k = 0; k < 2; k++) {
    for (auto& a : ar) if (!a.on) {
      float ang = frand(0, 6.283f), sp = frand(0.5f, 1.2f);
      a.x = p.x; a.y = p.y; a.vx = p.vx * 0.5f + cosf(ang) * sp; a.vy = p.vy * 0.5f + sinf(ang) * sp; a.r = nr; a.on = true; break;
    }
  }
}
static void asUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (asState) { if (btnPressed[BTN_SELECT]) asStart(); return; }
  if (millis() - asLast < 30) return; asLast = millis();
  if (isHeld(BTN_LEFT))  asa -= 0.18f;
  if (isHeld(BTN_RIGHT)) asa += 0.18f;
  if (isHeld(BTN_UP)) {
    asvx += cosf(asa) * 0.14f; asvy += sinf(asa) * 0.14f;
    float sp = sqrtf(asvx * asvx + asvy * asvy); if (sp > 2.4f) { asvx *= 2.4f / sp; asvy *= 2.4f / sp; }
  }
  asvx *= 0.985f; asvy *= 0.985f; asx += asvx; asy += asvy;
  if (asx < 0) asx += 128; if (asx >= 128) asx -= 128; if (asy < 0) asy += 64; if (asy >= 64) asy -= 64;
  if (isHeld(BTN_SELECT) && millis() - asShot > 220) {
    asShot = millis();
    for (auto& b : ab) if (!b.on) { b.on = true; b.x = asx + cosf(asa) * 5; b.y = asy + sinf(asa) * 5; b.vx = cosf(asa) * 3.5f + asvx; b.vy = sinf(asa) * 3.5f + asvy; b.life = 30; break; }
  }
  for (auto& a : ar) {
    if (!a.on) continue;
    a.x += a.vx; a.y += a.vy;
    if (a.x < 0) a.x += 128; if (a.x >= 128) a.x -= 128; if (a.y < 0) a.y += 64; if (a.y >= 64) a.y -= 64;
  }
  for (auto& b : ab) {
    if (!b.on) continue;
    b.x += b.vx; b.y += b.vy;
    if (b.x < 0) b.x += 128; if (b.x >= 128) b.x -= 128; if (b.y < 0) b.y += 64; if (b.y >= 64) b.y -= 64;
    if (--b.life == 0) { b.on = false; continue; }
    for (auto& a : ar) {
      if (!a.on) continue;
      float dx = a.x - b.x, dy = a.y - b.y;
      if (dx * dx + dy * dy < (a.r + 1) * (a.r + 1)) {
        b.on = false; a.on = false;
        asScore += a.r == 8 ? 20 : a.r == 5 ? 50 : 100;
        if (a.r > 3) asSplit(a, a.r == 8 ? 5 : 3);
        break;
      }
    }
  }
  if (millis() > asInv) {
    for (auto& a : ar) {
      if (!a.on) continue;
      float dx = a.x - asx, dy = a.y - asy;
      if (dx * dx + dy * dy < (a.r + 2) * (a.r + 2)) {
        asLives--; asx = 64; asy = 32; asvx = asvy = 0; asInv = millis() + 2000;
        if (asLives <= 0) { asState = 1; if (asScore > astBest) astBest = asScore; saveAll(); }
        break;
      }
    }
  }
  bool any = false; for (auto& a : ar) if (a.on) any = true;
  if (!any && asState == 0) { asWave++; asSpawnWave(); asInv = millis() + 1500; }
}
static void asDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  for (auto& a : ar) if (a.on) display.drawCircle((int)a.x, (int)a.y, a.r, 1);
  for (auto& b : ab) if (b.on) { display.drawPixel((int)b.x, (int)b.y, 1); display.drawPixel((int)b.x + 1, (int)b.y, 1); }
  if (asState == 0 && (millis() > asInv || ((millis() / 100) & 1))) {
    int nx = asx + cosf(asa) * 5, ny = asy + sinf(asa) * 5;
    int lx = asx + cosf(asa + 2.5f) * 4, ly = asy + sinf(asa + 2.5f) * 4;
    int rx = asx + cosf(asa - 2.5f) * 4, ry = asy + sinf(asa - 2.5f) * 4;
    display.drawLine(nx, ny, lx, ly, 1); display.drawLine(nx, ny, rx, ry, 1); display.drawLine(lx, ly, rx, ry, 1);
  }
  display.setCursor(0, 0); display.print(asScore);
  display.setCursor(56, 0); display.print('W'); display.print(asWave);
  for (int i = 0; i < asLives; i++) display.fillTriangle(100 + i * 9, 6, 96 + i * 9, 0, 104 + i * 9, 0, 1);
  if (asState == 1) bpPanelSB("GAME OVER", asScore, astBest, "SELECT: retry");
  display.display();
}

// ================= MINESWEEPER (hold SELECT = flag) =================
#define MN_W 16
#define MN_H 7
#define MN_M 14
static uint8_t mnMine[MN_H][MN_W], mnRev[MN_H][MN_W], mnFlag[MN_H][MN_W], mnAdj[MN_H][MN_W];
static int mnCx, mnCy, mnLeft, mnState, mnFlags;        // state: 0 ready, 1 playing, 2 lost, 3 won
static unsigned long mnT0, mnDown;
static bool mnHeldSel, mnLong;
static uint32_t mnTime;
static void mnStart() {
  memset(mnMine, 0, sizeof(mnMine)); memset(mnRev, 0, sizeof(mnRev)); memset(mnFlag, 0, sizeof(mnFlag)); memset(mnAdj, 0, sizeof(mnAdj));
  mnCx = 8; mnCy = 3; mnState = 0; mnFlags = 0; mnLeft = MN_W * MN_H - MN_M; mnHeldSel = false; mnLong = false; mnTime = 0;
}
static void mnPlace(int sr, int sc) {
  int placed = 0;
  while (placed < MN_M) {
    int r = random(MN_H), c = random(MN_W);
    if (mnMine[r][c] || (abs(r - sr) <= 1 && abs(c - sc) <= 1)) continue;
    mnMine[r][c] = 1; placed++;
  }
  for (int r = 0; r < MN_H; r++) for (int c = 0; c < MN_W; c++) {
    int n = 0;
    for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
      int nr = r + dr, nc = c + dc;
      if ((dr || dc) && nr >= 0 && nr < MN_H && nc >= 0 && nc < MN_W && mnMine[nr][nc]) n++;
    }
    mnAdj[r][c] = n;
  }
  mnT0 = millis(); mnState = 1;
}
static void mnReveal(int r, int c) {
  if (mnRev[r][c] || mnFlag[r][c]) return;
  int st[MN_W * MN_H][2], sp = 0;
  mnRev[r][c] = 1; st[sp][0] = r; st[sp][1] = c; sp++;
  while (sp) {
    sp--; int rr = st[sp][0], cc = st[sp][1];
    if (mnMine[rr][cc]) { mnState = 2; continue; }
    mnLeft--;
    if (mnAdj[rr][cc] == 0) {
      for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
        int nr = rr + dr, nc = cc + dc;
        if (nr < 0 || nr >= MN_H || nc < 0 || nc >= MN_W || mnRev[nr][nc] || mnFlag[nr][nc]) continue;
        mnRev[nr][nc] = 1; st[sp][0] = nr; st[sp][1] = nc; sp++;
      }
    }
  }
  if (mnState == 1 && mnLeft == 0) {
    mnState = 3; mnTime = (millis() - mnT0) / 1000;
    if (mnBest == 0 || mnTime < mnBest) mnBest = mnTime;
    saveAll();
  }
}
static void mnToggleFlag() {
  if (mnRev[mnCy][mnCx]) return;
  if (mnFlag[mnCy][mnCx]) { mnFlag[mnCy][mnCx] = 0; mnFlags--; } else { mnFlag[mnCy][mnCx] = 1; mnFlags++; }
}
static void mnUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (mnState >= 2) { if (btnPressed[BTN_SELECT]) mnStart(); return; }
  if (btnPressed[BTN_UP] && mnCy > 0) mnCy--;
  if (btnPressed[BTN_DOWN] && mnCy < MN_H - 1) mnCy++;
  if (btnPressed[BTN_LEFT] && mnCx > 0) mnCx--;
  if (btnPressed[BTN_RIGHT] && mnCx < MN_W - 1) mnCx++;
  if (btnPressed[BTN_SELECT]) { mnDown = millis(); mnHeldSel = true; mnLong = false; }
  if (mnHeldSel) {
    if (isHeld(BTN_SELECT)) {
      if (!mnLong && millis() - mnDown > 350) { mnLong = true; mnToggleFlag(); }
    } else {
      mnHeldSel = false;
      if (!mnLong) { if (mnState == 0) mnPlace(mnCy, mnCx); mnReveal(mnCy, mnCx); }
    }
  }
}
static void mnDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  display.setCursor(0, 0);
  if (mnState == 2) display.print(F("BOOM!  SELECT=retry"));
  else if (mnState == 3) { display.print(F("CLEARED ")); display.print(mnTime); display.print(F("s best ")); display.print(mnBest); }
  else {
    display.print(F("M:")); display.print(MN_M - mnFlags);
    display.print(F(" T:")); display.print(mnState == 1 ? (millis() - mnT0) / 1000 : 0);
    display.print(F(" B:")); if (mnBest) display.print(mnBest); else display.print('-');
  }
  for (int r = 0; r < MN_H; r++) for (int c = 0; c < MN_W; c++) {
    int x = c * 8, y = 8 + r * 8;
    if (!mnRev[r][c]) {
      if (mnState == 2 && mnMine[r][c]) { display.fillCircle(x + 3, y + 3, 2, 1); display.drawPixel(x + 3, y + 3, 0); }
      else {
        display.fillRect(x, y, 7, 7, 1);
        if (mnFlag[r][c]) { display.fillTriangle(x + 2, y + 1, x + 5, y + 3, x + 2, y + 5, 0); display.drawLine(x + 2, y + 1, x + 2, y + 6, 0); }
      }
    } else if (mnAdj[r][c]) { display.setCursor(x + 1, y); display.print((int)mnAdj[r][c]); }
  }
  if (mnState < 2) {
    int x = mnCx * 8, y = 8 + mnCy * 8;
    if (!mnRev[mnCy][mnCx]) display.fillRect(x + 2, y + 2, 3, 3, 0); else display.drawRect(x, y, 7, 7, 1);
  }
  display.display();
}

// ================= SNAKE (arrows, walls kill) =================
#define SN_W 32
#define SN_H 14
static uint8_t snkX[SN_W * SN_H], snkY[SN_W * SN_H];
static int snkLen, snkDir, snkNext, snkState, snkFx, snkFy;   // dir: 0 up 1 right 2 down 3 left; state: 0 run, 1 dead
static uint32_t snkScore;
static unsigned long snkLast;
static void snkFood() {
  for (int t = 0; t < 300; t++) {
    int x = random(SN_W), y = random(SN_H); bool ok = true;
    for (int i = 0; i < snkLen; i++) if (snkX[i] == x && snkY[i] == y) { ok = false; break; }
    if (ok) { snkFx = x; snkFy = y; return; }
  }
}
static void snkStart() {
  snkLen = 3; snkDir = snkNext = 1; snkState = 0; snkScore = 0;
  for (int i = 0; i < 3; i++) { snkX[i] = 16 - i; snkY[i] = 7; }
  snkFood(); snkLast = millis();
}
static void snkUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (snkState) { if (btnPressed[BTN_SELECT]) snkStart(); return; }
  int d = -1;
  if (btnPressed[BTN_UP]) d = 0; else if (btnPressed[BTN_RIGHT]) d = 1;
  else if (btnPressed[BTN_DOWN]) d = 2; else if (btnPressed[BTN_LEFT]) d = 3;
  if (d >= 0 && d != (snkDir + 2) % 4) snkNext = d;
  long iv = 150 - (long)snkScore * 3; if (iv < 60) iv = 60;
  if (millis() - snkLast < (unsigned long)iv) return;
  snkLast = millis(); snkDir = snkNext;
  int nx = snkX[0], ny = snkY[0];
  if (snkDir == 0) ny--; else if (snkDir == 1) nx++; else if (snkDir == 2) ny++; else nx--;
  bool eat = (nx == snkFx && ny == snkFy);
  bool hit = nx < 0 || nx >= SN_W || ny < 0 || ny >= SN_H;
  int chk = eat ? snkLen : snkLen - 1;
  for (int i = 0; i < chk && !hit; i++) if (snkX[i] == nx && snkY[i] == ny) hit = true;
  if (hit) { snkState = 1; saveAll(); return; }
  if (eat && snkLen < SN_W * SN_H - 1) snkLen++;
  memmove(snkX + 1, snkX, snkLen - 1); memmove(snkY + 1, snkY, snkLen - 1);
  snkX[0] = nx; snkY[0] = ny;
  if (eat) { snkScore++; if (snkScore > snkBest) { snkBest = snkScore; dirty = true; } snkFood(); }
}
static void snkDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  display.setCursor(0, 0); display.print(snkScore);
  display.setCursor(70, 0); display.print(F("best ")); display.print(snkBest);
  display.drawFastHLine(0, 7, 128, 1);
  for (int i = 0; i < snkLen; i++) display.fillRect(snkX[i] * 4, 8 + snkY[i] * 4, 3, 3, 1);
  display.drawRect(snkFx * 4, 8 + snkFy * 4, 3, 3, 1);
  if (snkState) bpPanelSB("GAME OVER", snkScore, snkBest, "SELECT: retry");
  display.display();
}

// ================= FLAPPY (SELECT = flap) =================
#define FP_GAP 24
#define FP_W 12
struct FpPipe { float x; int gy; bool sc; };
static FpPipe fpp[3];
static float flpY, flpV;
static int flpState;                                    // 0 ready, 1 run, 2 dead
static uint32_t flpScore;
static unsigned long flpLast;
static void flpStart() {
  flpY = 28; flpV = 0; flpState = 0; flpScore = 0; flpLast = millis();
  for (int i = 0; i < 3; i++) { fpp[i].x = 128 + i * 56; fpp[i].gy = random(8, 33); fpp[i].sc = false; }
}
static void flpUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (flpState == 2) { if (btnPressed[BTN_SELECT]) flpStart(); return; }
  if (btnPressed[BTN_SELECT]) { flpV = -2.4f; if (flpState == 0) { flpState = 1; flpLast = millis(); } }
  if (flpState == 0) return;
  if (millis() - flpLast < 25) return; flpLast = millis();
  flpV += 0.22f; flpY += flpV;
  for (auto& p : fpp) {
    p.x -= 1.7f;
    if (p.x < -FP_W) { p.x += 168; p.gy = random(8, 33); p.sc = false; }
    if (!p.sc && p.x + FP_W < 30) { p.sc = true; flpScore++; if (flpScore > flpBest) { flpBest = flpScore; dirty = true; } }
    if (38 > p.x && 30 < p.x + FP_W && (flpY < p.gy || flpY + 7 > p.gy + FP_GAP)) flpState = 2;
  }
  if (flpY < 0 || flpY + 7 > 63) flpState = 2;
  if (flpState == 2) saveAll();
}
static void flpDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  for (auto& p : fpp) {
    int x = (int)p.x; if (x > 128 || x < -FP_W - 2) continue;
    display.fillRect(x, 0, FP_W, p.gy, 1);
    display.fillRect(x, p.gy + FP_GAP, FP_W, 64 - p.gy - FP_GAP, 1);
    display.fillRect(x - 1, p.gy - 3, FP_W + 2, 3, 1);
    display.fillRect(x - 1, p.gy + FP_GAP, FP_W + 2, 3, 1);
  }
  display.fillCircle(34, (int)flpY + 4, 5, 0);
  display.fillCircle(34, (int)flpY + 4, 4, 1);
  display.fillRect(36, (int)flpY + 2, 2, 2, 0);
  display.setTextColor(1, 0);
  display.setCursor(0, 0); display.print(flpScore);
  if (flpState == 0) { display.setCursor(30, 56); display.print(F("SELECT: flap")); }
  if (flpState == 2) bpPanelSB("SPLAT!", flpScore, flpBest, "SELECT: retry");
  display.display();
}

// ================= BREAKOUT (LEFT/RIGHT, SELECT = launch) =================
#define BK_R 4
#define BK_C 10
#define BK_PW 22
static uint8_t brkB[BK_R][BK_C];
static float brkX, brkY, brkVx, brkVy, brkP;
static int brkLives, brkState, brkLeft, brkLevel;       // state: 0 ready, 1 run, 2 over
static uint32_t brkScore;
static unsigned long brkLast;
static float brkSpd() { float s = 1.6f + brkLevel * 0.2f; return s > 3.0f ? 3.0f : s; }
static void brkBricks() { for (int r = 0; r < BK_R; r++) for (int c = 0; c < BK_C; c++) brkB[r][c] = 1; brkLeft = BK_R * BK_C; }
static void brkReady() { brkState = 0; brkP = 53; brkX = brkP + BK_PW / 2; brkY = 57; }
static void brkStart() { brkLives = 3; brkScore = 0; brkLevel = 1; brkBricks(); brkReady(); brkLast = millis(); }
static void brkUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (brkState == 2) { if (btnPressed[BTN_SELECT]) brkStart(); return; }
  if (brkState == 0 && btnPressed[BTN_SELECT]) { brkState = 1; brkVy = -brkSpd(); brkVx = (random(2) ? 1 : -1) * brkSpd() * 0.5f; }
  if (millis() - brkLast < 20) return; brkLast = millis();
  if (isHeld(BTN_LEFT))  brkP -= 3;
  if (isHeld(BTN_RIGHT)) brkP += 3;
  if (brkP < 0) brkP = 0;
  if (brkP > 128 - BK_PW) brkP = 128 - BK_PW;
  if (brkState == 0) { brkX = brkP + BK_PW / 2; brkY = 57; return; }
  brkX += brkVx; brkY += brkVy;
  if (brkX < 0) { brkX = 0; brkVx = fabsf(brkVx); }
  if (brkX > 126) { brkX = 126; brkVx = -fabsf(brkVx); }
  if (brkY < 9) { brkY = 9; brkVy = fabsf(brkVy); }
  if (brkX >= 4 && brkY >= 10) {
    int c = (int)((brkX - 4) / 12), r = (int)((brkY - 10) / 5);
    if (r < BK_R && c < BK_C && brkB[r][c]) {
      brkB[r][c] = 0; brkVy = -brkVy; brkScore += 10; brkLeft--;
      if (brkScore > brkBest) { brkBest = brkScore; dirty = true; }
      if (brkLeft == 0) { brkLevel++; brkBricks(); brkReady(); return; }
    }
  }
  if (brkVy > 0 && brkY >= 58 && brkY <= 63 && brkX >= brkP - 1 && brkX <= brkP + BK_PW + 1) {
    float h = (brkX - (brkP + BK_PW / 2)) / (BK_PW / 2.0f), s = brkSpd();
    brkVx = h * s * 1.1f; brkVy = -s; brkY = 57;
  }
  if (brkY > 64) {
    brkLives--;
    if (brkLives <= 0) { brkState = 2; saveAll(); }
    else brkReady();
  }
}
static void brkDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  display.setCursor(0, 0); display.print(brkScore);
  display.setCursor(50, 0); display.print('L'); display.print(brkLevel);
  for (int i = 0; i < brkLives; i++) display.fillCircle(104 + i * 8, 3, 2, 1);
  for (int r = 0; r < BK_R; r++) for (int c = 0; c < BK_C; c++)
    if (brkB[r][c]) display.fillRect(4 + c * 12, 10 + r * 5, 11, 4, 1);
  display.fillRect((int)brkP, 60, BK_PW, 3, 1);
  display.fillRect((int)brkX, (int)brkY, 2, 2, 1);
  if (brkState == 0) { display.setCursor(24, 40); display.print(F("SELECT: launch")); }
  if (brkState == 2) bpPanelSB("GAME OVER", brkScore, brkBest, "SELECT: retry");
  display.display();
}

// ================= TETRIS (UP rotate, DOWN soft drop, SELECT hard drop) =================
static const uint16_t TET[7][4] = {
  {0x0F00, 0x2222, 0x00F0, 0x4444},   // I
  {0x44C0, 0x8E00, 0x6440, 0x0E20},   // J
  {0x4460, 0x0E80, 0xC440, 0x2E00},   // L
  {0xCC00, 0xCC00, 0xCC00, 0xCC00},   // O
  {0x06C0, 0x8C40, 0x6C00, 0x4620},   // S
  {0x0E40, 0x4C40, 0x4E00, 0x4640},   // T
  {0x0C60, 0x4C80, 0xC600, 0x2640}    // Z
};
static uint8_t tetBoard[16][10];
static int tetP, tetR, tetN, tetPx, tetPy, tetState, tetLines;   // state: 0 run, 1 over
static uint32_t tetScore;
static unsigned long tetFall, tetRep;
static bool tetCan(int p, int r, int px, int py) {
  uint16_t m = TET[p][r];
  for (int i = 0; i < 16; i++) if (m & (0x8000 >> i)) {
    int x = px + (i & 3), y = py + (i >> 2);
    if (x < 0 || x >= 10 || y >= 16) return false;
    if (y >= 0 && tetBoard[y][x]) return false;
  }
  return true;
}
static void tetSpawn() {
  tetP = tetN; tetN = random(7); tetR = 0; tetPx = 3; tetPy = 0; tetFall = millis();
  if (!tetCan(tetP, tetR, tetPx, tetPy)) { tetState = 1; saveAll(); }
}
static void tetStart() {
  memset(tetBoard, 0, sizeof(tetBoard)); tetScore = 0; tetLines = 0; tetState = 0; tetRep = 0;
  tetN = random(7); tetSpawn();
}
static void tetLock() {
  uint16_t m = TET[tetP][tetR];
  for (int i = 0; i < 16; i++) if (m & (0x8000 >> i)) {
    int x = tetPx + (i & 3), y = tetPy + (i >> 2);
    if (y >= 0 && y < 16 && x >= 0 && x < 10) tetBoard[y][x] = 1;
  }
  int n = 0;
  for (int y = 15; y >= 0; y--) {
    bool full = true;
    for (int x = 0; x < 10; x++) if (!tetBoard[y][x]) { full = false; break; }
    if (full) {
      n++;
      for (int yy = y; yy > 0; yy--) memcpy(tetBoard[yy], tetBoard[yy - 1], 10);
      memset(tetBoard[0], 0, 10); y++;
    }
  }
  static const uint16_t pts[5] = {0, 100, 300, 500, 800};
  tetLines += n; tetScore += pts[n] * (1 + tetLines / 10);
  if (tetScore > tetBest) { tetBest = tetScore; dirty = true; }
  tetSpawn();
}
static void tetUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (tetState) { if (btnPressed[BTN_SELECT]) tetStart(); return; }
  int dx = 0;
  if (btnPressed[BTN_LEFT])       { dx = -1; tetRep = millis() + 180; }
  else if (btnPressed[BTN_RIGHT]) { dx = 1;  tetRep = millis() + 180; }
  else if (millis() > tetRep) {
    if (isHeld(BTN_LEFT))       { dx = -1; tetRep = millis() + 70; }
    else if (isHeld(BTN_RIGHT)) { dx = 1;  tetRep = millis() + 70; }
  }
  if (dx && tetCan(tetP, tetR, tetPx + dx, tetPy)) tetPx += dx;
  if (btnPressed[BTN_UP]) {
    int nr = (tetR + 1) & 3;
    if (tetCan(tetP, nr, tetPx, tetPy)) tetR = nr;
    else if (tetCan(tetP, nr, tetPx - 1, tetPy)) { tetR = nr; tetPx--; }
    else if (tetCan(tetP, nr, tetPx + 1, tetPy)) { tetR = nr; tetPx++; }
  }
  if (btnPressed[BTN_SELECT]) { while (tetCan(tetP, tetR, tetPx, tetPy + 1)) tetPy++; tetLock(); return; }
  long iv = 600 - 45L * (tetLines / 10); if (iv < 80) iv = 80;
  if (isHeld(BTN_DOWN) && iv > 50) iv = 50;
  if (millis() - tetFall >= (unsigned long)iv) {
    tetFall = millis();
    if (tetCan(tetP, tetR, tetPx, tetPy + 1)) tetPy++; else tetLock();
  }
}
static void tetDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  display.drawFastVLine(43, 0, 64, 1); display.drawFastVLine(84, 0, 64, 1);
  for (int y = 0; y < 16; y++) for (int x = 0; x < 10; x++)
    if (tetBoard[y][x]) display.fillRect(44 + x * 4, y * 4, 3, 3, 1);
  if (!tetState) {
    uint16_t m = TET[tetP][tetR];
    for (int i = 0; i < 16; i++) if (m & (0x8000 >> i)) {
      int y = tetPy + (i >> 2); if (y < 0) continue;
      display.fillRect(44 + (tetPx + (i & 3)) * 4, y * 4, 3, 3, 1);
    }
  }
  display.setCursor(0, 0);  display.print(F("Score"));
  display.setCursor(0, 9);  display.print(tetScore);
  display.setCursor(0, 22); display.print(F("Lines"));
  display.setCursor(0, 31); display.print(tetLines);
  display.setCursor(0, 46); display.print(F("Best"));
  display.setCursor(0, 55); display.print(tetBest);
  display.setCursor(90, 0); display.print(F("Next"));
  uint16_t nm = TET[tetN][0];
  for (int i = 0; i < 16; i++) if (nm & (0x8000 >> i))
    display.fillRect(92 + (i & 3) * 4, 12 + (i >> 2) * 4, 3, 3, 1);
  if (tetState) bpPanelSB("GAME OVER", tetScore, tetBest, "SELECT: retry");
  display.display();
}

// ================= PONG (UP/DOWN, SELECT = serve, first to 7) =================
#define PG_H 14
static float pngY, pngAi, pngBx, pngBy, pngVx, pngVy;
static int pngS, pngAs, pngState;                       // state: 0 serve, 1 play, 2 over
static unsigned long pngLast;
static void pngServe(int dir) { pngBx = 64; pngBy = 36; pngVx = 1.8f * dir; pngVy = (random(2) ? 1 : -1) * frand(0.4f, 1.0f); pngState = 0; }
static void pngStart() { pngY = pngAi = 28; pngS = pngAs = 0; pngServe(random(2) ? 1 : -1); pngLast = millis(); }
static void pngUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (pngState == 2) { if (btnPressed[BTN_SELECT]) pngStart(); return; }
  if (pngState == 0 && btnPressed[BTN_SELECT]) pngState = 1;
  if (millis() - pngLast < 20) return; pngLast = millis();
  if (isHeld(BTN_UP))   pngY -= 2.6f;
  if (isHeld(BTN_DOWN)) pngY += 2.6f;
  if (pngY < 8) pngY = 8;
  if (pngY > 64 - PG_H) pngY = 64 - PG_H;
  if (pngState == 0) return;
  float tgt = (pngVx > 0) ? pngBy - PG_H / 2 : 36 - PG_H / 2;
  float sp = 1.25f + pngS * 0.1f; if (sp > 2.2f) sp = 2.2f;
  float df = tgt - pngAi; if (df > sp) df = sp; if (df < -sp) df = -sp;
  pngAi += df;
  if (pngAi < 8) pngAi = 8;
  if (pngAi > 64 - PG_H) pngAi = 64 - PG_H;
  pngBx += pngVx; pngBy += pngVy;
  if (pngBy < 8)  { pngBy = 8;  pngVy = fabsf(pngVy); }
  if (pngBy > 61) { pngBy = 61; pngVy = -fabsf(pngVy); }
  if (pngVx < 0 && pngBx <= 7 && pngBx >= 2 && pngBy + 2 >= pngY && pngBy <= pngY + PG_H) {
    pngVx = fabsf(pngVx) * 1.06f; if (pngVx > 4.0f) pngVx = 4.0f;
    pngVy += ((pngBy - (pngY + PG_H / 2)) / (PG_H / 2)) * 1.2f;
    if (pngVy > 2.6f) pngVy = 2.6f; if (pngVy < -2.6f) pngVy = -2.6f;
    pngBx = 8;
  }
  if (pngVx > 0 && pngBx >= 119 && pngBx <= 124 && pngBy + 2 >= pngAi && pngBy <= pngAi + PG_H) {
    pngVx = -fabsf(pngVx) * 1.04f; if (pngVx < -4.0f) pngVx = -4.0f;
    pngVy += ((pngBy - (pngAi + PG_H / 2)) / (PG_H / 2)) * 1.2f;
    if (pngVy > 2.6f) pngVy = 2.6f; if (pngVy < -2.6f) pngVy = -2.6f;
    pngBx = 118;
  }
  if (pngBx < 0)    { pngAs++; if (pngAs >= 7) { pngState = 2; saveAll(); } else pngServe(1); }
  if (pngBx > 127)  { pngS++;  if (pngS >= 7)  { pngState = 2; pngWins++; saveAll(); } else pngServe(-1); }
}
static void pngDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  display.setCursor(0, 0); display.print('W'); display.print(pngWins);
  display.setCursor(52, 0); display.print(pngS); display.print(F(" : ")); display.print(pngAs);
  display.drawFastHLine(0, 7, 128, 1);
  for (int y = 10; y < 64; y += 6) display.drawFastVLine(64, y, 3, 1);
  display.fillRect(4, (int)pngY, 3, PG_H, 1);
  display.fillRect(121, (int)pngAi, 3, PG_H, 1);
  display.fillRect((int)pngBx, (int)pngBy, 3, 3, 1);
  if (pngState == 0) { display.setCursor(30, 50); display.print(F("SELECT: serve")); }
  if (pngState == 2) { char b[16]; snprintf(b, sizeof(b), "%d : %d", pngS, pngAs); bpPanel(pngS >= 7 ? "YOU WIN!" : "YOU LOSE", b, "SELECT: again"); }
  display.display();
}

// ================= INVADERS (LEFT/RIGHT, hold SELECT = fire) =================
#define IV_C 8
#define IV_R 4
struct IvShot { float x, y; bool on; };
static bool ivA[IV_R][IV_C];
static IvShot ivS[3];
static float ivX, ivPx, ivBx, ivBy;
static int ivY, ivDir, ivAlive, ivLives, ivState, ivWave;   // state: 0 run, 1 over
static bool ivBon;
static uint32_t ivScore;
static unsigned long ivLast, ivStep, ivShotT, ivFire, ivInv;
static void ivWaveInit() {
  for (int r = 0; r < IV_R; r++) for (int c = 0; c < IV_C; c++) ivA[r][c] = true;
  ivAlive = IV_R * IV_C; ivX = 4; ivY = 10 + (ivWave > 4 ? 3 : ivWave - 1) * 3; ivDir = 1; ivBon = false;
  for (auto& s : ivS) s.on = false;
  ivStep = millis(); ivShotT = millis() + 1000;
}
static void ivStart() { ivPx = 59; ivLives = 3; ivScore = 0; ivWave = 1; ivState = 0; ivInv = 0; ivFire = 0; ivWaveInit(); ivLast = millis(); }
static void ivOver() { ivState = 1; saveAll(); }
static void ivUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (ivState) { if (btnPressed[BTN_SELECT]) ivStart(); return; }
  if (millis() - ivLast < 25) return; ivLast = millis();
  if (isHeld(BTN_LEFT))  ivPx -= 2.5f;
  if (isHeld(BTN_RIGHT)) ivPx += 2.5f;
  if (ivPx < 0) ivPx = 0;
  if (ivPx > 119) ivPx = 119;
  if (isHeld(BTN_SELECT) && !ivBon && millis() - ivFire > 200) { ivBon = true; ivBx = ivPx + 4; ivBy = 56; ivFire = millis(); }
  if (ivBon) {                                          // player bullet
    ivBy -= 4;
    if (ivBy < 8) ivBon = false;
    else for (int r = 0; r < IV_R && ivBon; r++) for (int c = 0; c < IV_C; c++) {
      if (!ivA[r][c]) continue;
      float ax = ivX + c * 12, ay = ivY + r * 9;
      if (ivBx >= ax && ivBx <= ax + 8 && ivBy >= ay && ivBy <= ay + 5) {
        ivA[r][c] = false; ivAlive--; ivBon = false; ivScore += 10 * (IV_R - r);
        if (ivScore > invBest) { invBest = ivScore; dirty = true; }
        break;
      }
    }
  }
  if (ivAlive == 0) { ivWave++; ivWaveInit(); return; }
  long iv = 40 + ivAlive * 12 - (ivWave - 1) * 15; if (iv < 40) iv = 40;
  if (millis() - ivStep >= (unsigned long)iv) {         // alien march
    ivStep = millis();
    int lo = IV_C, hi = -1, low = 0;
    for (int r = 0; r < IV_R; r++) for (int c = 0; c < IV_C; c++) if (ivA[r][c]) { if (c < lo) lo = c; if (c > hi) hi = c; if (r > low) low = r; }
    float le = ivX + lo * 12, re = ivX + hi * 12 + 8;
    if ((ivDir > 0 && re + 3 > 127) || (ivDir < 0 && le - 3 < 0)) { ivDir = -ivDir; ivY += 4; }
    else ivX += 3 * ivDir;
    if (ivY + low * 9 + 5 >= 56) { ivOver(); return; }
  }
  if (millis() > ivShotT) {                             // alien fire
    long gap = 1100 - ivWave * 100; if (gap < 350) gap = 350;
    ivShotT = millis() + gap + random(400);
    int c = random(IV_C), rr = -1;
    for (int r = IV_R - 1; r >= 0; r--) if (ivA[r][c]) { rr = r; break; }
    if (rr >= 0) for (auto& s : ivS) if (!s.on) { s.on = true; s.x = ivX + c * 12 + 4; s.y = ivY + rr * 9 + 5; break; }
  }
  for (auto& s : ivS) {
    if (!s.on) continue;
    s.y += 2.0f;
    if (s.y > 64) { s.on = false; continue; }
    if (millis() > ivInv && s.y >= 56 && s.x >= ivPx && s.x <= ivPx + 9) {
      s.on = false; ivLives--; ivInv = millis() + 1500;
      if (ivLives <= 0) { ivOver(); return; }
    }
  }
}
static void ivDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  int anim = ((int)ivX / 3) & 1;
  for (int r = 0; r < IV_R; r++) for (int c = 0; c < IV_C; c++) {
    if (!ivA[r][c]) continue;
    int x = (int)ivX + c * 12, y = ivY + r * 9;
    display.fillRect(x + 1, y, 6, 3, 1); display.fillRect(x, y + 1, 8, 1, 1);
    display.drawPixel(x + 2, y + 1, 0); display.drawPixel(x + 5, y + 1, 0);
    if (anim) { display.drawPixel(x + 1, y + 3, 1); display.drawPixel(x + 6, y + 3, 1); }
    else      { display.drawPixel(x + 2, y + 3, 1); display.drawPixel(x + 5, y + 3, 1); }
  }
  if (ivBon) display.fillRect((int)ivBx, (int)ivBy, 1, 3, 1);
  for (auto& s : ivS) if (s.on) display.fillRect((int)s.x, (int)s.y, 1, 3, 1);
  if (ivState == 0 && (millis() > ivInv || ((millis() / 100) & 1))) {
    display.fillRect((int)ivPx, 60, 9, 3, 1); display.fillRect((int)ivPx + 3, 58, 3, 2, 1);
  }
  display.setCursor(0, 0); display.print(ivScore);
  display.setCursor(56, 0); display.print('W'); display.print(ivWave);
  for (int i = 0; i < ivLives; i++) display.fillRect(100 + i * 9, 1, 6, 3, 1);
  if (ivState == 1) bpPanelSB("GAME OVER", ivScore, invBest, "SELECT: retry");
  display.display();
}

// ================= MENU =================
#define BP_N 16
static const char* const BP_NAME[BP_N] = {"GD Dash", "Clicker", "Simon", "Dodge", "Reaction", "2048", "Stack", "Asteroids",
                                          "Mines", "Snake", "Flappy", "Breakout", "Tetris", "Pong", "Invaders", "Reset saves"};
static const uint8_t BP_ICON[BP_N][8] = {
  {0x10, 0x10, 0x38, 0x38, 0x7C, 0x7C, 0xFE, 0x00},   // GD Dash: spike
  {0x3C, 0x42, 0x81, 0x99, 0x99, 0x81, 0x42, 0x3C},   // Clicker: coin
  {0xEE, 0xAA, 0xEE, 0x00, 0xEE, 0xAA, 0xEE, 0x00},   // Simon: 4 pads
  {0x38, 0x38, 0x38, 0x00, 0x00, 0x00, 0x7E, 0x7E},   // Dodge: block + player
  {0x1C, 0x38, 0x70, 0xFE, 0x1C, 0x38, 0x70, 0x20},   // Reaction: bolt
  {0xFF, 0x81, 0xBD, 0x85, 0xBD, 0xA1, 0xBD, 0xFF},   // 2048: tile "2"
  {0x38, 0x38, 0x00, 0x7C, 0x7C, 0x00, 0xFE, 0xFE},   // Stack: tower
  {0x1C, 0x7E, 0x7F, 0xFE, 0xFE, 0x7E, 0x3C, 0x18},   // Asteroids: rock
  {0x92, 0x54, 0x38, 0xFE, 0x38, 0x54, 0x92, 0x00},   // Mines
  {0x7C, 0x40, 0x40, 0x7C, 0x04, 0x04, 0x7C, 0x00},   // Snake: S
  {0x38, 0x7E, 0xDE, 0xFF, 0xFC, 0x7E, 0x38, 0x00},   // Flappy: bird
  {0xEE, 0x00, 0xEE, 0x00, 0x00, 0x10, 0x00, 0x7E},   // Breakout
  {0xFC, 0xFC, 0x30, 0x30, 0x00, 0x00, 0xCC, 0xCC},   // Tetris
  {0x00, 0x80, 0x80, 0x81, 0x89, 0x01, 0x01, 0x00},   // Pong
  {0x24, 0x7E, 0xDB, 0xFF, 0xFF, 0x24, 0x5A, 0x81},   // Invaders: alien
  {0x81, 0x42, 0x24, 0x18, 0x18, 0x24, 0x42, 0x81}    // Reset: X
};
static void menuUpdate() {
  if (checkExitToMenu()) { resetArm = false; return; }
  if (btnPressed[BTN_UP])   { cur = (cur + BP_N - 1) % BP_N; resetArm = false; }
  if (btnPressed[BTN_DOWN]) { cur = (cur + 1) % BP_N; resetArm = false; }
  if (!btnPressed[BTN_SELECT]) return;
  switch (cur) {
    case 0: gdBuild(); gdStart(); sub = S_GD; break;
    case 1: clkLastAuto = clkLastSave = millis(); sub = S_CLK; break;
    case 2: simStart(); sub = S_SIM; break;
    case 3: dgStart(); sub = S_DGE; break;
    case 4: rctState = 0; sub = S_RCT; break;
    case 5: t48Start(); sub = S_2048; break;
    case 6: stkStart(); sub = S_STK; break;
    case 7: asStart(); sub = S_AST; break;
    case 8: mnStart(); sub = S_MIN; break;
    case 9: snkStart(); sub = S_SNK; break;
    case 10: flpStart(); sub = S_FLP; break;
    case 11: brkStart(); sub = S_BRK; break;
    case 12: tetStart(); sub = S_TET; break;
    case 13: pngStart(); sub = S_PNG; break;
    case 14: ivStart(); sub = S_INV; break;
    default: if (!resetArm) resetArm = true; else { wipeAll(); resetArm = false; }
  }
}
static void menuDraw() {
  display.clearDisplay(); display.setTextSize(1);
  // header bar
  display.fillRect(0, 0, 128, 9, 1); display.setTextColor(0);
  display.setCursor(3, 1); display.print(F("BONUS PACK"));
  char cnt[8]; snprintf(cnt, sizeof(cnt), "%d/%d", cur + 1, BP_N);
  display.setCursor(125 - (int)strlen(cnt) * 6, 1); display.print(cnt);
  // right-hand values
  char v[BP_N][12];
  const uint32_t sc[BP_N] = {gdBest, clkCoins, simBest, dgeBest, rctBest, best48, stkBest, astBest, mnBest, snkBest, flpBest, brkBest, tetBest, pngWins, invBest, 0};
  for (int i = 0; i < BP_N; i++) {
    if (!sc[i]) snprintf(v[i], 12, "--"); else snprintf(v[i], 12, "%u", (unsigned)sc[i]);
  }
  snprintf(v[0], 12, "%u%%", (unsigned)gdBest);
  if (clkCoins) snprintf(v[1], 12, "$%u", (unsigned)clkCoins); else snprintf(v[1], 12, "$0");
  if (rctBest) snprintf(v[4], 12, "%ums", (unsigned)rctBest);
  if (mnBest)  snprintf(v[8], 12, "%us", (unsigned)mnBest);
  if (pngWins) snprintf(v[13], 12, "W%u", (unsigned)pngWins);
  snprintf(v[15], 12, "%s", resetArm ? "SURE?" : "");
  // list: 4 rows, selection highlighted
  int top = cur - 1; if (top < 0) top = 0; if (top > BP_N - 4) top = BP_N - 4;
  for (int i = 0; i < 4; i++) {
    int idx = top + i, y = 11 + i * 11; bool sel = (idx == cur);
    uint16_t col = sel ? 0 : 1;
    if (sel) { display.fillRect(0, y, 123, 11, 1); display.drawPixel(0, y, 0); display.drawPixel(122, y, 0); display.drawPixel(0, y + 10, 0); display.drawPixel(122, y + 10, 0); }
    bpIcon(3, y + 1, BP_ICON[idx], col);
    display.setTextColor(col);
    display.setCursor(15, y + 2); display.print(BP_NAME[idx]);
    display.setCursor(120 - (int)strlen(v[idx]) * 6, y + 2); display.print(v[idx]);
  }
  // scrollbar
  for (int y = 11; y < 55; y += 2) display.drawPixel(126, y, 1);
  int th = 44 * 4 / BP_N; if (th < 5) th = 5;
  int ty = 11 + (44 - th) * cur / (BP_N - 1);
  display.fillRect(125, ty, 3, th, 1);
  // footer
  display.setTextColor(1);
  display.setCursor(resetArm ? 2 : 8, 56); display.print(resetArm ? F("Press SELECT = WIPE!") : F("SEL:open  BACK:exit"));
  display.display();
}

// ================= HOOKS FOR minigame.ino =================
void customReset() {
#ifndef GYVER_OLED_EXTERNAL
  oled.init(BP_SDA, BP_SCL);                            // pass the pins: plain init() would re-init I2C on default pins
  GyverGfx::addrMode(0x00);                             // init() leaves the panel in vertical mode: give it back to Adafruit
#endif
  loadAll(); sub = S_MENU; cur = 0; resetArm = false;
}
void customUpdate() {
  switch (sub) {
    case S_MENU: menuUpdate(); break; case S_GD: gdUpdate(); break; case S_CLK: clkUpdate(); break;
    case S_SIM: simUpdate(); break;   case S_DGE: dgUpdate(); break; case S_RCT: rctUpdate(); break;
    case S_2048: t48Update(); break;  case S_STK: stkUpdate(); break; case S_AST: asUpdate(); break;
    case S_MIN: mnUpdate(); break;    case S_SNK: snkUpdate(); break; case S_FLP: flpUpdate(); break;
    case S_BRK: brkUpdate(); break;   case S_TET: tetUpdate(); break; case S_PNG: pngUpdate(); break;
    case S_INV: ivUpdate(); break;
  }
}
void customDraw() {
  switch (sub) {
    case S_MENU: menuDraw(); break; case S_GD: gdDraw(); break; case S_CLK: clkDraw(); break;
    case S_SIM: simDraw(); break;   case S_DGE: dgDraw(); break; case S_RCT: rctDraw(); break;
    case S_2048: t48Draw(); break;  case S_STK: stkDraw(); break; case S_AST: asDraw(); break;
    case S_MIN: mnDraw(); break;    case S_SNK: snkDraw(); break; case S_FLP: flpDraw(); break;
    case S_BRK: brkDraw(); break;   case S_TET: tetDraw(); break; case S_PNG: pngDraw(); break;
    case S_INV: ivDraw(); break;
  }
}