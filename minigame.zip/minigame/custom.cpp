#include <Arduino.h>
#include <Preferences.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;
extern bool btnPressed[7];
extern bool isHeld(int idx);
extern bool checkExitToMenu();

#define BTN_UP     0
#define BTN_DOWN   1
#define BTN_LEFT   2
#define BTN_RIGHT  3
#define BTN_SELECT 4
#define BTN_BOOT   5
#define BTN_BACK   6

const char* CUSTOM_GAME_NAME = "Bonus Pack";

// ================= SAVE DATA (NVS, namespace "bonus") =================
enum Sub { S_MENU, S_GD, S_CLK, S_SIM, S_DGE, S_RCT, S_2048, S_STK, S_AST, S_MIN };
static Sub sub;
static Preferences sv;
static uint32_t gdBest, gdAtt, gdJumps, clkCoins, clkTotal, clkP, clkA;
static uint32_t simBest, dgeBest, rctBest, best48, stkBest, astBest, mnBest;
static bool dirty;
static int cur;
static bool resetArm;

static void loadAll() {
  sv.begin("bonus", false);
  gdBest = sv.getUInt("gdBest", 0);  gdAtt = sv.getUInt("gdAtt", 0);  gdJumps = sv.getUInt("gdJumps", 0);
  clkCoins = sv.getUInt("coins", 0); clkTotal = sv.getUInt("total", 0);
  clkP = sv.getUInt("clkP", 0);      clkA = sv.getUInt("clkA", 0);
  simBest = sv.getUInt("simB", 0);   dgeBest = sv.getUInt("dgeB", 0); rctBest = sv.getUInt("rctB", 0);
  best48 = sv.getUInt("b2048", 0);   stkBest = sv.getUInt("stkB", 0); astBest = sv.getUInt("astB", 0);
  mnBest = sv.getUInt("minB", 0);
  sv.end(); dirty = false;
}
static void saveAll() {
  sv.begin("bonus", false);
  sv.putUInt("gdBest", gdBest);  sv.putUInt("gdAtt", gdAtt);  sv.putUInt("gdJumps", gdJumps);
  sv.putUInt("coins", clkCoins); sv.putUInt("total", clkTotal);
  sv.putUInt("clkP", clkP);      sv.putUInt("clkA", clkA);
  sv.putUInt("simB", simBest);   sv.putUInt("dgeB", dgeBest); sv.putUInt("rctB", rctBest);
  sv.putUInt("b2048", best48);   sv.putUInt("stkB", stkBest); sv.putUInt("astB", astBest);
  sv.putUInt("minB", mnBest);
  sv.end(); dirty = false;
}
static void wipeAll() {
  sv.begin("bonus", false); sv.clear(); sv.end();
  gdBest = gdAtt = gdJumps = clkCoins = clkTotal = clkP = clkA = 0;
  simBest = dgeBest = rctBest = best48 = stkBest = astBest = mnBest = 0; dirty = false;
}
static bool backPressed() { return btnPressed[BTN_BACK] || btnPressed[BTN_BOOT]; }

// ================= GD DASH =================
#define GD_G 54
#define GD_MAX 60
#define GD_LEN 3200
struct GdOb { int16_t x; uint8_t t; };      // 0 spike, 1 double spike, 2 block 8, 3 block 16
static GdOb gdOb[GD_MAX];
static int gdN, gdState;                     // 0 run, 1 dead, 2 win
static float gdX, gdPy, gdVy;
static bool gdOnG;
static unsigned long gdLast, gdT;

static int obW(uint8_t t) { return (t == 1 || t == 3) ? 16 : 8; }
static int obH(uint8_t t) { return t == 3 ? 16 : 8; }
static void gdBuild() {
  uint32_t s = 12345; int x = 170; gdN = 0;
  while (gdN < GD_MAX && x < GD_LEN - 90) {
    s = s * 1103515245u + 12345u; uint8_t r = (s >> 16) & 7;
    uint8_t t = r < 3 ? 0 : r < 5 ? 1 : r < 7 ? 2 : 3;
    gdOb[gdN++] = { (int16_t)x, t };
    s = s * 1103515245u + 12345u; x += obW(t) + 70 + ((s >> 16) % 50);
  }
}
static void gdStart() { gdX = 0; gdPy = GD_G - 8; gdVy = 0; gdOnG = true; gdState = 0; gdAtt++; dirty = true; gdLast = millis(); }
static int gdPct() { int p = (int)(gdX * 100 / GD_LEN); return p > 100 ? 100 : p; }
static void gdDie() { gdState = 1; gdT = millis(); if ((uint32_t)gdPct() > gdBest) gdBest = gdPct(); saveAll(); }

static void gdUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (gdState == 1) { if (millis() - gdT > 500) gdStart(); return; }
  if (gdState == 2) { if (btnPressed[BTN_SELECT]) gdStart(); return; }
  if (millis() - gdLast < 25) return; gdLast = millis();

  if (gdOnG && isHeld(BTN_SELECT)) { gdVy = -5.2f; gdJumps++; dirty = true; }
  gdVy += 0.55f; gdPy += gdVy; gdOnG = false; gdX += 2.2f;
  if (gdPy >= GD_G - 8) { gdPy = GD_G - 8; gdVy = 0; gdOnG = true; }

  for (int i = 0; i < gdN; i++) {                         // landing on blocks
    float sx = gdOb[i].x - gdX; if (sx > 45 || sx < -20 || gdOb[i].t < 2) continue;
    int w = obW(gdOb[i].t), top = GD_G - obH(gdOb[i].t);
    if (31 < sx + w && 37 > sx && gdVy >= 0 && gdPy + 8 >= top && gdPy + 8 - gdVy <= top + 2) { gdPy = top - 8; gdVy = 0; gdOnG = true; }
  }
  for (int i = 0; i < gdN; i++) {                         // deaths
    float sx = gdOb[i].x - gdX; if (sx > 45 || sx < -20) continue;
    int w = obW(gdOb[i].t), h = obH(gdOb[i].t);
    float rx = sx, ry = GD_G - h, rw = w, rh = h;
    if (gdOb[i].t < 2) { rx = sx + 2; ry = GD_G - 6; rw = w - 4; rh = 6; }
    if (31 < rx + rw && 37 > rx && gdPy + 1 < ry + rh && gdPy + 7 > ry) { gdDie(); return; }
  }
  if (gdX >= GD_LEN) { gdState = 2; gdBest = 100; saveAll(); }
}
static void gdDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  display.drawFastHLine(0, GD_G, 128, 1);
  for (int i = 0; i < 9; i++) display.drawPixel(i * 16 - ((int)gdX % 16), GD_G + 3, 1);
  for (int i = 0; i < gdN; i++) {
    int sx = (int)(gdOb[i].x - gdX); if (sx > 128 || sx < -20) continue;
    uint8_t t = gdOb[i].t;
    if (t < 2) { for (int k = 0; k < (t == 1 ? 2 : 1); k++) display.fillTriangle(sx + k * 8, GD_G, sx + k * 8 + 8, GD_G, sx + k * 8 + 4, GD_G - 8, 1); }
    else { int h = obH(t), w = obW(t); display.drawRect(sx, GD_G - h, w, h, 1); display.drawRect(sx + 2, GD_G - h + 2, w - 4, h - 4, 1); }
  }
  display.fillRect(30, (int)gdPy, 8, 8, 1); display.fillRect(34, (int)gdPy + 2, 2, 2, 0);
  if (gdState == 1) { display.drawLine(28, (int)gdPy - 2, 40, (int)gdPy + 10, 1); display.drawLine(40, (int)gdPy - 2, 28, (int)gdPy + 10, 1); }
  display.setCursor(0, 0); display.print(gdPct()); display.print('%');
  display.drawRect(26, 1, 100, 5, 1); display.fillRect(27, 2, gdPct() * 98 / 100, 3, 1);
  display.setCursor(0, 57); display.print(F("Att ")); display.print(gdAtt); display.print(F("  Best ")); display.print(gdBest); display.print('%');
  if (gdState == 2) { display.fillRect(10, 18, 108, 24, 0); display.drawRect(10, 18, 108, 24, 1); display.setCursor(22, 22); display.print(F("LEVEL COMPLETE!")); display.setCursor(22, 32); display.print(F("SELECT: again")); }
  display.display();
}

// ================= CLICKER =================
static unsigned long clkLastAuto, clkLastSave, clkAnim;
static uint32_t costP() { return 15 + clkP * clkP * 8; }
static uint32_t costA() { return 50 + clkA * clkA * 25; }
static void clkUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (btnPressed[BTN_SELECT]) { clkCoins += 1 + clkP; clkTotal += 1 + clkP; clkAnim = millis(); dirty = true; }
  if (btnPressed[BTN_UP] && clkCoins >= costP()) { clkCoins -= costP(); clkP++; dirty = true; }
  if (btnPressed[BTN_DOWN] && clkCoins >= costA()) { clkCoins -= costA(); clkA++; dirty = true; }
  if (clkA && millis() - clkLastAuto >= 1000) { clkLastAuto += 1000; clkCoins += clkA; clkTotal += clkA; dirty = true; }
  if (dirty && millis() - clkLastSave > 5000) { saveAll(); clkLastSave = millis(); }
}
static void clkDraw() {
  display.clearDisplay(); display.setTextColor(1); display.setTextSize(1);
  display.setCursor(0, 0); display.print(F("CLICKER  total ")); display.print(clkTotal);
  int r = (millis() - clkAnim < 120) ? 6 : 3; display.fillCircle(120, 4, r, 1);
  display.setTextSize(2); display.setCursor(2, 12); display.print(clkCoins); display.setTextSize(1);
  display.setCursor(0, 31); display.print('+'); display.print(1 + clkP); display.print(F("/click  auto ")); display.print(clkA); display.print(F("/s"));
  display.setCursor(0, 41); display.print(clkCoins >= costP() ? '*' : ' '); display.print(F("UP click+1 $")); display.print(costP());
  display.setCursor(0, 50); display.print(clkCoins >= costA() ? '*' : ' '); display.print(F("DOWN auto+1 $")); display.print(costA());
  display.setCursor(0, 57); display.print(F("SELECT = click"));
  display.display();
}

// ================= SIMON =================
static uint8_t simSeq[50];
static int simLen, simShow, simIn, simState, simLit;   // state: 0 show, 1 input, 2 fail
static unsigned long simT;
static void simStart() { simLen = 1; simSeq[0] = random(4); simState = 0; simShow = 0; simLit = -1; simT = millis() + 600; }
static void simUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (simState == 2) { if (btnPressed[BTN_SELECT]) simStart(); return; }
  if (simState == 0) {
    if (millis() < simT) return;
    if (simLit == -1) {
      if (simShow < simLen) { simLit = simSeq[simShow]; simT = millis() + 450; }
      else { simState = 1; simIn = 0; }
    } else { simLit = -1; simShow++; simT = millis() + 200; }
    return;
  }
  if (simLit != -1 && millis() > simT) simLit = -1;
  int d = -1;                                           // UP=0 RIGHT=1 DOWN=2 LEFT=3
  if (btnPressed[BTN_UP]) d = 0; else if (btnPressed[BTN_RIGHT]) d = 1;
  else if (btnPressed[BTN_DOWN]) d = 2; else if (btnPressed[BTN_LEFT]) d = 3;
  if (d < 0) return;
  simLit = d; simT = millis() + 150;
  if (d != simSeq[simIn]) { simState = 2; simLit = -1; saveAll(); return; }
  if (++simIn == simLen) {
    if ((uint32_t)simLen > simBest) { simBest = simLen; dirty = true; }
    if (simLen < 50) simSeq[simLen++] = random(4);
    simState = 0; simShow = 0; simLit = -1; simT = millis() + 700;
  }
}
static void simDraw() {
  display.clearDisplay(); display.setTextColor(1); display.setTextSize(1);
  const int px[4] = {46, 84, 46, 20}, py[4] = {10, 22, 42, 22}, pw[4] = {36, 24, 36, 24}, ph[4] = {12, 20, 12, 20};
  for (int i = 0; i < 4; i++) { if (simLit == i) display.fillRect(px[i], py[i], pw[i], ph[i], 1); else display.drawRect(px[i], py[i], pw[i], ph[i], 1); }
  display.setCursor(0, 0); display.print(F("R")); display.print(simLen - (simState == 2 ? 1 : 0));
  display.setCursor(0, 56); display.print(F("Best ")); display.print(simBest);
  display.setCursor(72, 56);
  display.print(simState == 0 ? F("watch...") : simState == 1 ? F("your turn") : F("SEL:retry"));
  display.display();
}

// ================= DODGE =================
struct DgBlk { float x, y, v; bool on; };
static DgBlk dgB[8];
static float dgX;
static int dgTick, dgState;                             // 0 run, 1 dead
static unsigned long dgLast, dgSpawn;
static int dgScore() { return dgTick / 20; }
static void dgStart() { dgX = 59; dgTick = 0; dgState = 0; for (auto& b : dgB) b.on = false; dgLast = dgSpawn = millis(); }
static void dgUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (dgState == 1) { if (btnPressed[BTN_SELECT]) dgStart(); return; }
  if (isHeld(BTN_LEFT))  dgX -= 2.5f;
  if (isHeld(BTN_RIGHT)) dgX += 2.5f;
  if (dgX < 0) dgX = 0; if (dgX > 118) dgX = 118;
  if (millis() - dgLast < 25) return; dgLast = millis(); dgTick++;
  int sc = dgScore(); long iv = 700 - sc * 3; if (iv < 220) iv = 220;
  if ((long)(millis() - dgSpawn) > iv) {
    dgSpawn = millis();
    for (auto& b : dgB) if (!b.on) { b.on = true; b.x = random(0, 120); b.y = -8; b.v = 1.3f + sc * 0.02f; if (b.v > 3.6f) b.v = 3.6f; break; }
  }
  for (auto& b : dgB) {
    if (!b.on) continue;
    b.y += b.v; if (b.y > 64) { b.on = false; continue; }
    if (b.x < dgX + 10 && b.x + 8 > dgX && b.y + 8 > 56 && b.y < 62) {
      dgState = 1; if ((uint32_t)sc > dgeBest) dgeBest = sc; saveAll(); return;
    }
  }
}
static void dgDraw() {
  display.clearDisplay(); display.setTextColor(1); display.setTextSize(1);
  for (auto& b : dgB) if (b.on) display.fillRect((int)b.x, (int)b.y, 8, 8, 1);
  display.fillRect((int)dgX, 56, 10, 6, 1);
  display.setCursor(0, 0); display.print(dgScore()); display.print(F("  best ")); display.print(dgeBest);
  if (dgState == 1) { display.fillRect(20, 20, 88, 24, 0); display.drawRect(20, 20, 88, 24, 1); display.setCursor(32, 24); display.print(F("CRASHED!")); display.setCursor(26, 34); display.print(F("SELECT: retry")); }
  display.display();
}

// ================= REACTION =================
static int rctState;                                    // 0 idle, 1 wait, 2 go, 3 result
static unsigned long rctWait, rctGo, rctMs;
static void rctUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (rctState == 0 || rctState == 3) { if (btnPressed[BTN_SELECT]) { rctState = 1; rctWait = millis() + random(1500, 4000); } return; }
  if (rctState == 1) {
    if (btnPressed[BTN_SELECT]) { rctMs = 0; rctState = 3; }            // false start
    else if (millis() >= rctWait) { rctState = 2; rctGo = millis(); }
    return;
  }
  if (btnPressed[BTN_SELECT]) {
    rctMs = millis() - rctGo; rctState = 3;
    if (rctBest == 0 || rctMs < rctBest) { rctBest = rctMs; saveAll(); }
  }
}
static void rctDraw() {
  display.clearDisplay(); display.setTextSize(1);
  if (rctState == 2) { display.fillRect(0, 0, 128, 64, 1); display.setTextColor(0); display.setTextSize(2); display.setCursor(30, 24); display.print(F("PRESS!")); display.display(); return; }
  display.setTextColor(1);
  display.setCursor(34, 0); display.print(F("REACTION")); display.drawFastHLine(0, 9, 128, 1);
  display.setCursor(4, 18);
  if (rctState == 0) display.print(F("SELECT to start"));
  else if (rctState == 1) display.print(F("Wait for it..."));
  else if (rctMs == 0) display.print(F("Too early!"));
  else { display.setTextSize(2); display.print(rctMs); display.print(F(" ms")); display.setTextSize(1); }
  display.setCursor(4, 44); display.print(F("Best: ")); if (rctBest) { display.print(rctBest); display.print(F(" ms")); } else display.print(F("--"));
  display.setCursor(4, 56); display.print(F("BACK: menu"));
  display.display();
}

// ================= 2048 =================
static uint32_t t48[4][4];
static uint32_t sc48;
static bool over48, won48;
static void t48Add() {
  int er[16], ec[16], n = 0;
  for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) if (!t48[r][c]) { er[n] = r; ec[n] = c; n++; }
  if (!n) return;
  int k = random(n); t48[er[k]][ec[k]] = random(10) == 0 ? 4 : 2;
}
static bool t48Can() {
  for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
    if (!t48[r][c]) return true;
    if (c < 3 && t48[r][c] == t48[r][c + 1]) return true;
    if (r < 3 && t48[r][c] == t48[r + 1][c]) return true;
  }
  return false;
}
static bool t48Move(int dir) {                          // 0 up, 1 down, 2 left, 3 right
  bool moved = false;
  for (int i = 0; i < 4; i++) {
    uint32_t a[4]; int pr[4], pc[4];
    for (int k = 0; k < 4; k++) {
      int r, c;
      if (dir == 2) { r = i; c = k; } else if (dir == 3) { r = i; c = 3 - k; }
      else if (dir == 0) { r = k; c = i; } else { r = 3 - k; c = i; }
      pr[k] = r; pc[k] = c; a[k] = t48[r][c];
    }
    uint32_t o[4] = {0, 0, 0, 0}; int n = 0; bool mergedLast = false;
    for (int k = 0; k < 4; k++) {
      if (!a[k]) continue;
      if (n > 0 && o[n - 1] == a[k] && !mergedLast) { o[n - 1] *= 2; sc48 += o[n - 1]; if (o[n - 1] == 2048) won48 = true; mergedLast = true; }
      else { o[n++] = a[k]; mergedLast = false; }
    }
    for (int k = 0; k < 4; k++) { if (t48[pr[k]][pc[k]] != o[k]) moved = true; t48[pr[k]][pc[k]] = o[k]; }
  }
  return moved;
}
static void t48Start() { memset(t48, 0, sizeof(t48)); sc48 = 0; over48 = won48 = false; t48Add(); t48Add(); }
static void t48Update() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (over48) { if (btnPressed[BTN_SELECT]) t48Start(); return; }
  int d = -1;
  if (btnPressed[BTN_UP]) d = 0; else if (btnPressed[BTN_DOWN]) d = 1;
  else if (btnPressed[BTN_LEFT]) d = 2; else if (btnPressed[BTN_RIGHT]) d = 3;
  if (d < 0) return;
  if (t48Move(d)) {
    t48Add();
    if (sc48 > best48) { best48 = sc48; dirty = true; }
    if (!t48Can()) { over48 = true; saveAll(); }
  }
}
static void t48Draw() {
  display.clearDisplay(); display.setTextSize(1);
  for (int r = 0; r < 4; r++) for (int c = 0; c < 4; c++) {
    int x = 2 + c * 24, y = 2 + r * 15; uint32_t v = t48[r][c];
    if (!v) { display.drawPixel(x + 11, y + 7, 1); continue; }
    bool inv = v >= 128;
    if (inv) display.fillRect(x, y, 24, 15, 1); else display.drawRect(x, y, 24, 15, 1);
    char b[8]; snprintf(b, 8, "%u", (unsigned)v); int w = strlen(b) * 6;
    display.setTextColor(inv ? 0 : 1, inv ? 1 : 0);
    display.setCursor(x + (24 - w) / 2, y + 4); display.print(b);
  }
  display.setTextColor(1);
  display.setCursor(99, 2);  display.print(F("Sc"));
  display.setCursor(99, 11); display.print(sc48);
  display.setCursor(99, 26); display.print(F("Best"));
  display.setCursor(99, 35); display.print(best48);
  if (won48) { display.setCursor(99, 52); display.print(F("2048!")); }
  if (over48) { display.fillRect(6, 20, 88, 24, 0); display.drawRect(6, 20, 88, 24, 1); display.setCursor(18, 24); display.print(F("NO MOVES")); display.setCursor(12, 34); display.print(F("SELECT: new")); }
  display.display();
}

// ================= STACK =================
#define STK_MAX 120
static int16_t stkX[STK_MAX], stkW[STK_MAX];
static int stkN, stkState, stkStreak;                   // state: 0 run, 1 over
static uint32_t stkScore;
static float stkCx, stkCw, stkDir;
static unsigned long stkLast;
static void stkStart() {
  stkN = 1; stkX[0] = 44; stkW[0] = 40; stkCw = 40; stkCx = 0; stkDir = 1;
  stkState = 0; stkStreak = 0; stkScore = 0; stkLast = millis();
}
static void stkUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (stkState) { if (btnPressed[BTN_SELECT]) stkStart(); return; }
  if (millis() - stkLast >= 20) {
    stkLast = millis();
    float v = 1.2f + stkScore * 0.07f; if (v > 3.6f) v = 3.6f;
    stkCx += stkDir * v;
    if (stkCx < 0) { stkCx = 0; stkDir = 1; }
    if (stkCx + stkCw > 128) { stkCx = 128 - stkCw; stkDir = -1; }
  }
  if (!btnPressed[BTN_SELECT]) return;
  int px = stkX[stkN - 1], pw = stkW[stkN - 1], x = (int)stkCx, w = (int)stkCw;
  int l = max(x, px), r = min(x + w, px + pw), ov = r - l;
  if (ov <= 0) { stkState = 1; if (stkScore > stkBest) stkBest = stkScore; saveAll(); return; }
  if (abs(x - px) <= 1) {                               // perfect drop
    l = px; ov = pw; stkStreak++;
    if (stkStreak >= 3 && ov < 56) { l -= 1; ov += 2; }
  } else stkStreak = 0;
  stkX[stkN] = l; stkW[stkN] = ov; stkN++; stkScore++;
  stkCw = ov; stkCx = stkDir > 0 ? 0 : 128 - ov;
  if (stkScore > stkBest) { stkBest = stkScore; dirty = true; }
  if (stkN >= STK_MAX) {                                // keep going: drop the oldest 20 levels
    memmove(stkX, stkX + 20, (STK_MAX - 20) * sizeof(int16_t));
    memmove(stkW, stkW + 20, (STK_MAX - 20) * sizeof(int16_t));
    stkN -= 20;
  }
}
static void stkDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  int base = stkN > 10 ? stkN - 10 : 0;
  for (int i = base; i < stkN; i++) display.fillRect(stkX[i], 58 - (i - base) * 4, stkW[i], 3, 1);
  if (stkState == 0) display.drawRect((int)stkCx, 58 - (stkN - base) * 4, (int)stkCw, 3, 1);
  display.setCursor(0, 0); display.print(stkScore);
  display.setCursor(70, 0); display.print(F("best ")); display.print(stkBest);
  if (stkStreak >= 3 && stkState == 0) { display.setCursor(0, 10); display.print(F("PERFECT x")); display.print(stkStreak); }
  if (stkState == 1) { display.fillRect(14, 22, 100, 24, 0); display.drawRect(14, 22, 100, 24, 1); display.setCursor(34, 26); display.print(F("TOWER FELL")); display.setCursor(22, 36); display.print(F("SELECT: retry")); }
  display.display();
}

// ================= ASTEROIDS =================
struct AstR { float x, y, vx, vy; uint8_t r; bool on; };
struct AstB { float x, y, vx, vy; uint8_t life; bool on; };
static AstR ar[14];
static AstB ab[4];
static float asx, asy, asvx, asvy, asa;
static int asLives, asWave, asState;                    // state: 0 run, 1 over
static uint32_t asScore;
static unsigned long asInv, asShot, asLast;
static float frand(float a, float b) { return a + (b - a) * (random(1000) / 1000.0f); }
static void asSpawnWave() {
  for (auto& a : ar) a.on = false;
  int n = 3 + asWave; if (n > 7) n = 7;
  for (int i = 0; i < n; i++) {
    float x, y;
    do { x = random(128); y = random(64); } while ((x - asx) * (x - asx) + (y - asy) * (y - asy) < 900);
    float ang = frand(0, 6.283f), sp = frand(0.3f, 0.8f) + asWave * 0.05f;
    ar[i].x = x; ar[i].y = y; ar[i].vx = cosf(ang) * sp; ar[i].vy = sinf(ang) * sp; ar[i].r = 8; ar[i].on = true;
  }
}
static void asStart() {
  asx = 64; asy = 32; asvx = asvy = 0; asa = -1.57f; asLives = 3; asWave = 1; asScore = 0; asState = 0;
  for (auto& b : ab) b.on = false;
  asSpawnWave(); asInv = millis() + 2000; asShot = 0; asLast = millis();
}
static void asSplit(const AstR& p, int nr) {
  for (int k = 0; k < 2; k++) {
    for (auto& a : ar) if (!a.on) {
      float ang = frand(0, 6.283f), sp = frand(0.5f, 1.2f);
      a.x = p.x; a.y = p.y; a.vx = p.vx * 0.5f + cosf(ang) * sp; a.vy = p.vy * 0.5f + sinf(ang) * sp; a.r = nr; a.on = true; break;
    }
  }
}
static void asUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (asState) { if (btnPressed[BTN_SELECT]) asStart(); return; }
  if (millis() - asLast < 30) return; asLast = millis();
  if (isHeld(BTN_LEFT))  asa -= 0.18f;
  if (isHeld(BTN_RIGHT)) asa += 0.18f;
  if (isHeld(BTN_UP)) {
    asvx += cosf(asa) * 0.14f; asvy += sinf(asa) * 0.14f;
    float sp = sqrtf(asvx * asvx + asvy * asvy); if (sp > 2.4f) { asvx *= 2.4f / sp; asvy *= 2.4f / sp; }
  }
  asvx *= 0.985f; asvy *= 0.985f; asx += asvx; asy += asvy;
  if (asx < 0) asx += 128; if (asx >= 128) asx -= 128; if (asy < 0) asy += 64; if (asy >= 64) asy -= 64;
  if (isHeld(BTN_SELECT) && millis() - asShot > 220) {
    asShot = millis();
    for (auto& b : ab) if (!b.on) { b.on = true; b.x = asx + cosf(asa) * 5; b.y = asy + sinf(asa) * 5; b.vx = cosf(asa) * 3.5f + asvx; b.vy = sinf(asa) * 3.5f + asvy; b.life = 30; break; }
  }
  for (auto& a : ar) {
    if (!a.on) continue;
    a.x += a.vx; a.y += a.vy;
    if (a.x < 0) a.x += 128; if (a.x >= 128) a.x -= 128; if (a.y < 0) a.y += 64; if (a.y >= 64) a.y -= 64;
  }
  for (auto& b : ab) {
    if (!b.on) continue;
    b.x += b.vx; b.y += b.vy;
    if (b.x < 0) b.x += 128; if (b.x >= 128) b.x -= 128; if (b.y < 0) b.y += 64; if (b.y >= 64) b.y -= 64;
    if (--b.life == 0) { b.on = false; continue; }
    for (auto& a : ar) {
      if (!a.on) continue;
      float dx = a.x - b.x, dy = a.y - b.y;
      if (dx * dx + dy * dy < (a.r + 1) * (a.r + 1)) {
        b.on = false; a.on = false;
        asScore += a.r == 8 ? 20 : a.r == 5 ? 50 : 100;
        if (a.r > 3) asSplit(a, a.r == 8 ? 5 : 3);
        break;
      }
    }
  }
  if (millis() > asInv) {
    for (auto& a : ar) {
      if (!a.on) continue;
      float dx = a.x - asx, dy = a.y - asy;
      if (dx * dx + dy * dy < (a.r + 2) * (a.r + 2)) {
        asLives--; asx = 64; asy = 32; asvx = asvy = 0; asInv = millis() + 2000;
        if (asLives <= 0) { asState = 1; if (asScore > astBest) astBest = asScore; saveAll(); }
        break;
      }
    }
  }
  bool any = false; for (auto& a : ar) if (a.on) any = true;
  if (!any && asState == 0) { asWave++; asSpawnWave(); asInv = millis() + 1500; }
}
static void asDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  for (auto& a : ar) if (a.on) display.drawCircle((int)a.x, (int)a.y, a.r, 1);
  for (auto& b : ab) if (b.on) { display.drawPixel((int)b.x, (int)b.y, 1); display.drawPixel((int)b.x + 1, (int)b.y, 1); }
  if (asState == 0 && (millis() > asInv || ((millis() / 100) & 1))) {
    int nx = asx + cosf(asa) * 5, ny = asy + sinf(asa) * 5;
    int lx = asx + cosf(asa + 2.5f) * 4, ly = asy + sinf(asa + 2.5f) * 4;
    int rx = asx + cosf(asa - 2.5f) * 4, ry = asy + sinf(asa - 2.5f) * 4;
    display.drawLine(nx, ny, lx, ly, 1); display.drawLine(nx, ny, rx, ry, 1); display.drawLine(lx, ly, rx, ry, 1);
  }
  display.setCursor(0, 0); display.print(asScore);
  display.setCursor(56, 0); display.print('W'); display.print(asWave);
  for (int i = 0; i < asLives; i++) display.fillTriangle(100 + i * 9, 6, 96 + i * 9, 0, 104 + i * 9, 0, 1);
  if (asState == 1) { display.fillRect(14, 20, 100, 28, 0); display.drawRect(14, 20, 100, 28, 1); display.setCursor(34, 24); display.print(F("GAME OVER")); display.setCursor(26, 34); display.print(F("best ")); display.print(astBest); display.setCursor(26, 40); display.print(F("SELECT: retry")); }
  display.display();
}

// ================= MINESWEEPER (hold SELECT = flag) =================
#define MN_W 16
#define MN_H 7
#define MN_M 14
static uint8_t mnMine[MN_H][MN_W], mnRev[MN_H][MN_W], mnFlag[MN_H][MN_W], mnAdj[MN_H][MN_W];
static int mnCx, mnCy, mnLeft, mnState, mnFlags;        // state: 0 ready, 1 playing, 2 lost, 3 won
static unsigned long mnT0, mnDown;
static bool mnHeldSel, mnLong;
static uint32_t mnTime;
static void mnStart() {
  memset(mnMine, 0, sizeof(mnMine)); memset(mnRev, 0, sizeof(mnRev)); memset(mnFlag, 0, sizeof(mnFlag)); memset(mnAdj, 0, sizeof(mnAdj));
  mnCx = 8; mnCy = 3; mnState = 0; mnFlags = 0; mnLeft = MN_W * MN_H - MN_M; mnHeldSel = false; mnLong = false; mnTime = 0;
}
static void mnPlace(int sr, int sc) {
  int placed = 0;
  while (placed < MN_M) {
    int r = random(MN_H), c = random(MN_W);
    if (mnMine[r][c] || (abs(r - sr) <= 1 && abs(c - sc) <= 1)) continue;
    mnMine[r][c] = 1; placed++;
  }
  for (int r = 0; r < MN_H; r++) for (int c = 0; c < MN_W; c++) {
    int n = 0;
    for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
      int nr = r + dr, nc = c + dc;
      if ((dr || dc) && nr >= 0 && nr < MN_H && nc >= 0 && nc < MN_W && mnMine[nr][nc]) n++;
    }
    mnAdj[r][c] = n;
  }
  mnT0 = millis(); mnState = 1;
}
static void mnReveal(int r, int c) {
  if (mnRev[r][c] || mnFlag[r][c]) return;
  int st[MN_W * MN_H][2], sp = 0;
  mnRev[r][c] = 1; st[sp][0] = r; st[sp][1] = c; sp++;
  while (sp) {
    sp--; int rr = st[sp][0], cc = st[sp][1];
    if (mnMine[rr][cc]) { mnState = 2; continue; }
    mnLeft--;
    if (mnAdj[rr][cc] == 0) {
      for (int dr = -1; dr <= 1; dr++) for (int dc = -1; dc <= 1; dc++) {
        int nr = rr + dr, nc = cc + dc;
        if (nr < 0 || nr >= MN_H || nc < 0 || nc >= MN_W || mnRev[nr][nc] || mnFlag[nr][nc]) continue;
        mnRev[nr][nc] = 1; st[sp][0] = nr; st[sp][1] = nc; sp++;
      }
    }
  }
  if (mnState == 1 && mnLeft == 0) {
    mnState = 3; mnTime = (millis() - mnT0) / 1000;
    if (mnBest == 0 || mnTime < mnBest) mnBest = mnTime;
    saveAll();
  }
}
static void mnToggleFlag() {
  if (mnRev[mnCy][mnCx]) return;
  if (mnFlag[mnCy][mnCx]) { mnFlag[mnCy][mnCx] = 0; mnFlags--; } else { mnFlag[mnCy][mnCx] = 1; mnFlags++; }
}
static void mnUpdate() {
  if (backPressed()) { saveAll(); sub = S_MENU; return; }
  if (mnState >= 2) { if (btnPressed[BTN_SELECT]) mnStart(); return; }
  if (btnPressed[BTN_UP] && mnCy > 0) mnCy--;
  if (btnPressed[BTN_DOWN] && mnCy < MN_H - 1) mnCy++;
  if (btnPressed[BTN_LEFT] && mnCx > 0) mnCx--;
  if (btnPressed[BTN_RIGHT] && mnCx < MN_W - 1) mnCx++;
  if (btnPressed[BTN_SELECT]) { mnDown = millis(); mnHeldSel = true; mnLong = false; }
  if (mnHeldSel) {
    if (isHeld(BTN_SELECT)) {
      if (!mnLong && millis() - mnDown > 350) { mnLong = true; mnToggleFlag(); }
    } else {
      mnHeldSel = false;
      if (!mnLong) { if (mnState == 0) mnPlace(mnCy, mnCx); mnReveal(mnCy, mnCx); }
    }
  }
}
static void mnDraw() {
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1);
  display.setCursor(0, 0);
  if (mnState == 2) display.print(F("BOOM!  SELECT=retry"));
  else if (mnState == 3) { display.print(F("CLEARED ")); display.print(mnTime); display.print(F("s best ")); display.print(mnBest); }
  else {
    display.print(F("M:")); display.print(MN_M - mnFlags);
    display.print(F(" T:")); display.print(mnState == 1 ? (millis() - mnT0) / 1000 : 0);
    display.print(F(" B:")); if (mnBest) display.print(mnBest); else display.print('-');
  }
  for (int r = 0; r < MN_H; r++) for (int c = 0; c < MN_W; c++) {
    int x = c * 8, y = 8 + r * 8;
    if (!mnRev[r][c]) {
      if (mnState == 2 && mnMine[r][c]) { display.fillCircle(x + 3, y + 3, 2, 1); display.drawPixel(x + 3, y + 3, 0); }
      else {
        display.fillRect(x, y, 7, 7, 1);
        if (mnFlag[r][c]) { display.fillTriangle(x + 2, y + 1, x + 5, y + 3, x + 2, y + 5, 0); display.drawLine(x + 2, y + 1, x + 2, y + 6, 0); }
      }
    } else if (mnAdj[r][c]) { display.setCursor(x + 1, y); display.print((int)mnAdj[r][c]); }
  }
  if (mnState < 2) {
    int x = mnCx * 8, y = 8 + mnCy * 8;
    if (!mnRev[mnCy][mnCx]) display.fillRect(x + 2, y + 2, 3, 3, 0); else display.drawRect(x, y, 7, 7, 1);
  }
  display.display();
}

// ================= MENU =================
#define BP_N 10
static void menuUpdate() {
  if (checkExitToMenu()) { resetArm = false; return; }
  if (btnPressed[BTN_UP])   { cur = (cur + BP_N - 1) % BP_N; resetArm = false; }
  if (btnPressed[BTN_DOWN]) { cur = (cur + 1) % BP_N; resetArm = false; }
  if (!btnPressed[BTN_SELECT]) return;
  switch (cur) {
    case 0: gdBuild(); gdStart(); sub = S_GD; break;
    case 1: clkLastAuto = clkLastSave = millis(); sub = S_CLK; break;
    case 2: simStart(); sub = S_SIM; break;
    case 3: dgStart(); sub = S_DGE; break;
    case 4: rctState = 0; sub = S_RCT; break;
    case 5: t48Start(); sub = S_2048; break;
    case 6: stkStart(); sub = S_STK; break;
    case 7: asStart(); sub = S_AST; break;
    case 8: mnStart(); sub = S_MIN; break;
    default: if (!resetArm) resetArm = true; else { wipeAll(); resetArm = false; }
  }
}
static void menuDraw() {
  display.clearDisplay(); display.setTextColor(1); display.setTextSize(1);
  display.setCursor(30, 0); display.print(F("BONUS PACK")); display.drawFastHLine(0, 9, 128, 1);
  char b[BP_N][26];
  snprintf(b[0], 26, "GD Dash  %u%%", (unsigned)gdBest);
  snprintf(b[1], 26, "Clicker  $%u", (unsigned)clkCoins);
  snprintf(b[2], 26, "Simon    best %u", (unsigned)simBest);
  snprintf(b[3], 26, "Dodge    best %u", (unsigned)dgeBest);
  snprintf(b[4], 26, "Reaction %ums", (unsigned)rctBest);
  snprintf(b[5], 26, "2048     best %u", (unsigned)best48);
  snprintf(b[6], 26, "Stack    best %u", (unsigned)stkBest);
  snprintf(b[7], 26, "Asteroid best %u", (unsigned)astBest);
  snprintf(b[8], 26, "Mines    best %us", (unsigned)mnBest);
  snprintf(b[9], 26, resetArm ? "Press again: WIPE!" : "Reset saves");
  int sc = cur > 3 ? cur - 3 : 0;
  for (int i = 0; i < 4; i++) { display.setCursor(2, 13 + i * 10); display.print(sc + i == cur ? "> " : "  "); display.print(b[sc + i]); }
  display.setCursor(2, 56); display.print(F("SELECT:open BACK:exit"));
  display.display();
}

// ================= HOOKS FOR minigame.ino =================
void customReset() { loadAll(); sub = S_MENU; cur = 0; resetArm = false; }
void customUpdate() {
  switch (sub) {
    case S_MENU: menuUpdate(); break; case S_GD: gdUpdate(); break; case S_CLK: clkUpdate(); break;
    case S_SIM: simUpdate(); break;   case S_DGE: dgUpdate(); break; case S_RCT: rctUpdate(); break;
    case S_2048: t48Update(); break;  case S_STK: stkUpdate(); break; case S_AST: asUpdate(); break;
    case S_MIN: mnUpdate(); break;
  }
}
void customDraw() {
  switch (sub) {
    case S_MENU: menuDraw(); break; case S_GD: gdDraw(); break; case S_CLK: clkDraw(); break;
    case S_SIM: simDraw(); break;   case S_DGE: dgDraw(); break; case S_RCT: rctDraw(); break;
    case S_2048: t48Draw(); break;  case S_STK: stkDraw(); break; case S_AST: asDraw(); break;
    case S_MIN: mnDraw(); break;
  }
}