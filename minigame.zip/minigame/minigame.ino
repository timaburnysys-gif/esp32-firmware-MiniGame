#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Preferences.h>
#include <WiFi.h>
#include <WebServer.h>
#include <LittleFS.h>
#include <Update.h>

extern const char* CUSTOM_GAME_NAME;
extern void customReset();
extern void customUpdate();
extern void customDraw();

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

#define PIN_UP 18
#define PIN_DOWN 10
#define PIN_LEFT 15
#define PIN_RIGHT 12
#define PIN_SELECT 2
#define PIN_BOOT 0
#define PIN_BACK 40

const int BTN_PINS[7] = {PIN_UP, PIN_DOWN, PIN_LEFT, PIN_RIGHT, PIN_SELECT, PIN_BOOT, PIN_BACK};
bool btnLast[7] = {HIGH,HIGH,HIGH,HIGH,HIGH,HIGH,HIGH};
bool btnStable[7] = {HIGH,HIGH,HIGH,HIGH,HIGH,HIGH,HIGH};
unsigned long btnLastChange[7] = {0,0,0,0,0,0,0};
bool btnPressed[7];
const unsigned long DEBOUNCE_MS = 30;

#define BTN_UP 0
#define BTN_DOWN 1
#define BTN_LEFT 2
#define BTN_RIGHT 3
#define BTN_SELECT 4
#define BTN_BOOT 5
#define BTN_BACK 6

void updateButtons() {
  unsigned long now = millis();
  for (int i = 0; i < 7; i++) {
    bool cur = digitalRead(BTN_PINS[i]);
    btnPressed[i] = false;
    if (cur != btnLast[i]) { btnLastChange[i] = now; btnLast[i] = cur; }
    if ((now - btnLastChange[i]) > DEBOUNCE_MS) {
      if (cur != btnStable[i]) { btnStable[i] = cur; if (cur == LOW) btnPressed[i] = true; }
    }
  }
}
bool isHeld(int idx) { return btnStable[idx] == LOW; }
bool anyButtonPressed() { for (int i=0;i<7;i++) if (btnPressed[i]) return true; return false; }

Preferences prefs;
int difficulty = 1;
const char* diffNames[3] = {"Easy","Normal","Hard"};
float diffLerp(float e,float n,float h){ if(difficulty==0)return e; if(difficulty==2)return h; return n; }
void loadSettings(){ prefs.begin("minigame",true); difficulty=prefs.getInt("diff",1); prefs.end(); }
void saveSettings(){ prefs.begin("minigame",false); prefs.putInt("diff",difficulty); prefs.end(); }

#define BD_MAP_SIZE 10
uint8_t *bd_map = nullptr;
const uint8_t BD_MAP_DEFAULT[BD_MAP_SIZE][BD_MAP_SIZE] = {
  {1,1,1,1,1,1,1,1,1,1},{1,0,0,0,0,0,0,0,0,1},{1,0,1,1,0,1,1,0,0,1},
  {1,0,1,0,0,0,1,0,1,1},{1,0,0,0,1,0,0,0,0,1},{1,1,0,1,1,0,1,1,0,1},
  {1,0,0,0,0,0,1,0,0,1},{1,0,1,1,0,1,1,0,1,1},{1,0,0,0,0,0,0,0,0,1},
  {1,1,1,1,1,1,1,1,1,1}
};
bool bdIsWall(float x,float y){int ix=(int)x,iy=(int)y; if(ix<0||ix>=BD_MAP_SIZE||iy<0||iy>=BD_MAP_SIZE)return true; return bd_map[iy*BD_MAP_SIZE+ix]==1;}
void initPsramMap(){
  size_t bytes=BD_MAP_SIZE*BD_MAP_SIZE;
  if(psramFound()){ bd_map=(uint8_t*)ps_malloc(bytes); Serial.println(F("PSRAM found")); }
  else { bd_map=(uint8_t*)malloc(bytes); Serial.println(F("No PSRAM")); }
  for(int y=0;y<BD_MAP_SIZE;y++) for(int x=0;x<BD_MAP_SIZE;x++) bd_map[y*BD_MAP_SIZE+x]=BD_MAP_DEFAULT[y][x];
}

enum Mode { MODE_SPLASH, MODE_MENU, MODE_SETTINGS, MODE_GAME, MODE_GAMEOVER, MODE_BIN_SERVER, MODE_OTA_PREPARE, MODE_OTA_UPDATING, MODE_FORMAT_CONFIRM };
Mode mode = MODE_SPLASH;
int currentGame = 0;
int lastScore = 0;

#define GAME_COUNT 16
const char* gameNames[GAME_COUNT] = {
  "Flappy Bird","Snake","Pong vs AI","Dino Run","Tetris","Space Invaders",
  "Breakout","Pac-Man","Monster Hunt 3D","Bot Duel 3D","3D FPS Test",
  "Custom","Bin: Upload","Bin: Play","Gallery","EspBench"
};
const char* menuTags[GAME_COUNT] = {
  "2D","2D","2D","2D","2D","2D","2D","2D","3D","3D","3D","2D","SYS","SYS","MEDIA","SYS"
};
#define MENU_ITEMS (GAME_COUNT + 1)
int menuIndex = 0;
unsigned long splashStart = 0;
const unsigned long SPLASH_DURATION = 2000;

void startGame(int idx);
bool checkExitToMenu(){ if(btnPressed[BTN_BOOT]||btnPressed[BTN_BACK]){mode=MODE_MENU;return true;} return false; }

// ================= PNG + MEDIA DIRS =================
#define GALLERY_DIR "/gallery"
#define VIDEO_DIR "/video"

uint32_t png_crcTable[256]; bool png_crcTableReady=false;
void pngBuildCrcTable(){ for(uint32_t n=0;n<256;n++){uint32_t c=n; for(int k=0;k<8;k++) c=(c&1)?(0xEDB88320^(c>>1)):(c>>1); png_crcTable[n]=c;} png_crcTableReady=true; }
uint32_t pngCrc32(const uint8_t* buf,size_t len){ if(!png_crcTableReady)pngBuildCrcTable(); uint32_t c=0xFFFFFFFF; for(size_t i=0;i<len;i++) c=png_crcTable[(c^buf[i])&0xFF]^(c>>8); return c^0xFFFFFFFF; }
uint32_t pngAdler32(const uint8_t* buf,size_t len){ uint32_t a=1,b=0; for(size_t i=0;i<len;i++){a=(a+buf[i])%65521;b=(b+a)%65521;} return (b<<16)|a; }
void pngWriteBE32(uint8_t* out,uint32_t v){ out[0]=(v>>24)&0xFF;out[1]=(v>>16)&0xFF;out[2]=(v>>8)&0xFF;out[3]=v&0xFF; }
void pngWriteChunk(File &f,const char* type,const uint8_t* data,uint32_t len){
  uint8_t lenBuf[4]; pngWriteBE32(lenBuf,len); f.write(lenBuf,4); f.write((const uint8_t*)type,4);
  if(len>0) f.write(data,len);
  uint8_t* crcBuf=(uint8_t*)malloc(4+len); memcpy(crcBuf,type,4); if(len>0)memcpy(crcBuf+4,data,len);
  uint32_t crc=pngCrc32(crcBuf,4+len); free(crcBuf);
  uint8_t crcOut[4]; pngWriteBE32(crcOut,crc); f.write(crcOut,4);
}
bool getBufferPixel(uint8_t* buf,int x,int y){ int idx=x+(y/8)*SCREEN_WIDTH; return (buf[idx]>>(y&7))&1; }

bool savePngFromBuffer(uint8_t* srcBuf,const char* path){
  const int w=SCREEN_WIDTH,h=SCREEN_HEIGHT; const int rowBytes=(w+7)/8; const int rawLen=h*(1+rowBytes);
  uint8_t* raw=psramFound()?(uint8_t*)ps_malloc(rawLen):(uint8_t*)malloc(rawLen);
  if(!raw) return false;
  for(int y=0;y<h;y++){ int rowOff=y*(1+rowBytes); raw[rowOff]=0;
    for(int i=0;i<rowBytes;i++) raw[rowOff+1+i]=0;
    for(int x=0;x<w;x++) if(getBufferPixel(srcBuf,x,y)) raw[rowOff+1+x/8]|=(1<<(7-(x%8))); }
  int zlibLen=2+5+rawLen+4;
  uint8_t* zbuf=psramFound()?(uint8_t*)ps_malloc(zlibLen):(uint8_t*)malloc(zlibLen);
  if(!zbuf){free(raw);return false;}
  int p=0; zbuf[p++]=0x78; zbuf[p++]=0x01; zbuf[p++]=0x01;
  zbuf[p++]=rawLen&0xFF; zbuf[p++]=(rawLen>>8)&0xFF;
  uint16_t nlen=~rawLen; zbuf[p++]=nlen&0xFF; zbuf[p++]=(nlen>>8)&0xFF;
  memcpy(zbuf+p,raw,rawLen); p+=rawLen;
  pngWriteBE32(zbuf+p,pngAdler32(raw,rawLen)); p+=4;
  free(raw);
  File f=LittleFS.open(path,"w"); if(!f){free(zbuf);return false;}
  const uint8_t sig[8]={137,80,78,71,13,10,26,10}; f.write(sig,8);
  uint8_t ihdr[13]; pngWriteBE32(ihdr,w); pngWriteBE32(ihdr+4,h);
  ihdr[8]=1;ihdr[9]=0;ihdr[10]=0;ihdr[11]=0;ihdr[12]=0;
  pngWriteChunk(f,"IHDR",ihdr,13); pngWriteChunk(f,"IDAT",zbuf,zlibLen); pngWriteChunk(f,"IEND",nullptr,0);
  f.close(); free(zbuf); return true;
}

bool loadPngToBuffer(const char* path,uint8_t* destBuf){
  File f=LittleFS.open(path,"r"); if(!f) return false;
  uint8_t sig[8]; f.read(sig,8);
  uint8_t* idatData=nullptr; uint32_t imgW=0,imgH=0;
  while(f.available()){
    uint8_t lenBuf[4]; if(f.read(lenBuf,4)!=4) break;
    uint32_t len=(lenBuf[0]<<24)|(lenBuf[1]<<16)|(lenBuf[2]<<8)|lenBuf[3];
    char type[5]={0}; f.read((uint8_t*)type,4);
    if(strcmp(type,"IHDR")==0){ uint8_t ihdr[13]; f.read(ihdr,13);
      imgW=(ihdr[0]<<24)|(ihdr[1]<<16)|(ihdr[2]<<8)|ihdr[3]; imgH=(ihdr[4]<<24)|(ihdr[5]<<16)|(ihdr[6]<<8)|ihdr[7];
      f.seek(f.position()+4);
    } else if(strcmp(type,"IDAT")==0){
      idatData=psramFound()?(uint8_t*)ps_malloc(len):(uint8_t*)malloc(len);
      if(!idatData){f.close();return false;} f.read(idatData,len); f.seek(f.position()+4);
    } else { f.seek(f.position()+len+4); }
    if(strcmp(type,"IEND")==0) break;
  }
  f.close();
  if(!idatData||imgW==0){ if(idatData)free(idatData); return false; }
  uint8_t* raw=idatData+2+5; int rowBytes=(imgW+7)/8;
  for(uint32_t y=0;y<imgH&&y<(uint32_t)SCREEN_HEIGHT;y++){
    const uint8_t* rowData=raw+y*(1+rowBytes)+1;
    for(uint32_t x=0;x<imgW&&x<(uint32_t)SCREEN_WIDTH;x++){
      bool on=(rowData[x/8]>>(7-(x%8)))&1; int idx=x+(y/8)*SCREEN_WIDTH;
      if(on) destBuf[idx]|=(1<<(y&7)); else destBuf[idx]&=~(1<<(y&7));
    }
  }
  free(idatData); return true;
}

int galleryNextIndex(const char* dirPath,const char* prefix){
  if(!LittleFS.exists(dirPath)) LittleFS.mkdir(dirPath);
  int maxIdx=0; File dir=LittleFS.open(dirPath); File entry=dir.openNextFile();
  while(entry){ String name=entry.name(); int us=name.lastIndexOf('_'); int dot=name.lastIndexOf('.');
    if(us>=0&&dot>us){ int idx=name.substring(us+1,dot).toInt(); if(idx>maxIdx)maxIdx=idx; }
    entry=dir.openNextFile(); }
  return maxIdx+1;
}

void captureScreenshot(){
  int idx=galleryNextIndex(GALLERY_DIR,"shot");
  char path[48]; snprintf(path,sizeof(path),"%s/shot_%04d.png",GALLERY_DIR,idx);
  bool ok=savePngFromBuffer(display.getBuffer(),path);
  display.fillRect(0,SCREEN_HEIGHT-10,SCREEN_WIDTH,10,SSD1306_BLACK);
  display.setCursor(2,SCREEN_HEIGHT-9); display.print(ok?F("Saved!"):F("Save failed"));
  display.display(); delay(400);
}

// ================= VIDEO RECORDING =================
#define VID_MAX_FRAMES 40
#define VID_FRAME_INTERVAL 250
bool vid_recording=false;
File vid_file;
int vid_frameCount=0;
unsigned long vid_lastFrameTime=0;
String vid_currentPath;

void vidStartRecording(){
  if(!LittleFS.exists(VIDEO_DIR)) LittleFS.mkdir(VIDEO_DIR);
  int idx=galleryNextIndex(VIDEO_DIR,"vid");
  char path[48]; snprintf(path,sizeof(path),"%s/vid_%04d.mgv",VIDEO_DIR,idx);
  vid_currentPath=String(path);
  vid_file=LittleFS.open(path,"w");
  if(!vid_file) return;
  uint8_t header[8]={'M','G','V','D',SCREEN_WIDTH&0xFF,(SCREEN_WIDTH>>8)&0xFF,SCREEN_HEIGHT&0xFF,0};
  vid_file.write(header,8);
  vid_frameCount=0; vid_recording=true; vid_lastFrameTime=millis();
}
void vidStopRecording(){
  if(vid_file){ vid_file.seek(0);
    uint8_t header[8]={'M','G','V','D',SCREEN_WIDTH&0xFF,(SCREEN_WIDTH>>8)&0xFF,SCREEN_HEIGHT&0xFF,(uint8_t)vid_frameCount};
    vid_file.write(header,8); vid_file.close(); }
  vid_recording=false;
}
void vidCaptureFrameIfDue(){
  if(!vid_recording) return;
  if(millis()-vid_lastFrameTime < VID_FRAME_INTERVAL) return;
  vid_lastFrameTime=millis();
  vid_file.write(display.getBuffer(), SCREEN_WIDTH*SCREEN_HEIGHT/8);
  vid_frameCount++;
  if(vid_frameCount>=VID_MAX_FRAMES) vidStopRecording();
}
void vidToggleRecording(){ if(vid_recording) vidStopRecording(); else vidStartRecording(); }

// ================= GALLERY APP (photos+videos) =================
#define GALLERY_MAX_FILES 64
struct MediaItem { String path; bool isVideo; };
MediaItem gallery_items[GALLERY_MAX_FILES];
int gallery_count;
int gallery_index;
bool gallery_viewing;
uint8_t* gallery_viewBuf=nullptr;
File gallery_vidFile;
int gallery_vidFrames=0, gallery_vidCurFrame=0;
unsigned long gallery_vidLastFrame=0;

void galleryScanDir(const char* dirPath,bool isVideo){
  if(!LittleFS.exists(dirPath)) return;
  File dir=LittleFS.open(dirPath); File entry=dir.openNextFile();
  while(entry && gallery_count<GALLERY_MAX_FILES){
    gallery_items[gallery_count].path=String(entry.name());
    gallery_items[gallery_count].isVideo=isVideo;
    gallery_count++; entry=dir.openNextFile();
  }
}

void galleryReset(){
  gallery_count=0; gallery_index=0; gallery_viewing=false;
  if(!LittleFS.exists(GALLERY_DIR)) LittleFS.mkdir(GALLERY_DIR);
  if(!LittleFS.exists(VIDEO_DIR)) LittleFS.mkdir(VIDEO_DIR);
  galleryScanDir(GALLERY_DIR,false);
  galleryScanDir(VIDEO_DIR,true);
  if(!gallery_viewBuf){ int bufSize=SCREEN_WIDTH*SCREEN_HEIGHT/8;
    gallery_viewBuf=psramFound()?(uint8_t*)ps_malloc(bufSize):(uint8_t*)malloc(bufSize); }
}

void galleryStartVideoPlayback(){
  gallery_vidFile=LittleFS.open(gallery_items[gallery_index].path.c_str(),"r");
  if(!gallery_vidFile) return;
  uint8_t header[8]; gallery_vidFile.read(header,8);
  gallery_vidFrames=header[7]; gallery_vidCurFrame=0; gallery_vidLastFrame=millis();
}

void galleryUpdate(){
  if(checkExitToMenu()) return;
  if(gallery_viewing){
    if(gallery_count>0 && gallery_items[gallery_index].isVideo && gallery_vidFile){
      if(millis()-gallery_vidLastFrame>=VID_FRAME_INTERVAL){
        gallery_vidLastFrame=millis();
        if(gallery_vidCurFrame<gallery_vidFrames){
          gallery_vidFile.read(gallery_viewBuf,SCREEN_WIDTH*SCREEN_HEIGHT/8);
          gallery_vidCurFrame++;
        } else {
          gallery_vidFile.seek(8); gallery_vidCurFrame=0;
        }
      }
    }
    if(btnPressed[BTN_SELECT]){ if(gallery_vidFile) gallery_vidFile.close(); gallery_viewing=false; }
    return;
  }
  if(gallery_count==0) return;
  if(btnPressed[BTN_UP]) gallery_index=(gallery_index+gallery_count-1)%gallery_count;
  if(btnPressed[BTN_DOWN]) gallery_index=(gallery_index+1)%gallery_count;
  if(btnPressed[BTN_SELECT]){
    if(gallery_items[gallery_index].isVideo){ galleryStartVideoPlayback(); gallery_viewing=true; }
    else if(loadPngToBuffer(gallery_items[gallery_index].path.c_str(),gallery_viewBuf)) gallery_viewing=true;
  }
}

void galleryDraw(){
  display.clearDisplay();
  if(gallery_viewing){
    memcpy(display.getBuffer(),gallery_viewBuf,SCREEN_WIDTH*SCREEN_HEIGHT/8);
    display.fillRect(0,0,SCREEN_WIDTH,9,SSD1306_BLACK);
    display.setCursor(2,1);
    String full=gallery_items[gallery_index].path;
    int slash=full.lastIndexOf('/');
    display.print(slash>=0?full.substring(slash+1):full);
    display.display(); return;
  }
  display.setTextSize(1); display.setCursor(20,0); display.print(F("GALLERY"));
  display.drawFastHLine(0,9,SCREEN_WIDTH,SSD1306_WHITE);
  if(gallery_count==0){ display.setCursor(10,28); display.print(F("No media yet")); }
  else {
    display.setCursor(2,14); display.print(gallery_index+1); display.print(F(" / ")); display.print(gallery_count);
    String full=gallery_items[gallery_index].path; int slash=full.lastIndexOf('/');
    display.setCursor(2,26); display.print(slash>=0?full.substring(slash+1):full);
    display.setCursor(2,36); display.print(gallery_items[gallery_index].isVideo?F("[VIDEO]"):F("[PHOTO]"));
    display.setCursor(2,46); display.print(F("SELECT: view"));
  }
  display.setCursor(0,56); display.print(F("BOOT/BACK: exit"));
  display.display();
}

// ================= ESPBENCH =================
enum BenchStage { BENCH_IDLE, BENCH_CPU, BENCH_MEM, BENCH_PSRAM, BENCH_FLASH, BENCH_DONE };
BenchStage bench_stage=BENCH_IDLE;
long bench_cpuScore=0,bench_memScore=0,bench_psramScore=0,bench_flashScore=0;
void benchReset(){ bench_stage=BENCH_IDLE; bench_cpuScore=bench_memScore=bench_psramScore=bench_flashScore=0; }
long benchRunCpuLoop(unsigned long durMs){ unsigned long start=millis(); long counter=0; volatile float x=1.0001f;
  while(millis()-start<durMs){ for(int i=0;i<1000;i++){ x=x*1.0000001f+0.0000001f; counter++; } } return counter; }
long benchRunMemTest(unsigned long durMs){ unsigned long start=millis(); long counter=0; const int bufSize=4096;
  uint8_t* buf=(uint8_t*)malloc(bufSize); if(!buf)return 0;
  while(millis()-start<durMs){ for(int i=0;i<bufSize;i++) buf[i]=(uint8_t)(i^counter); counter++; } free(buf); return counter; }
long benchRunPsramTest(unsigned long durMs){ if(!psramFound())return -1; unsigned long start=millis(); long counter=0; const int bufSize=65536;
  uint8_t* buf=(uint8_t*)ps_malloc(bufSize); if(!buf)return 0;
  while(millis()-start<durMs){ for(int i=0;i<bufSize;i+=64) buf[i]=(uint8_t)(i^counter); counter++; } free(buf); return counter; }
long benchRunFlashTest(unsigned long durMs){ unsigned long start=millis(); long counter=0; const char* tp="/bench_tmp.bin";
  const int chunkSize=512; uint8_t chunk[chunkSize]; for(int i=0;i<chunkSize;i++) chunk[i]=i&0xFF;
  while(millis()-start<durMs){ File f=LittleFS.open(tp,"w"); if(!f)break; f.write(chunk,chunkSize); f.close(); counter++; }
  LittleFS.remove(tp); return counter; }
void benchUpdate(){
  if(checkExitToMenu()) return;
  if(bench_stage==BENCH_IDLE){ if(btnPressed[BTN_SELECT]) bench_stage=BENCH_CPU; return; }
  if(bench_stage==BENCH_DONE){ if(btnPressed[BTN_SELECT]) benchReset(); return; }
  switch(bench_stage){
    case BENCH_CPU: bench_cpuScore=benchRunCpuLoop(1000); bench_stage=BENCH_MEM; break;
    case BENCH_MEM: bench_memScore=benchRunMemTest(1000); bench_stage=BENCH_PSRAM; break;
    case BENCH_PSRAM: bench_psramScore=benchRunPsramTest(1000); bench_stage=BENCH_FLASH; break;
    case BENCH_FLASH: bench_flashScore=benchRunFlashTest(800); bench_stage=BENCH_DONE; break;
    default: break;
  }
}
void benchDraw(){
  display.clearDisplay(); display.setTextSize(1); display.setCursor(25,0); display.print(F("ESPBENCH"));
  display.drawFastHLine(0,9,SCREEN_WIDTH,SSD1306_WHITE);
  if(bench_stage==BENCH_IDLE){ display.setCursor(5,20); display.print(F("Press SELECT to run"));
    display.setCursor(5,32); display.print(F("CPU/RAM/PSRAM/Flash")); }
  else if(bench_stage==BENCH_DONE){
    display.setCursor(2,12); display.print(F("CPU:   ")); display.print(bench_cpuScore);
    display.setCursor(2,22); display.print(F("RAM:   ")); display.print(bench_memScore);
    display.setCursor(2,32); display.print(F("PSRAM: ")); if(bench_psramScore<0)display.print(F("N/A")); else display.print(bench_psramScore);
    display.setCursor(2,42); display.print(F("Flash: ")); display.print(bench_flashScore);
    display.setCursor(2,54); display.print(F("SELECT: run again"));
  } else {
    display.setCursor(10,25); display.print(F("Running..."));
  }
  display.setCursor(0,56); display.print(F("BOOT/BACK: exit"));
  display.display();
}

// ================= SPLASH =================
void drawGamepadIcon(int cx,int cy){
  display.fillRoundRect(cx-24,cy-10,48,22,6,SSD1306_WHITE);
  int dx=cx-15,dy=cy;
  display.fillRect(dx-1,dy-4,3,9,SSD1306_BLACK); display.fillRect(dx-4,dy-1,9,3,SSD1306_BLACK);
  display.fillCircle(cx+12,cy-3,2,SSD1306_BLACK); display.fillCircle(cx+18,cy+2,2,SSD1306_BLACK);
}
void drawSplash(){
  display.clearDisplay(); drawGamepadIcon(SCREEN_WIDTH/2,24);
  display.setTextSize(2); int16_t x1,y1; uint16_t w,h;
  display.getTextBounds("MiniGame",0,0,&x1,&y1,&w,&h);
  display.setCursor((SCREEN_WIDTH-w)/2,44); display.println(F("MiniGame")); display.display();
}
void updateSplash(){ drawSplash(); if(millis()-splashStart>SPLASH_DURATION||anyButtonPressed()) mode=MODE_MENU; }

// ================= МЕНЮ =================
float menu_highlightY=11, menu_targetY=11; unsigned long menu_lastAnimFrame=0;
void drawMenu(){
  display.clearDisplay(); display.setTextSize(1); display.setCursor(38,0); display.print(F("MiniGame"));
  display.drawFastHLine(0,9,SCREEN_WIDTH,SSD1306_WHITE);
  int visible=4,scroll=0;
  if(menuIndex>=visible) scroll=menuIndex-visible+1;
  if(scroll>MENU_ITEMS-visible) scroll=MENU_ITEMS-visible; if(scroll<0)scroll=0;
  int rowH=10,listTop=12;
  menu_targetY=listTop+(menuIndex-scroll)*rowH;
  if(millis()-menu_lastAnimFrame>10){ menu_lastAnimFrame=millis();
    float diff=menu_targetY-menu_highlightY;
    if(fabs(diff)<0.5) menu_highlightY=menu_targetY; else menu_highlightY+=diff*0.45; }
  display.fillRoundRect(2,(int)menu_highlightY,SCREEN_WIDTH-4,rowH-1,2,SSD1306_WHITE);
  for(int i=0;i<visible&&(scroll+i)<MENU_ITEMS;i++){
    int idx=scroll+i, rowY=listTop+i*rowH; bool sel=(idx==menuIndex);
    display.setCursor(8,rowY+1);
    const char* label; const char* tag;
    if(idx<GAME_COUNT){ label=(idx==11)?CUSTOM_GAME_NAME:gameNames[idx]; tag=menuTags[idx]; }
    else { label="Settings"; tag="SYS"; }
    if(sel){ display.setTextColor(SSD1306_BLACK); display.print(label);
      display.setCursor(SCREEN_WIDTH-24,rowY+1); display.print(tag); display.setTextColor(SSD1306_WHITE); }
    else { display.print(label);
      display.setCursor(SCREEN_WIDTH-24,rowY+1); display.print(tag); }
  }
  if(MENU_ITEMS>visible){
    int barH=SCREEN_HEIGHT-12-8, thumbH=barH*visible/MENU_ITEMS; if(thumbH<4)thumbH=4;
    int thumbY=12+(barH-thumbH)*scroll/(MENU_ITEMS-visible);
    display.drawFastVLine(SCREEN_WIDTH-2,12,barH,SSD1306_WHITE);
    display.fillRect(SCREEN_WIDTH-3,thumbY,2,thumbH,SSD1306_WHITE);
  }
  display.drawFastHLine(0,55,SCREEN_WIDTH,SSD1306_WHITE);
  display.setCursor(2,56); display.print(F("BOOT/BACK: exit"));
  display.display();
}
void updateMenu(){
  if(btnPressed[BTN_UP]) menuIndex=(menuIndex+MENU_ITEMS-1)%MENU_ITEMS;
  if(btnPressed[BTN_DOWN]) menuIndex=(menuIndex+1)%MENU_ITEMS;
  if(btnPressed[BTN_SELECT]){ if(menuIndex<GAME_COUNT) startGame(menuIndex); else mode=MODE_SETTINGS; }
  drawMenu();
}

// ================= SETTINGS =================
int settings_cursor=0;
void drawSettings(){
  display.clearDisplay(); display.setTextSize(1); display.setCursor(28,0); display.println(F("SETTINGS"));
  display.setCursor(10,18); display.print(settings_cursor==0?"> ":"  ");
  display.print(F("Difficulty: ")); display.println(diffNames[difficulty]);
  display.setCursor(10,30); display.print(settings_cursor==1?"> ":"  ");
  display.println(F("Format storage"));
  display.setCursor(4,46); display.println(F("UP/DOWN:select item"));
  display.setCursor(4,56); display.println(F("BOOT/BACK: exit"));
  display.display();
}
void updateSettings(){
  if(btnPressed[BTN_UP]) settings_cursor=(settings_cursor+1)%2;
  if(btnPressed[BTN_DOWN]) settings_cursor=(settings_cursor+1)%2;
  if(settings_cursor==0){
    if(btnPressed[BTN_LEFT]) difficulty=(difficulty+2)%3;
    if(btnPressed[BTN_RIGHT]) difficulty=(difficulty+1)%3;
  }
  if(btnPressed[BTN_SELECT]){
    if(settings_cursor==0){ saveSettings(); mode=MODE_MENU; }
    else { mode=MODE_FORMAT_CONFIRM; }
  }
  if(btnPressed[BTN_BOOT]||btnPressed[BTN_BACK]){ saveSettings(); mode=MODE_MENU; }
  drawSettings();
}

void formatDeleteDir(const char* dirPath){
  if(!LittleFS.exists(dirPath)) return;
  File dir=LittleFS.open(dirPath); File entry=dir.openNextFile();
  while(entry){ String p=entry.name(); entry.close(); LittleFS.remove(p); entry=dir.openNextFile(); }
}
void drawFormatConfirm(){
  display.clearDisplay(); display.setTextSize(1);
  display.setCursor(10,10); display.print(F("Delete ALL photos"));
  display.setCursor(10,20); display.print(F("and videos?"));
  display.setCursor(4,38); display.print(F("SELECT: confirm"));
  display.setCursor(4,48); display.print(F("BOOT/BACK: cancel"));
  display.display();
}
void updateFormatConfirm(){
  if(btnPressed[BTN_SELECT]){
    formatDeleteDir(GALLERY_DIR); formatDeleteDir(VIDEO_DIR);
    display.clearDisplay(); display.setCursor(20,28); display.print(F("Formatted!"));
    display.display(); delay(800);
    mode=MODE_SETTINGS;
  }
  if(btnPressed[BTN_BOOT]||btnPressed[BTN_BACK]) mode=MODE_SETTINGS;
  drawFormatConfirm();
}

// ============== GAME OVER ==============
void drawGameOver(){
  display.clearDisplay(); display.setTextSize(1); display.setCursor(25,8); display.println(F("GAME OVER"));
  display.setCursor(20,24); display.print(F("Score: ")); display.println(lastScore);
  display.setCursor(4,44); display.println(F("SELECT - restart"));
  display.setCursor(4,54); display.println(F("BOOT/BACK - menu"));
  display.display();
}
void updateGameOver(){
  if(btnPressed[BTN_SELECT]) startGame(currentGame);
  if(btnPressed[BTN_BOOT]||btnPressed[BTN_BACK]) mode=MODE_MENU;
  drawGameOver();
}

// ================= FLAPPY BIRD =================
float f_birdY,f_birdVel; int f_score;
struct FPipe{float x;int gapY;}; FPipe f_pipes[3]; bool f_passed[3];
unsigned long f_lastFrame=0; const int F_BX=20,F_BS=3,F_PW=10; int F_GAP; float F_SPEED;
void flappyReset(){
  f_birdY=32; f_birdVel=0; f_score=0; F_GAP=(int)diffLerp(34,26,20); F_SPEED=diffLerp(1.2,1.6,2.2);
  for(int i=0;i<3;i++){ f_pipes[i].x=SCREEN_WIDTH+i*50; f_pipes[i].gapY=random(6,SCREEN_HEIGHT-6-F_GAP); f_passed[i]=false; }
  f_lastFrame=millis();
}
bool flappyCollision(){
  if(f_birdY<0||f_birdY+F_BS>SCREEN_HEIGHT) return true;
  for(int i=0;i<3;i++) if(F_BX+F_BS>f_pipes[i].x&&F_BX<f_pipes[i].x+F_PW)
    if(f_birdY<f_pipes[i].gapY||f_birdY+F_BS>f_pipes[i].gapY+F_GAP) return true;
  return false;
}
void flappyUpdate(){
  if(checkExitToMenu()) return;
  if(btnPressed[BTN_SELECT]) f_birdVel=-3.2;
  if(millis()-f_lastFrame<30) return; f_lastFrame=millis();
  f_birdVel+=0.35; f_birdY+=f_birdVel;
  for(int i=0;i<3;i++){ f_pipes[i].x-=F_SPEED;
    if(!f_passed[i]&&f_pipes[i].x+F_PW<F_BX){f_score++;f_passed[i]=true;}
    if(f_pipes[i].x+F_PW<0){ float maxX=0; for(int j=0;j<3;j++) if(f_pipes[j].x>maxX)maxX=f_pipes[j].x;
      f_pipes[i].x=maxX+50; f_pipes[i].gapY=random(6,SCREEN_HEIGHT-6-F_GAP); f_passed[i]=false; } }
  if(flappyCollision()){ lastScore=f_score; mode=MODE_GAMEOVER; }
}
void flappyDraw(){
  display.clearDisplay();
  for(int i=0;i<3;i++){ int px=(int)f_pipes[i].x;
    display.fillRect(px,0,F_PW,f_pipes[i].gapY,SSD1306_WHITE);
    display.fillRect(px,f_pipes[i].gapY+F_GAP,F_PW,SCREEN_HEIGHT-(f_pipes[i].gapY+F_GAP),SSD1306_WHITE); }
  display.fillRect(F_BX,(int)f_birdY,F_BS,F_BS,SSD1306_WHITE);
  display.setCursor(2,2); display.print(f_score); display.display();
}

// ================= SNAKE =================
#define CELL 8
#define GRID_W (SCREEN_WIDTH/CELL)
#define GRID_H ((SCREEN_HEIGHT-8)/CELL)
#define GRID_OFFSET_Y 8
#define SNAKE_MAX 100
int s_snakeX[SNAKE_MAX],s_snakeY[SNAKE_MAX]; int s_dx,s_dy,s_len,s_foodX,s_foodY,s_score;
unsigned long s_lastFrame=0; int s_interval;
void snakePlaceFood(){ bool ok; do{ ok=true; s_foodX=random(0,GRID_W); s_foodY=random(0,GRID_H);
  for(int i=0;i<s_len;i++) if(s_snakeX[i]==s_foodX&&s_snakeY[i]==s_foodY) ok=false; }while(!ok); }
void snakeReset(){
  s_len=3; for(int i=0;i<s_len;i++){s_snakeX[i]=5-i;s_snakeY[i]=GRID_H/2;}
  s_dx=1;s_dy=0;s_score=0; s_interval=(int)diffLerp(180,130,90); snakePlaceFood(); s_lastFrame=millis();
}
void snakeUpdate(){
  if(checkExitToMenu()) return;
  if(btnPressed[BTN_UP]&&s_dy==0){s_dx=0;s_dy=-1;} if(btnPressed[BTN_DOWN]&&s_dy==0){s_dx=0;s_dy=1;}
  if(btnPressed[BTN_LEFT]&&s_dx==0){s_dx=-1;s_dy=0;} if(btnPressed[BTN_RIGHT]&&s_dx==0){s_dx=1;s_dy=0;}
  if(millis()-s_lastFrame<(unsigned long)s_interval) return; s_lastFrame=millis();
  int nx=s_snakeX[0]+s_dx, ny=s_snakeY[0]+s_dy;
  if(nx<0||nx>=GRID_W||ny<0||ny>=GRID_H){lastScore=s_score;mode=MODE_GAMEOVER;return;}
  for(int i=0;i<s_len;i++) if(s_snakeX[i]==nx&&s_snakeY[i]==ny){lastScore=s_score;mode=MODE_GAMEOVER;return;}
  bool grow=(nx==s_foodX&&ny==s_foodY);
  for(int i=s_len-1;i>0;i--){s_snakeX[i]=s_snakeX[i-1];s_snakeY[i]=s_snakeY[i-1];}
  s_snakeX[0]=nx;s_snakeY[0]=ny;
  if(grow){ if(s_len<SNAKE_MAX){s_snakeX[s_len]=s_snakeX[s_len-1];s_snakeY[s_len]=s_snakeY[s_len-1];s_len++;}
    s_score++; if(s_interval>60)s_interval-=2; snakePlaceFood(); }
}
void snakeDraw(){
  display.clearDisplay(); display.drawRect(0,GRID_OFFSET_Y-1,GRID_W*CELL+1,GRID_H*CELL+2,SSD1306_WHITE);
  for(int i=1;i<s_len;i++){ int px=s_snakeX[i]*CELL, py=GRID_OFFSET_Y+s_snakeY[i]*CELL;
    display.fillRect(px+1,py+1,CELL-2,CELL-2,SSD1306_WHITE); }
  int hx=s_snakeX[0]*CELL, hy=GRID_OFFSET_Y+s_snakeY[0]*CELL;
  display.fillRect(hx,hy,CELL,CELL,SSD1306_WHITE);
  int eoX=(s_dx==1)?CELL-3:(s_dx==-1)?1:CELL/2-1, eoY=(s_dy==1)?CELL-3:(s_dy==-1)?1:CELL/2-1;
  if(s_dx!=0){ display.drawPixel(hx+eoX,hy+2,SSD1306_BLACK); display.drawPixel(hx+eoX,hy+CELL-3,SSD1306_BLACK); }
  else { display.drawPixel(hx+2,hy+eoY,SSD1306_BLACK); display.drawPixel(hx+CELL-3,hy+eoY,SSD1306_BLACK); }
  int fx=s_foodX*CELL+CELL/2, fy=GRID_OFFSET_Y+s_foodY*CELL+CELL/2, r=CELL/2-1;
  display.fillTriangle(fx,fy-r,fx-r,fy,fx+r,fy,SSD1306_WHITE);
  display.fillTriangle(fx,fy+r,fx-r,fy,fx+r,fy,SSD1306_WHITE);
  display.setTextSize(1); display.setCursor(2,0); display.print(F("Score: ")); display.print(s_score);
  display.display();
}

// ================= PONG vs AI =================
float p_ballX,p_ballY,p_ballVX,p_ballVY,p_playerY,p_aiY; int p_score;
const int P_PH=14,P_PW=3,P_PLAYER_X=4; const int P_AI_X=SCREEN_WIDTH-4-P_PW;
const float P_PLAYER_SPEED=2.2; float p_aiSpeedCur; unsigned long p_lastFrame=0;
void pongServe(int dir){ p_ballX=SCREEN_WIDTH/2; p_ballY=random(16,SCREEN_HEIGHT-16);
  p_ballVX=1.6*dir; p_ballVY=(random(0,2)==0)?1.0:-1.0; }
void pongReset(){ p_playerY=SCREEN_HEIGHT/2-P_PH/2; p_aiY=SCREEN_HEIGHT/2-P_PH/2; p_score=0;
  p_aiSpeedCur=diffLerp(1.1,1.6,2.3); pongServe(-1); p_lastFrame=millis(); }
void pongUpdate(){
  if(checkExitToMenu()) return;
  if(isHeld(BTN_UP)) p_playerY-=P_PLAYER_SPEED; if(isHeld(BTN_DOWN)) p_playerY+=P_PLAYER_SPEED;
  if(p_playerY<0)p_playerY=0; if(p_playerY+P_PH>SCREEN_HEIGHT) p_playerY=SCREEN_HEIGHT-P_PH;
  if(millis()-p_lastFrame<25) return; p_lastFrame=millis();
  float aiCenter=p_aiY+P_PH/2, targetY=p_ballY;
  if(aiCenter<targetY-2) p_aiY+=p_aiSpeedCur; else if(aiCenter>targetY+2) p_aiY-=p_aiSpeedCur;
  if(p_aiY<0)p_aiY=0; if(p_aiY+P_PH>SCREEN_HEIGHT)p_aiY=SCREEN_HEIGHT-P_PH;
  p_ballX+=p_ballVX; p_ballY+=p_ballVY;
  if(p_ballY<=0||p_ballY>=SCREEN_HEIGHT-2) p_ballVY=-p_ballVY;
  if(p_ballVX<0&&p_ballX<=P_PLAYER_X+P_PW&&p_ballX>=P_PLAYER_X&&p_ballY+2>=p_playerY&&p_ballY<=p_playerY+P_PH){
    p_ballVX=-p_ballVX; float hit=(p_ballY-(p_playerY+P_PH/2))/(P_PH/2); p_ballVY+=hit*0.8; p_ballVX*=1.03; }
  if(p_ballVX>0&&p_ballX+2>=P_AI_X&&p_ballX<=P_AI_X+P_PW&&p_ballY+2>=p_aiY&&p_ballY<=p_aiY+P_PH){
    p_ballVX=-p_ballVX; float hit=(p_ballY-(p_aiY+P_PH/2))/(P_PH/2); p_ballVY+=hit*0.8; }
  if(p_ballX<0){lastScore=p_score;mode=MODE_GAMEOVER;return;}
  if(p_ballX>SCREEN_WIDTH){p_score++;pongServe(-1);}
}
void pongDraw(){
  display.clearDisplay();
  display.fillRect(P_PLAYER_X,(int)p_playerY,P_PW,P_PH,SSD1306_WHITE);
  display.fillRect(P_AI_X,(int)p_aiY,P_PW,P_PH,SSD1306_WHITE);
  display.fillRect((int)p_ballX,(int)p_ballY,2,2,SSD1306_WHITE);
  for(int y=0;y<SCREEN_HEIGHT;y+=6) display.drawPixel(SCREEN_WIDTH/2,y,SSD1306_WHITE);
  display.setCursor(SCREEN_WIDTH/2-10,2); display.print(p_score); display.display();
}

// ================= DINO RUN =================
float d_dinoY,d_dinoVel; bool d_jumping;
const int D_GROUND=54,D_DX=10,D_DS=6; struct DObs{float x;}; DObs d_obs[2]; int d_score;
float d_obsSpeed; int d_gapMin,d_gapMax; unsigned long d_lastFrame=0,d_scoreTimer=0;
void dinoReset(){
  d_dinoY=D_GROUND-D_DS; d_dinoVel=0; d_jumping=false;
  d_obs[0].x=SCREEN_WIDTH+20; d_obs[1].x=SCREEN_WIDTH+80; d_score=0;
  d_obsSpeed=diffLerp(1.7,2.2,2.9); d_gapMin=(int)diffLerp(50,40,30); d_gapMax=(int)diffLerp(90,80,65);
  d_lastFrame=millis(); d_scoreTimer=millis();
}
void dinoUpdate(){
  if(checkExitToMenu()) return;
  if(btnPressed[BTN_SELECT]&&!d_jumping){d_dinoVel=-4.5;d_jumping=true;}
  if(millis()-d_lastFrame<30) return; d_lastFrame=millis();
  if(d_jumping){ d_dinoVel+=0.4; d_dinoY+=d_dinoVel;
    if(d_dinoY>=D_GROUND-D_DS){d_dinoY=D_GROUND-D_DS;d_jumping=false;d_dinoVel=0;} }
  for(int i=0;i<2;i++){ d_obs[i].x-=d_obsSpeed;
    if(d_obs[i].x<-6){ float maxX=0; for(int j=0;j<2;j++) if(d_obs[j].x>maxX)maxX=d_obs[j].x;
      d_obs[i].x=maxX+random(d_gapMin,d_gapMax); }
    if(d_obs[i].x<D_DX+D_DS&&d_obs[i].x+4>D_DX) if(d_dinoY+D_DS>D_GROUND-6){lastScore=d_score;mode=MODE_GAMEOVER;return;} }
  if(millis()-d_scoreTimer>200){d_score++;d_scoreTimer=millis();}
}
void dinoDraw(){
  display.clearDisplay(); display.drawLine(0,D_GROUND,SCREEN_WIDTH,D_GROUND,SSD1306_WHITE);
  display.fillRect(D_DX,(int)d_dinoY,D_DS,D_DS,SSD1306_WHITE);
  for(int i=0;i<2;i++) display.fillRect((int)d_obs[i].x,D_GROUND-6,4,6,SSD1306_WHITE);
  display.setCursor(2,2); display.print(d_score); display.display();
}

// ================= TETRIS =================
#define T_COLS 10
#define T_ROWS 18
#define T_CELL 3
uint8_t t_grid[T_ROWS][T_COLS]; int t_pieceType,t_rot,t_px,t_py,t_nextType,t_score;
unsigned long t_lastFall; int t_fallInterval;
const int8_t TETROMINOES[7][4][4][2]={
  {{{0,1},{1,1},{2,1},{3,1}},{{2,0},{2,1},{2,2},{2,3}},{{0,2},{1,2},{2,2},{3,2}},{{1,0},{1,1},{1,2},{1,3}}},
  {{{1,0},{2,0},{1,1},{2,1}},{{1,0},{2,0},{1,1},{2,1}},{{1,0},{2,0},{1,1},{2,1}},{{1,0},{2,0},{1,1},{2,1}}},
  {{{1,0},{0,1},{1,1},{2,1}},{{1,0},{1,1},{2,1},{1,2}},{{0,1},{1,1},{2,1},{1,2}},{{1,0},{0,1},{1,1},{1,2}}},
  {{{1,0},{2,0},{0,1},{1,1}},{{1,0},{1,1},{2,1},{2,2}},{{1,0},{2,0},{0,1},{1,1}},{{1,0},{1,1},{2,1},{2,2}}},
  {{{0,0},{1,0},{1,1},{2,1}},{{2,0},{1,1},{2,1},{1,2}},{{0,0},{1,0},{1,1},{2,1}},{{2,0},{1,1},{2,1},{1,2}}},
  {{{0,0},{0,1},{1,1},{2,1}},{{1,0},{2,0},{1,1},{1,2}},{{0,1},{1,1},{2,1},{2,2}},{{1,0},{1,1},{0,2},{1,2}}},
  {{{2,0},{0,1},{1,1},{2,1}},{{1,0},{1,1},{1,2},{2,2}},{{0,1},{1,1},{2,1},{0,2}},{{0,0},{1,0},{1,1},{1,2}}}
};
bool tetroFits(int type,int rot,int px,int py){
  for(int c=0;c<4;c++){ int gx=px+TETROMINOES[type][rot][c][0], gy=py+TETROMINOES[type][rot][c][1];
    if(gx<0||gx>=T_COLS||gy>=T_ROWS) return false; if(gy>=0&&t_grid[gy][gx]) return false; }
  return true;
}
void tetrisSpawn(){
  t_pieceType=t_nextType; t_nextType=random(0,7); t_rot=0; t_px=3; t_py=0;
  if(!tetroFits(t_pieceType,t_rot,t_px,t_py)){lastScore=t_score;mode=MODE_GAMEOVER;}
}
void tetrisReset(){
  for(int y=0;y<T_ROWS;y++) for(int x=0;x<T_COLS;x++) t_grid[y][x]=0;
  t_score=0; t_fallInterval=(int)diffLerp(650,500,350); t_nextType=random(0,7); tetrisSpawn(); t_lastFall=millis();
}
void tetrisLock(){
  for(int c=0;c<4;c++){ int gx=t_px+TETROMINOES[t_pieceType][t_rot][c][0], gy=t_py+TETROMINOES[t_pieceType][t_rot][c][1];
    if(gy>=0) t_grid[gy][gx]=1; }
  int cleared=0;
  for(int y=T_ROWS-1;y>=0;y--){ bool full=true;
    for(int x=0;x<T_COLS;x++) if(!t_grid[y][x]){full=false;break;}
    if(full){ cleared++; for(int yy=y;yy>0;yy--) for(int x=0;x<T_COLS;x++) t_grid[yy][x]=t_grid[yy-1][x];
      for(int x=0;x<T_COLS;x++) t_grid[0][x]=0; y++; } }
  if(cleared==1)t_score+=100; else if(cleared==2)t_score+=300; else if(cleared==3)t_score+=500; else if(cleared>=4)t_score+=800;
  if(t_fallInterval>150) t_fallInterval-=cleared*10;
  tetrisSpawn();
}
void tetrisUpdate(){
  if(checkExitToMenu()) return;
  if(btnPressed[BTN_LEFT]&&tetroFits(t_pieceType,t_rot,t_px-1,t_py)) t_px--;
  if(btnPressed[BTN_RIGHT]&&tetroFits(t_pieceType,t_rot,t_px+1,t_py)) t_px++;
  if(btnPressed[BTN_SELECT]){ int nr=(t_rot+1)%4;
    if(tetroFits(t_pieceType,nr,t_px,t_py)) t_rot=nr;
    else if(tetroFits(t_pieceType,nr,t_px-1,t_py)){t_rot=nr;t_px--;}
    else if(tetroFits(t_pieceType,nr,t_px+1,t_py)){t_rot=nr;t_px++;} }
  if(btnPressed[BTN_UP]){ while(tetroFits(t_pieceType,t_rot,t_px,t_py+1)) t_py++; tetrisLock(); t_lastFall=millis(); return; }
  unsigned long interval=isHeld(BTN_DOWN)?50:t_fallInterval;
  if(millis()-t_lastFall<interval) return; t_lastFall=millis();
  if(tetroFits(t_pieceType,t_rot,t_px,t_py+1)) t_py++; else tetrisLock();
}
void tetrisDraw(){
  display.clearDisplay(); int fieldX=2,fieldY=9;
  for(int y=0;y<T_ROWS;y++) for(int x=0;x<T_COLS;x++) if(t_grid[y][x])
    display.fillRect(fieldX+x*T_CELL,fieldY+y*T_CELL,T_CELL-1,T_CELL-1,SSD1306_WHITE);
  for(int c=0;c<4;c++){ int gx=t_px+TETROMINOES[t_pieceType][t_rot][c][0], gy=t_py+TETROMINOES[t_pieceType][t_rot][c][1];
    if(gy>=0) display.fillRect(fieldX+gx*T_CELL,fieldY+gy*T_CELL,T_CELL-1,T_CELL-1,SSD1306_WHITE); }
  display.drawRect(fieldX-1,fieldY-1,T_COLS*T_CELL+2,T_ROWS*T_CELL+2,SSD1306_WHITE);
  display.setCursor(46,0); display.print(F("Sc:")); display.print(t_score);
  display.setCursor(46,12); display.print(F("Next:"));
  int nx=46,ny=22; display.drawRect(nx-1,ny-1,4*T_CELL+2,4*T_CELL+2,SSD1306_WHITE);
  for(int c=0;c<4;c++){ int cx=TETROMINOES[t_nextType][0][c][0], cy=TETROMINOES[t_nextType][0][c][1];
    display.fillRect(nx+cx*T_CELL,ny+cy*T_CELL,T_CELL-1,T_CELL-1,SSD1306_WHITE); }
  display.display();
}

// ================= SPACE INVADERS =================
#define SI_COLS 6
#define SI_ROWS 3
#define SI_AW 6
#define SI_AH 4
#define SI_SPX 10
#define SI_SPY 8
bool si_alive[SI_ROWS][SI_COLS]; float si_formX; int si_formY,si_formDir; unsigned long si_lastMove;
int si_playerX; bool si_bulletActive; float si_bulletX,si_bulletY;
bool si_abActive[2]; float si_abX[2],si_abY[2]; unsigned long si_lastAlienShot; int si_score;
bool si_shield[3][6]; float si_speedMul; const int SI_PLAYER_Y=60,SI_PLAYER_W=7;
int si_aliveCount(){ int c=0; for(int r=0;r<SI_ROWS;r++) for(int x=0;x<SI_COLS;x++) if(si_alive[r][x])c++; return c; }
void siResetShields(){ for(int b=0;b<3;b++) for(int i=0;i<6;i++) si_shield[b][i]=true; }
void siSpawnWave(){ for(int r=0;r<SI_ROWS;r++) for(int x=0;x<SI_COLS;x++) si_alive[r][x]=true;
  si_formX=8; si_formY=8; si_formDir=1; siResetShields(); }
void siReset(){ si_score=0; si_playerX=60; si_bulletActive=false; si_abActive[0]=si_abActive[1]=false;
  si_speedMul=diffLerp(1.3,1.0,0.7); si_lastMove=millis(); si_lastAlienShot=millis(); siSpawnWave(); }
bool siHitShield(float bx,float by){
  for(int b=0;b<3;b++){ int bunkerX=14+b*40,bunkerY=50;
    for(int i=0;i<6;i++){ if(!si_shield[b][i])continue; int c=i%3,r=i/3; int brickX=bunkerX+c*4,brickY=bunkerY+r*3;
      if(bx+1>=brickX&&bx<=brickX+4&&by+1>=brickY&&by<=brickY+3){si_shield[b][i]=false;return true;} } }
  return false;
}
void siDrawShields(){ for(int b=0;b<3;b++){ int bunkerX=14+b*40,bunkerY=50;
    for(int i=0;i<6;i++){ if(!si_shield[b][i])continue; int c=i%3,r=i/3;
      display.fillRect(bunkerX+c*4,bunkerY+r*3,3,2,SSD1306_WHITE); } } }
void siUpdate(){
  if(checkExitToMenu()) return;
  if(isHeld(BTN_LEFT)) si_playerX-=2; if(isHeld(BTN_RIGHT)) si_playerX+=2;
  if(si_playerX<0)si_playerX=0; if(si_playerX>SCREEN_WIDTH-SI_PLAYER_W)si_playerX=SCREEN_WIDTH-SI_PLAYER_W;
  if(btnPressed[BTN_SELECT]&&!si_bulletActive){ si_bulletActive=true; si_bulletX=si_playerX+SI_PLAYER_W/2; si_bulletY=SI_PLAYER_Y-2; }
  if(si_bulletActive){ si_bulletY-=3;
    if(si_bulletY<0) si_bulletActive=false;
    else if(siHitShield(si_bulletX,si_bulletY)) si_bulletActive=false;
    else { for(int r=0;r<SI_ROWS&&si_bulletActive;r++) for(int c=0;c<SI_COLS&&si_bulletActive;c++){
        if(!si_alive[r][c]) continue;
        float ax=si_formX+c*SI_SPX, ay=si_formY+r*SI_SPY;
        if(si_bulletX+1>=ax&&si_bulletX<=ax+SI_AW&&si_bulletY+1>=ay&&si_bulletY<=ay+SI_AH){
          si_alive[r][c]=false; si_bulletActive=false; si_score+=(r==0)?30:(r==1)?20:10; } } } }
  int totalAliens=SI_ROWS*SI_COLS, alive=si_aliveCount();
  if(alive==0){ siSpawnWave(); alive=totalAliens; }
  unsigned long moveInterval=(unsigned long)((80+(alive*320)/totalAliens)*si_speedMul);
  if(millis()-si_lastMove>=moveInterval){ si_lastMove=millis();
    int leftMost=SI_COLS,rightMost=-1;
    for(int r=0;r<SI_ROWS;r++) for(int c=0;c<SI_COLS;c++) if(si_alive[r][c]){ if(c<leftMost)leftMost=c; if(c>rightMost)rightMost=c; }
    float minX=si_formX+leftMost*SI_SPX, maxX=si_formX+rightMost*SI_SPX+SI_AW;
    bool hitEdge=(si_formDir>0&&maxX>=SCREEN_WIDTH-2)||(si_formDir<0&&minX<=2);
    if(hitEdge){ si_formDir=-si_formDir; si_formY+=4; } else si_formX+=si_formDir*2;
    if(si_formY+SI_ROWS*SI_SPY>=SI_PLAYER_Y-2){ lastScore=si_score; mode=MODE_GAMEOVER; return; } }
  if(millis()-si_lastAlienShot>700){ si_lastAlienShot=millis();
    for(int tries=0;tries<6;tries++){ int c=random(0,SI_COLS); int r=-1;
      for(int rr=SI_ROWS-1;rr>=0;rr--) if(si_alive[rr][c]){r=rr;break;}
      if(r>=0){ for(int i=0;i<2;i++) if(!si_abActive[i]){ si_abActive[i]=true;
          si_abX[i]=si_formX+c*SI_SPX+SI_AW/2; si_abY[i]=si_formY+r*SI_SPY+SI_AH; break; } break; } } }
  for(int i=0;i<2;i++){ if(!si_abActive[i]) continue; si_abY[i]+=2;
    if(si_abY[i]>SCREEN_HEIGHT){ si_abActive[i]=false; continue; }
    if(siHitShield(si_abX[i],si_abY[i])){ si_abActive[i]=false; continue; }
    if(si_abY[i]+1>=SI_PLAYER_Y&&si_abY[i]<=SI_PLAYER_Y+3&&si_abX[i]+1>=si_playerX&&si_abX[i]<=si_playerX+SI_PLAYER_W){
      lastScore=si_score; mode=MODE_GAMEOVER; return; } }
}
void siDraw(){
  display.clearDisplay();
  for(int r=0;r<SI_ROWS;r++) for(int c=0;c<SI_COLS;c++) if(si_alive[r][c])
    display.fillRect(si_formX+c*SI_SPX,si_formY+r*SI_SPY,SI_AW,SI_AH,SSD1306_WHITE);
  siDrawShields();
  display.fillRect(si_playerX,SI_PLAYER_Y,SI_PLAYER_W,3,SSD1306_WHITE);
  if(si_bulletActive) display.fillRect((int)si_bulletX,(int)si_bulletY,1,3,SSD1306_WHITE);
  for(int i=0;i<2;i++) if(si_abActive[i]) display.fillRect((int)si_abX[i],(int)si_abY[i],1,3,SSD1306_WHITE);
  display.setCursor(0,0); display.print(F("Sc:")); display.print(si_score); display.display();
}

// ================= BREAKOUT =================
#define BR_COLS 8
#define BR_ROWS 4
#define BR_BW 15
#define BR_BH 4
#define BR_GAP 1
bool br_bricks[BR_ROWS][BR_COLS]; float br_paddleX; int br_paddleW;
float br_ballX,br_ballY,br_ballVX,br_ballVY; bool br_launched; int br_score;
bool br_powerActive; float br_powerX,br_powerY; unsigned long br_wideUntil,br_lastFrame;
const int BR_PADDLE_Y=60;
void brSpawnBricks(){ for(int r=0;r<BR_ROWS;r++) for(int c=0;c<BR_COLS;c++) br_bricks[r][c]=true; }
void brResetBall(){ br_ballX=br_paddleX+br_paddleW/2; br_ballY=BR_PADDLE_Y-3; br_ballVX=0; br_ballVY=0; br_launched=false; }
void brReset(){ br_paddleX=54; br_paddleW=20; br_score=0; br_powerActive=false; br_wideUntil=0;
  brSpawnBricks(); brResetBall(); br_lastFrame=millis(); }
void brUpdate(){
  if(checkExitToMenu()) return;
  if(isHeld(BTN_LEFT)) br_paddleX-=2.5; if(isHeld(BTN_RIGHT)) br_paddleX+=2.5;
  if(br_paddleX<0)br_paddleX=0; if(br_paddleX>SCREEN_WIDTH-br_paddleW)br_paddleX=SCREEN_WIDTH-br_paddleW;
  if(br_wideUntil&&millis()>br_wideUntil){ br_wideUntil=0; br_paddleW=20; }
  if(!br_launched){ br_ballX=br_paddleX+br_paddleW/2;
    if(btnPressed[BTN_SELECT]){ br_launched=true; float spd=diffLerp(0.85,1.0,1.3); br_ballVX=1.2*spd; br_ballVY=-1.6*spd; } }
  if(millis()-br_lastFrame<20) return; br_lastFrame=millis();
  if(br_powerActive){ br_powerY+=1.2;
    if(br_powerY>SCREEN_HEIGHT) br_powerActive=false;
    else if(br_powerY+3>=BR_PADDLE_Y&&br_powerX+3>=br_paddleX&&br_powerX<=br_paddleX+br_paddleW){
      br_powerActive=false; br_paddleW=30; br_wideUntil=millis()+8000;
      if(br_paddleX>SCREEN_WIDTH-br_paddleW) br_paddleX=SCREEN_WIDTH-br_paddleW; } }
  if(!br_launched) return;
  br_ballX+=br_ballVX; br_ballY+=br_ballVY;
  if(br_ballX<=0||br_ballX>=SCREEN_WIDTH-2) br_ballVX=-br_ballVX;
  if(br_ballY<=0) br_ballVY=-br_ballVY;
  if(br_ballY+2>=BR_PADDLE_Y&&br_ballY<=BR_PADDLE_Y+3&&br_ballX+2>=br_paddleX&&br_ballX<=br_paddleX+br_paddleW&&br_ballVY>0){
    br_ballVY=-br_ballVY; float hit=(br_ballX-(br_paddleX+br_paddleW/2))/(br_paddleW/2.0); br_ballVX=hit*2.0; }
  if(br_ballY>SCREEN_HEIGHT){ lastScore=br_score; mode=MODE_GAMEOVER; return; }
  bool brickHit=false;
  for(int r=0;r<BR_ROWS&&!brickHit;r++) for(int c=0;c<BR_COLS&&!brickHit;c++){
    if(!br_bricks[r][c]) continue; int bx=c*(BR_BW+BR_GAP), by=4+r*(BR_BH+BR_GAP+2);
    if(br_ballX+2>=bx&&br_ballX<=bx+BR_BW&&br_ballY+2>=by&&br_ballY<=by+BR_BH){
      br_bricks[r][c]=false; br_ballVY=-br_ballVY; br_score+=10;
      if(random(0,6)==0&&!br_powerActive){ br_powerActive=true; br_powerX=bx+BR_BW/2; br_powerY=by; }
      brickHit=true; } }
  bool anyLeft=false;
  for(int r=0;r<BR_ROWS;r++) for(int c=0;c<BR_COLS;c++) if(br_bricks[r][c]) anyLeft=true;
  if(!anyLeft){ brSpawnBricks(); brResetBall(); }
}
void brDraw(){
  display.clearDisplay();
  for(int r=0;r<BR_ROWS;r++) for(int c=0;c<BR_COLS;c++) if(br_bricks[r][c])
    display.fillRect(c*(BR_BW+BR_GAP),4+r*(BR_BH+BR_GAP+2),BR_BW,BR_BH,SSD1306_WHITE);
  display.fillRect((int)br_paddleX,BR_PADDLE_Y,br_paddleW,3,SSD1306_WHITE);
  display.fillRect((int)br_ballX,(int)br_ballY,2,2,SSD1306_WHITE);
  if(br_powerActive) display.drawRect((int)br_powerX,(int)br_powerY,3,3,SSD1306_WHITE);
  display.setCursor(0,0); display.print(br_score); display.display();
}

// ================= PAC-MAN =================
#define PM_COLS 16
#define PM_ROWS 7
#define PM_CELL 8
#define PM_OFFY 8
const char PM_LAYOUT[PM_ROWS][PM_COLS+1]={
  "################","#..............#","#.####.##.####.#","#..............#",
  "#.####.##.####.#","#..............#","################"
};
char pm_maze[PM_ROWS][PM_COLS+1];
int pm_px,pm_py,pm_dx,pm_dy,pm_g1x,pm_g1y,pm_g1dx,pm_g1dy,pm_g2x,pm_g2y,pm_g2dx,pm_g2dy,pm_score,pm_ghostInterval;
unsigned long pm_lastMove,pm_lastGhostMove;
bool pmWall(int x,int y){ if(x<0||x>=PM_COLS||y<0||y>=PM_ROWS) return true; return pm_maze[y][x]=='#'; }
void pmResetDots(){ for(int y=0;y<PM_ROWS;y++) for(int x=0;x<PM_COLS;x++) pm_maze[y][x]=PM_LAYOUT[y][x]; }
void pmReset(){
  pmResetDots(); pm_px=1;pm_py=1;pm_dx=1;pm_dy=0;
  pm_g1x=14;pm_g1y=1;pm_g1dx=-1;pm_g1dy=0; pm_g2x=1;pm_g2y=5;pm_g2dx=1;pm_g2dy=0;
  pm_score=0; pm_ghostInterval=(int)diffLerp(300,220,150); pm_lastMove=millis(); pm_lastGhostMove=millis();
}
void pmGhostStep(int &gx,int &gy,int &gdx,int &gdy){
  int opts[4][2]={{1,0},{-1,0},{0,1},{0,-1}}; int valid[4][2]; int n=0;
  for(int i=0;i<4;i++){ int ndx=opts[i][0],ndy=opts[i][1]; if(ndx==-gdx&&ndy==-gdy) continue;
    if(!pmWall(gx+ndx,gy+ndy)){ valid[n][0]=ndx; valid[n][1]=ndy; n++; } }
  if(n==0){ gdx=-gdx; gdy=-gdy; if(!pmWall(gx+gdx,gy+gdy)){gx+=gdx;gy+=gdy;} return; }
  int pick=random(0,n); gdx=valid[pick][0]; gdy=valid[pick][1]; gx+=gdx; gy+=gdy;
}
void pmUpdate(){
  if(checkExitToMenu()) return;
  if(btnPressed[BTN_UP]&&!pmWall(pm_px,pm_py-1)){pm_dx=0;pm_dy=-1;}
  if(btnPressed[BTN_DOWN]&&!pmWall(pm_px,pm_py+1)){pm_dx=0;pm_dy=1;}
  if(btnPressed[BTN_LEFT]&&!pmWall(pm_px-1,pm_py)){pm_dx=-1;pm_dy=0;}
  if(btnPressed[BTN_RIGHT]&&!pmWall(pm_px+1,pm_py)){pm_dx=1;pm_dy=0;}
  if(millis()-pm_lastMove>160){ pm_lastMove=millis();
    if(!pmWall(pm_px+pm_dx,pm_py+pm_dy)){ pm_px+=pm_dx; pm_py+=pm_dy;
      if(pm_maze[pm_py][pm_px]=='.'){ pm_maze[pm_py][pm_px]=' '; pm_score+=10; } } }
  if(millis()-pm_lastGhostMove>(unsigned long)pm_ghostInterval){ pm_lastGhostMove=millis();
    pmGhostStep(pm_g1x,pm_g1y,pm_g1dx,pm_g1dy); pmGhostStep(pm_g2x,pm_g2y,pm_g2dx,pm_g2dy); }
  if((pm_px==pm_g1x&&pm_py==pm_g1y)||(pm_px==pm_g2x&&pm_py==pm_g2y)){ lastScore=pm_score; mode=MODE_GAMEOVER; return; }
  bool dotsLeft=false; for(int y=0;y<PM_ROWS;y++) for(int x=0;x<PM_COLS;x++) if(pm_maze[y][x]=='.') dotsLeft=true;
  if(!dotsLeft) pmResetDots();
}
void pmDraw(){
  display.clearDisplay();
  for(int y=0;y<PM_ROWS;y++) for(int x=0;x<PM_COLS;x++){ char c=pm_maze[y][x]; int px=x*PM_CELL, py=PM_OFFY+y*PM_CELL;
    if(c=='#') display.drawRect(px,py,PM_CELL,PM_CELL,SSD1306_WHITE);
    else if(c=='.') display.fillRect(px+PM_CELL/2-1,py+PM_CELL/2-1,2,2,SSD1306_WHITE); }
  display.fillCircle(pm_px*PM_CELL+PM_CELL/2,PM_OFFY+pm_py*PM_CELL+PM_CELL/2,3,SSD1306_WHITE);
  display.fillCircle(pm_g1x*PM_CELL+PM_CELL/2,PM_OFFY+pm_g1y*PM_CELL+PM_CELL/2,3,SSD1306_WHITE);
  display.fillCircle(pm_g2x*PM_CELL+PM_CELL/2,PM_OFFY+pm_g2y*PM_CELL+PM_CELL/2,3,SSD1306_WHITE);
  display.setCursor(0,0); display.print(pm_score); display.display();
}

// ================= MONSTER HUNT 3D =================
#define MH_MAP_SIZE 8
uint8_t mh_map[MH_MAP_SIZE][MH_MAP_SIZE]={
  {1,1,1,1,1,1,1,1},{1,0,0,0,1,0,0,1},{1,0,1,0,1,0,1,1},{1,0,1,0,0,0,0,1},
  {1,0,1,1,1,0,1,1},{1,0,0,0,1,0,0,1},{1,1,0,1,0,0,1,1},{1,1,1,1,1,1,1,1}
};
#define MH_MAX_MONSTERS 5
#define MH_NUM_RAYS 64
#define MH_COL_W (SCREEN_WIDTH/MH_NUM_RAYS)
#define MH_FOV 1.0472
#define MH_MAX_DEPTH 8.0
struct MHMonster{float x,y;bool alive;}; MHMonster mh_monsters[MH_MAX_MONSTERS];
int mh_monsterCount; float mh_monsterSpeed; int mh_damagePerHit;
float mh_px,mh_py,mh_angle; int mh_health,mh_score; float mh_wallDist[MH_NUM_RAYS];
unsigned long mh_lastFrame,mh_lastAI,mh_lastDamageTick; bool mh_shooting=false; unsigned long mh_shootTime=0;
bool mhIsWall(float x,float y){ int ix=(int)x,iy=(int)y; if(ix<0||ix>=MH_MAP_SIZE||iy<0||iy>=MH_MAP_SIZE) return true; return mh_map[iy][ix]==1; }
void mhSpawnMonster(int idx){ int tries=0; while(tries<30){ int x=random(1,MH_MAP_SIZE-1),y=random(1,MH_MAP_SIZE-1);
  if(mh_map[y][x]==0){ float dx=x+0.5-mh_px,dy=y+0.5-mh_py; if(dx*dx+dy*dy>4.0){
    mh_monsters[idx].x=x+0.5; mh_monsters[idx].y=y+0.5; mh_monsters[idx].alive=true; return; } } tries++; }
  mh_monsters[idx].x=5.5; mh_monsters[idx].y=5.5; mh_monsters[idx].alive=true; }
void mhCastRays(){ for(int r=0;r<MH_NUM_RAYS;r++){ float rayAngle=mh_angle-MH_FOV/2+(float)r/MH_NUM_RAYS*MH_FOV;
    float rx=mh_px,ry=mh_py,dx=cos(rayAngle)*0.05,dy=sin(rayAngle)*0.05,dist=0;
    while(dist<MH_MAX_DEPTH){ rx+=dx;ry+=dy;dist+=0.05; if(mhIsWall(rx,ry)) break; }
    mh_wallDist[r]=dist*cos(rayAngle-mh_angle); } }
void mhReset(){
  mh_px=1.5;mh_py=1.5;mh_angle=0; mh_health=100;mh_score=0;
  mh_monsterCount=(int)diffLerp(3,4,5); mh_monsterSpeed=diffLerp(0.012,0.02,0.03); mh_damagePerHit=(int)diffLerp(5,8,12);
  for(int i=0;i<MH_MAX_MONSTERS;i++){ if(i<mh_monsterCount) mhSpawnMonster(i); else mh_monsters[i].alive=false; }
  mh_lastFrame=millis(); mh_lastAI=millis(); mh_lastDamageTick=millis(); mh_shooting=false; mhCastRays();
}
void mhUpdate(){
  if(checkExitToMenu()) return;
  if(isHeld(BTN_LEFT)) mh_angle-=0.06; if(isHeld(BTN_RIGHT)) mh_angle+=0.06;
  float ms=0.05;
  if(isHeld(BTN_UP)){ float nx=mh_px+cos(mh_angle)*ms,ny=mh_py+sin(mh_angle)*ms;
    if(!mhIsWall(nx,mh_py)) mh_px=nx; if(!mhIsWall(mh_px,ny)) mh_py=ny; }
  if(isHeld(BTN_DOWN)){ float nx=mh_px-cos(mh_angle)*ms,ny=mh_py-sin(mh_angle)*ms;
    if(!mhIsWall(nx,mh_py)) mh_px=nx; if(!mhIsWall(mh_px,ny)) mh_py=ny; }
  if(btnPressed[BTN_SELECT]){ mh_shooting=true; mh_shootTime=millis();
    int bestIdx=-1; float bestAngle=0.3;
    for(int i=0;i<mh_monsterCount;i++){ if(!mh_monsters[i].alive) continue;
      float ddx=mh_monsters[i].x-mh_px, ddy=mh_monsters[i].y-mh_py, dist=sqrt(ddx*ddx+ddy*ddy);
      float angleTo=atan2(ddy,ddx)-mh_angle; while(angleTo>PI)angleTo-=2*PI; while(angleTo<-PI)angleTo+=2*PI;
      if(fabs(angleTo)<bestAngle&&dist<MH_MAX_DEPTH){ int col=(int)((angleTo+MH_FOV/2)/MH_FOV*MH_NUM_RAYS);
        if(col>=0&&col<MH_NUM_RAYS&&dist<mh_wallDist[col]+0.3){ bestAngle=fabs(angleTo); bestIdx=i; } } }
    if(bestIdx>=0){ mh_monsters[bestIdx].alive=false; mh_score+=10;
      bool anyLeft=false; for(int i=0;i<mh_monsterCount;i++) if(mh_monsters[i].alive) anyLeft=true;
      if(!anyLeft) for(int i=0;i<mh_monsterCount;i++) mhSpawnMonster(i); } }
  if(millis()-mh_lastFrame<30) return; mh_lastFrame=millis(); mhCastRays();
  if(millis()-mh_lastAI>60){ mh_lastAI=millis();
    for(int i=0;i<mh_monsterCount;i++){ if(!mh_monsters[i].alive) continue;
      float ddx=mh_px-mh_monsters[i].x, ddy=mh_py-mh_monsters[i].y, len=sqrt(ddx*ddx+ddy*ddy);
      if(len>0.3){ float nx=mh_monsters[i].x+(ddx/len)*mh_monsterSpeed, ny=mh_monsters[i].y+(ddy/len)*mh_monsterSpeed;
        if(!mhIsWall(nx,mh_monsters[i].y)) mh_monsters[i].x=nx; if(!mhIsWall(mh_monsters[i].x,ny)) mh_monsters[i].y=ny; } } }
  if(millis()-mh_lastDamageTick>500){ mh_lastDamageTick=millis();
    for(int i=0;i<mh_monsterCount;i++){ if(!mh_monsters[i].alive) continue;
      float ddx=mh_px-mh_monsters[i].x, ddy=mh_py-mh_monsters[i].y;
      if(ddx*ddx+ddy*ddy<0.36) mh_health-=mh_damagePerHit; }
    if(mh_health<=0){ lastScore=mh_score; mode=MODE_GAMEOVER; return; } }
}
void mhDraw(){
  display.clearDisplay();
  for(int r=0;r<MH_NUM_RAYS;r++){ float dist=mh_wallDist[r]; if(dist<0.1)dist=0.1;
    int wallH=(int)(SCREEN_HEIGHT/dist); if(wallH>SCREEN_HEIGHT)wallH=SCREEN_HEIGHT;
    int y0=(SCREEN_HEIGHT-wallH)/2; display.fillRect(r*MH_COL_W,y0,MH_COL_W,wallH,SSD1306_WHITE); }
  for(int i=0;i<mh_monsterCount;i++){ if(!mh_monsters[i].alive) continue;
    float ddx=mh_monsters[i].x-mh_px, ddy=mh_monsters[i].y-mh_py, dist=sqrt(ddx*ddx+ddy*ddy);
    float angleTo=atan2(ddy,ddx)-mh_angle; while(angleTo>PI)angleTo-=2*PI; while(angleTo<-PI)angleTo+=2*PI;
    if(fabs(angleTo)>MH_FOV/2+0.2) continue;
    int col=(int)((angleTo+MH_FOV/2)/MH_FOV*MH_NUM_RAYS); if(col<0||col>=MH_NUM_RAYS) continue;
    if(dist>mh_wallDist[col]+0.15) continue;
    int sx=(int)((angleTo+MH_FOV/2)/MH_FOV*SCREEN_WIDTH); int size=(int)(SCREEN_HEIGHT/dist/2.2);
    if(size<2)size=2; if(size>40)size=40;
    display.fillRect(sx-size/2,SCREEN_HEIGHT/2-size/2,size,size,SSD1306_BLACK);
    display.drawRect(sx-size/2,SCREEN_HEIGHT/2-size/2,size,size,SSD1306_WHITE); }
  display.drawFastHLine(SCREEN_WIDTH/2-3,SCREEN_HEIGHT/2,6,SSD1306_WHITE);
  display.drawFastVLine(SCREEN_WIDTH/2,SCREEN_HEIGHT/2-3,6,SSD1306_WHITE);
  bool flashing=mh_shooting&&(millis()-mh_shootTime<100);
  int gunY=flashing?SCREEN_HEIGHT-14:SCREEN_HEIGHT-10;
  display.fillRect(SCREEN_WIDTH/2-3,gunY,6,12,SSD1306_WHITE);
  display.fillRect(SCREEN_WIDTH/2-1,gunY-4,2,5,SSD1306_WHITE);
  if(flashing) display.fillTriangle(SCREEN_WIDTH/2-5,gunY-4,SCREEN_WIDTH/2+5,gunY-4,SCREEN_WIDTH/2,gunY-12,SSD1306_WHITE);
  if(mh_shooting&&millis()-mh_shootTime>=100) mh_shooting=false;
  display.fillRect(0,0,44,8,SSD1306_BLACK);
  display.setCursor(0,0); display.print(F("HP:")); display.print(mh_health);
  display.setCursor(SCREEN_WIDTH-40,0); display.print(F("Sc:")); display.print(mh_score);
  display.display();
}

// ================= BOT DUEL 3D =================
float bd_px,bd_py,bd_angle,bd_botX,bd_botY,bd_botAngle,bd_botTargetX,bd_botTargetY;
int bd_playerHealth,bd_botHealth,bd_score; float bd_wallDist[MH_NUM_RAYS];
bool bd_shooting; unsigned long bd_shootTime; bool bd_botFlash; unsigned long bd_botFlashTime;
unsigned long bd_lastFrame,bd_lastAI,bd_lastBotShot; float bd_botSpeed; int bd_botDamage;
unsigned long bd_botFireInterval; int bd_botAccuracy; const int bd_playerDamage=20;
bool bdHasLineOfSight(float x0,float y0,float x1,float y1){
  float dx=x1-x0,dy=y1-y0,dist=sqrt(dx*dx+dy*dy); int steps=(int)(dist/0.1)+1;
  float sx=dx/steps,sy=dy/steps,cx=x0,cy=y0;
  for(int i=0;i<steps;i++){ cx+=sx;cy+=sy; if(bdIsWall(cx,cy)) return false; } return true;
}
void bdPickPatrolTarget(){ int tries=0; while(tries<30){ int x=random(1,BD_MAP_SIZE-1),y=random(1,BD_MAP_SIZE-1);
  if(!bdIsWall(x+0.5,y+0.5)){ bd_botTargetX=x+0.5; bd_botTargetY=y+0.5; return; } tries++; }
  bd_botTargetX=bd_botX; bd_botTargetY=bd_botY; }
void bdSpawnBot(){ int tries=0; while(tries<30){ int x=random(1,BD_MAP_SIZE-1),y=random(1,BD_MAP_SIZE-1);
  if(!bdIsWall(x+0.5,y+0.5)){ float dx=x+0.5-bd_px,dy=y+0.5-bd_py; if(dx*dx+dy*dy>4.0){
    bd_botX=x+0.5; bd_botY=y+0.5; bd_botHealth=100; bdPickPatrolTarget(); return; } } tries++; }
  bd_botX=8.5; bd_botY=8.5; bd_botHealth=100; bdPickPatrolTarget(); }
void bdCastRays(){ for(int r=0;r<MH_NUM_RAYS;r++){ float rayAngle=bd_angle-MH_FOV/2+(float)r/MH_NUM_RAYS*MH_FOV;
    float rx=bd_px,ry=bd_py,dx=cos(rayAngle)*0.05,dy=sin(rayAngle)*0.05,dist=0;
    while(dist<MH_MAX_DEPTH){ rx+=dx;ry+=dy;dist+=0.05; if(bdIsWall(rx,ry)) break; }
    bd_wallDist[r]=dist*cos(rayAngle-bd_angle); } }
void bdReset(){
  bd_px=1.5;bd_py=1.5;bd_angle=0; bd_playerHealth=100; bd_score=0; bd_shooting=false; bd_botFlash=false;
  bd_botSpeed=diffLerp(0.012,0.018,0.025); bd_botDamage=(int)diffLerp(5,8,12);
  bd_botFireInterval=(unsigned long)diffLerp(1600,1100,700); bd_botAccuracy=(int)diffLerp(45,65,85);
  bdSpawnBot(); bd_lastFrame=millis(); bd_lastAI=millis(); bd_lastBotShot=millis(); bdCastRays();
}
void bdBotAI(){
  float ddx=bd_px-bd_botX,ddy=bd_py-bd_botY,dist=sqrt(ddx*ddx+ddy*ddy);
  bool los=bdHasLineOfSight(bd_botX,bd_botY,bd_px,bd_py);
  if(los&&dist<7.0){ bd_botAngle=atan2(ddy,ddx);
    if(millis()-bd_lastBotShot>bd_botFireInterval){ bd_lastBotShot=millis(); bd_botFlash=true; bd_botFlashTime=millis();
      if(random(0,100)<bd_botAccuracy) bd_playerHealth-=bd_botDamage; } }
  else { float tdx=bd_botTargetX-bd_botX,tdy=bd_botTargetY-bd_botY,tdist=sqrt(tdx*tdx+tdy*tdy);
    if(tdist<0.3) bdPickPatrolTarget();
    else { float nx=bd_botX+(tdx/tdist)*bd_botSpeed, ny=bd_botY+(tdy/tdist)*bd_botSpeed;
      if(!bdIsWall(nx,bd_botY)) bd_botX=nx; if(!bdIsWall(bd_botX,ny)) bd_botY=ny; bd_botAngle=atan2(tdy,tdx); } }
}
void bdUpdate(){
  if(checkExitToMenu()) return;
  if(isHeld(BTN_LEFT)) bd_angle-=0.06; if(isHeld(BTN_RIGHT)) bd_angle+=0.06;
  float ms=0.05;
  if(isHeld(BTN_UP)){ float nx=bd_px+cos(bd_angle)*ms,ny=bd_py+sin(bd_angle)*ms;
    if(!bdIsWall(nx,bd_py)) bd_px=nx; if(!bdIsWall(bd_px,ny)) bd_py=ny; }
  if(isHeld(BTN_DOWN)){ float nx=bd_px-cos(bd_angle)*ms,ny=bd_py-sin(bd_angle)*ms;
    if(!bdIsWall(nx,bd_py)) bd_px=nx; if(!bdIsWall(bd_px,ny)) bd_py=ny; }
  if(btnPressed[BTN_SELECT]){ bd_shooting=true; bd_shootTime=millis();
    float ddx=bd_botX-bd_px,ddy=bd_botY-bd_py,dist=sqrt(ddx*ddx+ddy*ddy);
    float angleTo=atan2(ddy,ddx)-bd_angle; while(angleTo>PI)angleTo-=2*PI; while(angleTo<-PI)angleTo+=2*PI;
    if(fabs(angleTo)<0.16&&dist<MH_MAX_DEPTH){ int col=(int)((angleTo+MH_FOV/2)/MH_FOV*MH_NUM_RAYS);
      if(col>=0&&col<MH_NUM_RAYS&&dist<bd_wallDist[col]+0.3){ bd_botHealth-=bd_playerDamage;
        if(bd_botHealth<=0){ bd_score++; bdSpawnBot(); } } } }
  if(millis()-bd_lastFrame<30) return; bd_lastFrame=millis(); bdCastRays();
  if(millis()-bd_lastAI>80){ bd_lastAI=millis(); bdBotAI(); }
  if(bd_playerHealth<=0){ lastScore=bd_score; mode=MODE_GAMEOVER; return; }
}
void bdDraw(){
  display.clearDisplay();
  for(int r=0;r<MH_NUM_RAYS;r++){ float dist=bd_wallDist[r]; if(dist<0.1)dist=0.1;
    int wallH=(int)(SCREEN_HEIGHT/dist); if(wallH>SCREEN_HEIGHT)wallH=SCREEN_HEIGHT;
    int y0=(SCREEN_HEIGHT-wallH)/2; display.fillRect(r*MH_COL_W,y0,MH_COL_W,wallH,SSD1306_WHITE); }
  if(bd_botHealth>0){ float ddx=bd_botX-bd_px,ddy=bd_botY-bd_py,dist=sqrt(ddx*ddx+ddy*ddy);
    float angleTo=atan2(ddy,ddx)-bd_angle; while(angleTo>PI)angleTo-=2*PI; while(angleTo<-PI)angleTo+=2*PI;
    if(fabs(angleTo)<=MH_FOV/2+0.2){ int col=(int)((angleTo+MH_FOV/2)/MH_FOV*MH_NUM_RAYS);
      if(col>=0&&col<MH_NUM_RAYS&&dist<=bd_wallDist[col]+0.15){
        int sx=(int)((angleTo+MH_FOV/2)/MH_FOV*SCREEN_WIDTH); int hgt=(int)(SCREEN_HEIGHT/dist/1.8);
        if(hgt<4)hgt=4; if(hgt>46)hgt=46; int bodyW=hgt/2, topY=SCREEN_HEIGHT/2-hgt/2;
        display.fillRect(sx-bodyW/2,topY+hgt/4,bodyW,hgt-hgt/4,SSD1306_BLACK);
        display.drawRect(sx-bodyW/2,topY+hgt/4,bodyW,hgt-hgt/4,SSD1306_WHITE);
        int headR=hgt/8+1; display.fillCircle(sx,topY+headR,headR,SSD1306_BLACK); display.drawCircle(sx,topY+headR,headR,SSD1306_WHITE);
        if(bd_botFlash&&millis()-bd_botFlashTime<100) display.fillCircle(sx+bodyW/2+1,topY+hgt/3,2,SSD1306_WHITE); } } }
  if(bd_botFlash&&millis()-bd_botFlashTime>=100) bd_botFlash=false;
  display.drawFastHLine(SCREEN_WIDTH/2-3,SCREEN_HEIGHT/2,6,SSD1306_WHITE);
  display.drawFastVLine(SCREEN_WIDTH/2,SCREEN_HEIGHT/2-3,6,SSD1306_WHITE);
  bool flashing=bd_shooting&&(millis()-bd_shootTime<100);
  int gunY=flashing?SCREEN_HEIGHT-14:SCREEN_HEIGHT-10;
  display.fillRect(SCREEN_WIDTH/2-3,gunY,6,12,SSD1306_WHITE);
  display.fillRect(SCREEN_WIDTH/2-1,gunY-4,2,5,SSD1306_WHITE);
  if(flashing) display.fillTriangle(SCREEN_WIDTH/2-5,gunY-4,SCREEN_WIDTH/2+5,gunY-4,SCREEN_WIDTH/2,gunY-12,SSD1306_WHITE);
  if(bd_shooting&&millis()-bd_shootTime>=100) bd_shooting=false;
  display.fillRect(0,0,46,8,SSD1306_BLACK); display.setCursor(0,0); display.print(F("You:")); display.print(bd_playerHealth);
  display.fillRect(SCREEN_WIDTH-46,0,46,8,SSD1306_BLACK); display.setCursor(SCREEN_WIDTH-42,0);
  display.print(F("Bot:")); display.print(bd_botHealth>0?bd_botHealth:0);
  display.setCursor(SCREEN_WIDTH/2-12,9); display.print(F("W:")); display.print(bd_score);
  display.display();
}

// ================= 3D FPS TEST =================
float fps_px,fps_py,fps_angle; float fps_wallDist[MH_NUM_RAYS];
unsigned long fps_frameCount,fps_lastCalc; int fps_currentFps;
void fpsCastRays(){ for(int r=0;r<MH_NUM_RAYS;r++){ float rayAngle=fps_angle-MH_FOV/2+(float)r/MH_NUM_RAYS*MH_FOV;
    float rx=fps_px,ry=fps_py,dx=cos(rayAngle)*0.05,dy=sin(rayAngle)*0.05,dist=0;
    while(dist<MH_MAX_DEPTH){ rx+=dx;ry+=dy;dist+=0.05; if(bdIsWall(rx,ry)) break; }
    fps_wallDist[r]=dist*cos(rayAngle-fps_angle); } }
void fpsReset(){ fps_px=1.5;fps_py=1.5;fps_angle=0; fps_frameCount=0; fps_lastCalc=millis(); fps_currentFps=0; }
void fpsUpdate(){
  if(checkExitToMenu()) return;
  if(isHeld(BTN_LEFT)) fps_angle-=0.06; if(isHeld(BTN_RIGHT)) fps_angle+=0.06;
  float ms=0.05;
  if(isHeld(BTN_UP)){ float nx=fps_px+cos(fps_angle)*ms,ny=fps_py+sin(fps_angle)*ms;
    if(!bdIsWall(nx,fps_py)) fps_px=nx; if(!bdIsWall(fps_px,ny)) fps_py=ny; }
  if(isHeld(BTN_DOWN)){ float nx=fps_px-cos(fps_angle)*ms,ny=fps_py-sin(fps_angle)*ms;
    if(!bdIsWall(nx,fps_py)) fps_px=nx; if(!bdIsWall(fps_px,ny)) fps_py=ny; }
  fpsCastRays(); fps_frameCount++;
  if(millis()-fps_lastCalc>=1000){ fps_currentFps=fps_frameCount; fps_frameCount=0; fps_lastCalc=millis(); }
}
void fpsDraw(){
  display.clearDisplay();
  for(int r=0;r<MH_NUM_RAYS;r++){ float dist=fps_wallDist[r]; if(dist<0.1)dist=0.1;
    int wallH=(int)(SCREEN_HEIGHT/dist); if(wallH>SCREEN_HEIGHT)wallH=SCREEN_HEIGHT;
    int y0=(SCREEN_HEIGHT-wallH)/2; display.fillRect(r*MH_COL_W,y0,MH_COL_W,wallH,SSD1306_WHITE); }
  display.fillRect(0,0,60,8,SSD1306_BLACK); display.setCursor(0,0); display.print(F("FPS: ")); display.print(fps_currentFps);
  display.display();
}

// ================= BIN: WEB UPLOAD + GALLERY VIEW + OTA =================
WebServer binServer(80); File binUploadFile;
const char* BIN_AP_SSID="MiniGame-Upload"; const char* BIN_AP_PASS="12345678"; bool binFsReady=false;

void binHandleGalleryView(){
  if(!binServer.hasArg("f")){ binServer.send(400,"text/plain","missing f"); return; }
  String fname=binServer.arg("f");
  String path = fname.endsWith(".mgv") ? String(VIDEO_DIR)+"/"+fname : String(GALLERY_DIR)+"/"+fname;
  File f=LittleFS.open(path,"r"); if(!f){ binServer.send(404,"text/plain","not found"); return; }
  binServer.streamFile(f, fname.endsWith(".mgv") ? "application/octet-stream" : "image/png");
  f.close();
}

void binHandleRoot(){
  String html = F(
"<!DOCTYPE html><html><head><meta charset='utf-8'>"
"<meta name='viewport' content='width=device-width,initial-scale=1'>"
"<title>MiniGame</title><style>"
"body{font-family:Arial;background:#1a1a2e;color:#eee;margin:0;padding:20px}"
"h3{color:#0f8;text-align:center} h4{color:#ccc;border-bottom:2px solid #0f8;padding-bottom:5px}"
".upload-box{background:#16213e;padding:15px;border-radius:10px;margin-bottom:20px;text-align:center}"
"input[type=file]{color:#eee}"
"input[type=submit]{background:#0f8;color:#000;border:none;padding:8px 16px;border-radius:6px;cursor:pointer;font-weight:bold}"
".gallery{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}"
".shot{background:#16213e;padding:8px;border-radius:8px;text-align:center;cursor:pointer}"
".shot img{image-rendering:pixelated;width:192px;border-radius:4px;border:2px solid #0f8}"
".shot span{display:block;margin-top:6px;font-size:12px;color:#aaa}"
"#lightbox{display:none;position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.9);z-index:100;justify-content:center;align-items:center;flex-direction:column}"
"#lightbox img{image-rendering:pixelated;max-width:90%;max-height:80%;border:3px solid #0f8;border-radius:6px}"
"#lightbox .close{position:absolute;top:20px;right:30px;font-size:30px;color:#fff;cursor:pointer}"
"</style></head><body><h3>MiniGame Control Panel</h3>"
"<div class='upload-box'><h4 style='border:none'>Upload custom game (.bin)</h4>"
"<form method='POST' action='/upload' enctype='multipart/form-data'>"
"<input type='file' name='file'> <input type='submit' value='Upload'></form></div>"
"<div class='upload-box'><h4 style='border:none'>Firmware OTA Update</h4>"
"<form method='POST' action='/ota' enctype='multipart/form-data'>"
"<input type='file' name='firmware' accept='.bin'> "
"<input type='submit' value='Flash Firmware' style='background:#f44;color:#fff'></form>"
"<p style='color:#f88;font-size:12px'>Warning: replaces whole firmware!</p></div>"
"<h4>Gallery</h4><div class='gallery' id='gal'>"
  );
  if(!LittleFS.exists(GALLERY_DIR)) LittleFS.mkdir(GALLERY_DIR);
  File dir=LittleFS.open(GALLERY_DIR); File entry=dir.openNextFile(); bool any=false;
  while(entry){ any=true; String full=String(entry.name()); int slash=full.lastIndexOf('/');
    String base=slash>=0?full.substring(slash+1):full;
    html += "<div class='shot'><img src='/view?f="+base+"'><span>"+base+"</span></div>";
    entry=dir.openNextFile(); }
  if(!LittleFS.exists(VIDEO_DIR)) LittleFS.mkdir(VIDEO_DIR);
  File vdir=LittleFS.open(VIDEO_DIR); File ventry=vdir.openNextFile();
  while(ventry){ any=true; String full=String(ventry.name()); int slash=full.lastIndexOf('/');
    String base=slash>=0?full.substring(slash+1):full;
    html += "<div class='shot'><span>[VIDEO]<br>"+base+"</span></div>";
    ventry=vdir.openNextFile(); }
  if(!any) html += "<p style='color:#888'>No media yet</p>";
  html += F("</div></body></html>");
  binServer.send(200,"text/html",html);
}

void binHandleUpload(){
  HTTPUpload& upload=binServer.upload();
  if(upload.status==UPLOAD_FILE_START) binUploadFile=LittleFS.open("/game.bin","w");
  else if(upload.status==UPLOAD_FILE_WRITE){ if(binUploadFile) binUploadFile.write(upload.buf,upload.currentSize); }
  else if(upload.status==UPLOAD_FILE_END){ if(binUploadFile) binUploadFile.close(); }
}

bool ota_hasError=false; String ota_errorMsg=""; size_t ota_totalSize=0, ota_received=0;
unsigned long ota_prepareStart=0; const unsigned long OTA_PREPARE_MS=5000;

void otaHandleUpdate(){
  HTTPUpload& upload=binServer.upload();
  if(upload.status==UPLOAD_FILE_START){
    ota_hasError=false; ota_errorMsg=""; ota_received=0; ota_totalSize=upload.totalSize;
    ota_prepareStart=millis(); mode=MODE_OTA_PREPARE;
    if(!Update.begin(UPDATE_SIZE_UNKNOWN)){ ota_hasError=true; ota_errorMsg="Update.begin failed"; }
  } else if(upload.status==UPLOAD_FILE_WRITE){
    if(!ota_hasError){
      while(millis()-ota_prepareStart<OTA_PREPARE_MS) delay(10);
      mode=MODE_OTA_UPDATING;
      if(Update.write(upload.buf,upload.currentSize)!=upload.currentSize){ ota_hasError=true; ota_errorMsg="Write failed"; }
      ota_received+=upload.currentSize;
    }
  } else if(upload.status==UPLOAD_FILE_END){
    if(!ota_hasError){ if(!Update.end(true)){ ota_hasError=true; ota_errorMsg="Update.end failed"; } }
  }
}
void otaHandleUploadResponse(){
  if(ota_hasError){ binServer.send(500,"text/plain","OTA failed: "+ota_errorMsg); mode=MODE_MENU; }
  else { binServer.send(200,"text/plain","OK, rebooting..."); delay(500); ESP.restart(); }
}
void updateOtaPrepare(){
  display.clearDisplay(); display.setTextSize(2);
  int dotCount=((millis()-ota_prepareStart)/400)%4; String dots="";
  for(int i=0;i<dotCount;i++) dots+=".";
  String text="Updating"+dots; int16_t x1,y1; uint16_t w,h;
  display.getTextBounds(text.c_str(),0,0,&x1,&y1,&w,&h);
  display.setCursor((SCREEN_WIDTH-w)/2,SCREEN_HEIGHT/2-10); display.print(text);
  display.display(); binServer.handleClient();
}
void updateOtaUpdating(){
  display.clearDisplay(); display.setTextSize(1); display.setCursor(20,10); display.print(F("Flashing firmware"));
  display.drawFastHLine(0,20,SCREEN_WIDTH,SSD1306_WHITE);
  if(ota_totalSize>0){ int percent=(ota_received*100)/ota_totalSize; if(percent>100)percent=100;
    display.setCursor(50,30); display.print(percent); display.print(F("%"));
    int barW=SCREEN_WIDTH-20; display.drawRect(10,42,barW,10,SSD1306_WHITE);
    int fillW=(barW-2)*percent/100; display.fillRect(11,43,fillW,8,SSD1306_WHITE);
  } else { int dc=((millis()/400)%4); String dots=""; for(int i=0;i<dc;i++)dots+=".";
    display.setCursor(30,30); display.print(F("Writing")); display.print(dots); }
  display.setCursor(2,56); display.print(F("Do not power off!"));
  display.display(); binServer.handleClient();
}

void binServerStart(){
  if(!binFsReady) binFsReady=LittleFS.begin(true);
  WiFi.mode(WIFI_AP); WiFi.softAP(BIN_AP_SSID,BIN_AP_PASS);
  binServer.on("/",HTTP_GET,binHandleRoot);
  binServer.on("/upload",HTTP_POST,[](){binServer.send(200,"text/plain","OK");},binHandleUpload);
  binServer.on("/view",HTTP_GET,binHandleGalleryView);
  binServer.on("/ota",HTTP_POST,otaHandleUploadResponse,otaHandleUpdate);
  binServer.begin(); mode=MODE_BIN_SERVER;
}
void binServerStop(){ binServer.stop(); WiFi.softAPdisconnect(true); WiFi.mode(WIFI_OFF); }
void updateBinServer(){
  binServer.handleClient();
  display.clearDisplay(); display.setTextSize(1); display.setCursor(0,0);
  display.println(F("Bin Upload Mode"));
  display.print(F("SSID: ")); display.println(BIN_AP_SSID);
  display.print(F("Pass: ")); display.println(BIN_AP_PASS);
  display.print(F("http://")); display.println(WiFi.softAPIP());
  display.println(); display.println(F("BOOT/BACK: stop & exit"));
  display.display();
  if(btnPressed[BTN_BOOT]||btnPressed[BTN_BACK]){ binServerStop(); mode=MODE_MENU; }
}

// ================= BIN: BYTECODE VM =================
uint8_t *vm_code=nullptr; size_t vm_codeLen=0, vm_pc=0; uint16_t vm_loopStart=0;
int16_t vm_vars[8]; bool vm_error=false; String vm_errorMsg="";
uint8_t vmByte(){ if(vm_pc>=vm_codeLen){vm_error=true;return 0;} return vm_code[vm_pc++]; }
int16_t vmInt16(){ uint8_t lo=vmByte(),hi=vmByte(); return (int16_t)(lo|(hi<<8)); }
bool vmLoad(){
  if(!binFsReady) binFsReady=LittleFS.begin(true);
  if(!LittleFS.exists("/game.bin")){ vm_errorMsg="No game.bin found"; return false; }
  File f=LittleFS.open("/game.bin","r"); if(!f){ vm_errorMsg="Cannot open file"; return false; }
  vm_codeLen=f.size(); if(vm_codeLen<7){ vm_errorMsg="File too small"; f.close(); return false; }
  if(vm_code){ free(vm_code); vm_code=nullptr; }
  vm_code=psramFound()?(uint8_t*)ps_malloc(vm_codeLen):(uint8_t*)malloc(vm_codeLen);
  if(!vm_code){ vm_errorMsg="Out of memory"; f.close(); return false; }
  f.read(vm_code,vm_codeLen); f.close();
  if(vm_code[0]!='M'||vm_code[1]!='G'||vm_code[2]!='V'||vm_code[3]!='M'){ vm_errorMsg="Bad file format"; return false; }
  vm_loopStart=vm_code[5]|(vm_code[6]<<8); vm_pc=7;
  for(int i=0;i<8;i++) vm_vars[i]=0; vm_error=false; return true;
}
void binPlayReset(){
  if(!vmLoad()){
    display.clearDisplay(); display.setTextSize(1);
    display.setCursor(10,20); display.print(F("No custom game!"));
    display.setCursor(5,32); display.print(vm_errorMsg);
    display.setCursor(5,48); display.print(F("Upload via Bin:Upload"));
    display.display(); delay(2000); mode=MODE_MENU;
  }
}
bool vmBtnHeld(uint8_t id){ switch(id){ case 0:return isHeld(BTN_UP); case 1:return isHeld(BTN_DOWN);
  case 2:return isHeld(BTN_LEFT); case 3:return isHeld(BTN_RIGHT); case 4:return isHeld(BTN_SELECT); } return false; }
void binPlayUpdate(){
  if(checkExitToMenu()) return;
  if(!vm_code||vm_error){ lastScore=0; mode=MODE_GAMEOVER; return; }
  bool yieldFrame=false;
  while(!yieldFrame&&!vm_error){
    uint8_t op=vmByte();
    switch(op){
      case 0x00: break;
      case 0x01: display.clearDisplay(); break;
      case 0x02: display.display(); yieldFrame=true; break;
      case 0x03:{ int x=vmByte(),y=vmByte(),w=vmByte(),h=vmByte(),fl=vmByte();
        if(fl) display.fillRect(x,y,w,h,SSD1306_WHITE); else display.drawRect(x,y,w,h,SSD1306_WHITE); } break;
      case 0x04:{ int x=vmByte(),y=vmByte(); display.drawPixel(x,y,SSD1306_WHITE); } break;
      case 0x05:{ int x=vmByte(),y=vmByte(),len=vmByte(); char buf[33]; if(len>32)len=32;
        for(int i=0;i<len;i++) buf[i]=(char)vmByte(); buf[len]=0;
        display.setTextSize(1); display.setCursor(x,y); display.print(buf); } break;
      case 0x06:{ int r=vmByte()&7; int16_t v=vmInt16(); vm_vars[r]=v; } break;
      case 0x07:{ int r=vmByte()&7; int16_t v=vmInt16(); vm_vars[r]+=v; } break;
      case 0x08:{ int d=vmByte()&7,s=vmByte()&7; vm_vars[d]=vm_vars[s]; } break;
      case 0x09:{ int rx=vmByte()&7,ry=vmByte()&7,w=vmByte(),h=vmByte(),fl=vmByte();
        int x=vm_vars[rx],y=vm_vars[ry];
        if(fl) display.fillRect(x,y,w,h,SSD1306_WHITE); else display.drawRect(x,y,w,h,SSD1306_WHITE); } break;
      case 0x0A:{ uint8_t b=vmByte(); uint16_t addr=vmInt16(); if(vmBtnHeld(b)) vm_pc=addr; } break;
      case 0x0B:{ int r=vmByte()&7; int16_t v=vmInt16(); uint16_t a=vmInt16(); if(vm_vars[r]<v) vm_pc=a; } break;
      case 0x0C:{ int r=vmByte()&7; int16_t v=vmInt16(); uint16_t a=vmInt16(); if(vm_vars[r]>v) vm_pc=a; } break;
      case 0x0D:{ uint16_t a=vmInt16(); vm_pc=a; } break;
      case 0x0E:{ uint8_t ms=vmByte(); delay(ms); } break;
      case 0x0F: vm_pc=vm_loopStart; break;
      case 0xFF: mode=MODE_MENU; yieldFrame=true; break;
      default: vm_error=true; break;
    }
  }
  if(vm_error){ lastScore=0; mode=MODE_GAMEOVER; }
}
void binPlayDraw(){}

// ================= ОБЩЕЕ =================
void startGame(int idx){
  currentGame=idx; mode=MODE_GAME;
  switch(idx){
    case 0: flappyReset(); break; case 1: snakeReset(); break; case 2: pongReset(); break;
    case 3: dinoReset(); break; case 4: tetrisReset(); break; case 5: siReset(); break;
    case 6: brReset(); break; case 7: pmReset(); break; case 8: mhReset(); break;
    case 9: bdReset(); break; case 10: fpsReset(); break; case 11: customReset(); break;
    case 12: binServerStart(); return; case 13: binPlayReset(); break;
    case 14: galleryReset(); break; case 15: benchReset(); break;
  }
}

void setup(){
  Serial.begin(115200);
  pinMode(PIN_UP,INPUT_PULLUP); pinMode(PIN_DOWN,INPUT_PULLUP); pinMode(PIN_LEFT,INPUT_PULLUP);
  pinMode(PIN_RIGHT,INPUT_PULLUP); pinMode(PIN_SELECT,INPUT_PULLUP); pinMode(PIN_BOOT,INPUT_PULLUP); pinMode(PIN_BACK,INPUT_PULLUP);
  Wire.begin(20,21); Wire.setClock(400000);
  bool ok=false; for(int i=0;i<3&&!ok;i++){ ok=display.begin(SSD1306_SWITCHCAPVCC,0x3C); if(!ok) delay(200); }
  if(!ok){ for(;;); }
  display.clearDisplay(); display.setTextColor(SSD1306_WHITE); display.display();
  if(!LittleFS.begin(true)) Serial.println(F("LittleFS mount failed"));
  initPsramMap(); loadSettings(); randomSeed(analogRead(1)); splashStart=millis();
}

void loop(){
  updateButtons();
  if(isHeld(BTN_SELECT)&&btnPressed[BTN_BACK]) captureScreenshot();
  if(isHeld(BTN_DOWN)&&btnPressed[BTN_SELECT]) vidToggleRecording();
  vidCaptureFrameIfDue();

  switch(mode){
    case MODE_SPLASH: updateSplash(); break;
    case MODE_MENU: updateMenu(); break;
    case MODE_SETTINGS: updateSettings(); break;
    case MODE_FORMAT_CONFIRM: updateFormatConfirm(); break;
    case MODE_GAME:
      switch(currentGame){
        case 0: flappyUpdate(); if(mode==MODE_GAME) flappyDraw(); break;
        case 1: snakeUpdate(); if(mode==MODE_GAME) snakeDraw(); break;
        case 2: pongUpdate(); if(mode==MODE_GAME) pongDraw(); break;
        case 3: dinoUpdate(); if(mode==MODE_GAME) dinoDraw(); break;
        case 4: tetrisUpdate(); if(mode==MODE_GAME) tetrisDraw(); break;
        case 5: siUpdate(); if(mode==MODE_GAME) siDraw(); break;
        case 6: brUpdate(); if(mode==MODE_GAME) brDraw(); break;
        case 7: pmUpdate(); if(mode==MODE_GAME) pmDraw(); break;
        case 8: mhUpdate(); if(mode==MODE_GAME) mhDraw(); break;
        case 9: bdUpdate(); if(mode==MODE_GAME) bdDraw(); break;
        case 10: fpsUpdate(); if(mode==MODE_GAME) fpsDraw(); break;
        case 11: customUpdate(); if(mode==MODE_GAME) customDraw(); break;
        case 12: break;
        case 13: binPlayUpdate(); if(mode==MODE_GAME) binPlayDraw(); break;
        case 14: galleryUpdate(); if(mode==MODE_GAME) galleryDraw(); break;
        case 15: benchUpdate(); if(mode==MODE_GAME) benchDraw(); break;
      }
      break;
    case MODE_BIN_SERVER: updateBinServer(); break;
    case MODE_OTA_PREPARE: updateOtaPrepare(); break;
    case MODE_OTA_UPDATING: updateOtaUpdating(); break;
    case MODE_GAMEOVER: updateGameOver(); break;
  }
}