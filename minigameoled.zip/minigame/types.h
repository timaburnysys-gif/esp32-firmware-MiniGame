#pragma once
#include <Arduino.h>

struct Combo { uint8_t a, b; };
struct Ent { float x, y; bool alive; int hp; unsigned long t; };