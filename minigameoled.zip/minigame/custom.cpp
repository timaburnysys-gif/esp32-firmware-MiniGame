#include <Arduino.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

extern Adafruit_SSD1306 display;
extern bool btnPressed[7];
extern bool isHeld(int idx);
extern bool checkExitToMenu();
extern float diffLerp(float e, float n, float h);

#define BTN_UP     0
#define BTN_DOWN   1
#define BTN_LEFT   2
#define BTN_RIGHT  3
#define BTN_SELECT 4
#define BTN_BOOT   5
#define BTN_BACK   6

enum Mode { MODE_SPLASH, MODE_MENU, MODE_SETTINGS, MODE_GAME, MODE_GAMEOVER };
extern Mode mode;
extern int lastScore;

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

const char* CUSTOM_GAME_NAME = "Defend The Core";

// ===== РИСУНКИ (Спрайты 8x8 пикселей) =====
// Рисунок башни (псевдо-3D турель)
const unsigned char bmp_tower[] PROGMEM = {
  0x18, // ...##...
  0x3C, // ..####..
  0x7E, // .######.
  0x18, // ...##...
  0x18, // ...##...
  0x5A, // .#....#.
  0x7E, // .######.
  0xFF  // ########
};

// Рисунок врага (робот-жук)
const unsigned char bmp_enemy[] PROGMEM = {
  0x42, // .#....#.
  0x24, // ..#..#..
  0x7E, // .######.
  0xFF, // ########
  0xDB, // ##.##.##
  0xFF, // ########
  0x24, // ..#..#..
  0x42  // .#....#.
};

// ===== ПЕРЕМЕННЫЕ ИГРЫ =====
int gold = 100;
int lives = 10;
int score = 0;
int wave = 1;

int cursorX = 4;
int cursorY = 2;

struct Point { float x; float y; };
const int PATH_POINTS = 4;
Point waypoints[PATH_POINTS] = {
  {0, 24}, {56, 24}, {56, 48}, {128, 48}
};

struct Enemy {
  float x, y;
  int targetWaypoint;
  float hp, maxHp;
  float speed;
  bool active;
};
#define MAX_ENEMIES 8
Enemy enemies[MAX_ENEMIES];
unsigned long lastSpawnTime = 0;
int spawnInterval = 2500;

struct Tower {
  int x, y;
  int range;
  float damage;
  unsigned long lastShot;
  int cooldown;
};
#define MAX_TOWERS 8
Tower towers[MAX_TOWERS];
int towerCount = 0;

struct Bullet {
  float x, y;
  int targetEnemyIdx;
  float speed;
  float damage;
  bool active;
};
#define MAX_BULLETS 12
Bullet bullets[MAX_BULLETS];

float getDist(float x1, float y1, float x2, float y2) {
  return sqrt(pow(x2 - x1, 2) + pow(y2 - y1, 2));
}

// ===== ИНИЦИАЛИЗАЦИЯ =====
void customReset() {
  gold = diffLerp(120, 90, 70); 
  lives = 10;
  score = 0;
  wave = 1;
  towerCount = 0;
  cursorX = 4; cursorY = 2;
  spawnInterval = 2500;
  
  for (int i = 0; i < MAX_ENEMIES; i++) enemies[i].active = false;
  for (int i = 0; i < MAX_BULLETS; i++) bullets[i].active = false;
  lastSpawnTime = millis();
}

// ===== ЛОГИКА =====
void customUpdate() {
  if (checkExitToMenu()) return;

  unsigned long currentMillis = millis();

  if (btnPressed[BTN_LEFT] && cursorX > 0) cursorX--;
  if (btnPressed[BTN_RIGHT] && cursorX < 7) cursorX++;
  if (btnPressed[BTN_UP] && cursorY > 1) cursorY--;
  if (btnPressed[BTN_DOWN] && cursorY < 3) cursorY--;

  int cx = cursorX * 16 + 8;
  int cy = cursorY * 16 + 8;

  bool onRoad = false;
  if ((cy == 24 && cx <= 56) || (cx == 56 && cy >= 24 && cy <= 48) || (cy == 48 && cx >= 56)) {
    onRoad = true;
  }

  if (btnPressed[BTN_SELECT]) {
    if (!onRoad && gold >= 40 && towerCount < MAX_TOWERS) {
      bool occupied = false;
      for (int i = 0; i < towerCount; i++) {
        if (towers[i].x == cx && towers[i].y == cy) occupied = true;
      }
      
      if (!occupied) {
        towers[towerCount] = { cx, cy, 30, 20.0, currentMillis, 1000 };
        towerCount++;
        gold -= 40;
      }
    }
  }

  if (currentMillis - lastSpawnTime > spawnInterval) {
    lastSpawnTime = currentMillis;
    for (int i = 0; i < MAX_ENEMIES; i++) {
      if (!enemies[i].active) {
        enemies[i].active = true;
        enemies[i].x = waypoints[0].x;
        enemies[i].y = waypoints[0].y;
        enemies[i].targetWaypoint = 1;
        float spawnHp = 40.0 + (score * 2.5);
        enemies[i].maxHp = spawnHp;
        enemies[i].hp = spawnHp;
        enemies[i].speed = diffLerp(0.8, 1.0, 1.3);
        
        if (spawnInterval > 800) spawnInterval -= 20; 
        break;
      }
    }
  }

  for (int i = 0; i < MAX_ENEMIES; i++) {
    if (!enemies[i].active) continue;

    Point target = waypoints[enemies[i].targetWaypoint];
    float dist = getDist(enemies[i].x, enemies[i].y, target.x, target.y);

    if (dist < enemies[i].speed) {
      enemies[i].x = target.x;
      enemies[i].y = target.y;
      enemies[i].targetWaypoint++;
      
      if (enemies[i].targetWaypoint >= PATH_POINTS) {
        enemies[i].active = false;
        lives--;
        if (lives <= 0) {
          lastScore = score;
          mode = MODE_GAMEOVER;
          return;
        }
      }
    } else {
      enemies[i].x += ((target.x - enemies[i].x) / dist) * enemies[i].speed;
      enemies[i].y += ((target.y - enemies[i].y) / dist) * enemies[i].speed;
    }
  }

  for (int i = 0; i < towerCount; i++) {
    if (currentMillis - towers[i].lastShot > towers[i].cooldown) {
      int closestEnemy = -1;
      float minDist = towers[i].range;

      for (int j = 0; j < MAX_ENEMIES; j++) {
        if (!enemies[j].active) continue;
        float d = getDist(towers[i].x, towers[i].y, enemies[j].x, enemies[j].y);
        if (d <= minDist) {
          minDist = d;
          closestEnemy = j;
        }
      }

      if (closestEnemy != -1) {
        for (int b = 0; b < MAX_BULLETS; b++) {
          if (!bullets[b].active) {
            bullets[b] = { (float)towers[i].x, (float)towers[i].y, closestEnemy, 4.0, towers[i].damage, true };
            towers[i].lastShot = currentMillis;
            break;
          }
        }
      }
    }
  }

  for (int b = 0; b < MAX_BULLETS; b++) {
    if (!bullets[b].active) continue;

    int targetIdx = bullets[b].targetEnemyIdx;
    
    if (!enemies[targetIdx].active) {
      bullets[b].active = false;
      continue;
    }

    float d = getDist(bullets[b].x, bullets[b].y, enemies[targetIdx].x, enemies[targetIdx].y);
    
    if (d < bullets[b].speed) {
      bullets[b].active = false;
      enemies[targetIdx].hp -= bullets[b].damage;

      if (enemies[targetIdx].hp <= 0) {
        enemies[targetIdx].active = false;
        gold += 15;
        score += 10;
      }
    } else {
      bullets[b].x += ((enemies[targetIdx].x - bullets[b].x) / d) * bullets[b].speed;
      bullets[b].y += ((enemies[targetIdx].y - bullets[b].y) / d) * bullets[b].speed;
    }
  }
}

// ===== ОТРИСОВКА =====
void customDraw() {
  display.clearDisplay();

  // 1. Верхняя панель
  display.setCursor(0, 0);
  display.print("G:"); display.print(gold);
  display.setCursor(45, 0);
  display.print("L:"); display.print(lives);
  display.setCursor(90, 0);
  display.print("S:"); display.print(score);
  display.drawFastHLine(0, 9, 128, 1);

  // 2. Отрисовка пути 
  for (int i = 0; i < PATH_POINTS - 1; i++) {
    display.drawLine(waypoints[i].x, waypoints[i].y - 2, waypoints[i+1].x, waypoints[i+1].y - 2, 1);
    display.drawLine(waypoints[i].x, waypoints[i].y + 2, waypoints[i+1].x, waypoints[i+1].y + 2, 1);
  }

  // 3. ОТРИСОВКА БАШЕН (Спрайты)
  for (int i = 0; i < towerCount; i++) {
    // Выводим рисунок bmp_tower. Координаты смещаем на -4, чтобы башня была ровно по центру курсора
    display.drawBitmap(towers[i].x - 4, towers[i].y - 4, bmp_tower, 8, 8, 1);
  }

  // 4. ОТРИСОВКА ВРАГОВ (Спрайты)
  for (int i = 0; i < MAX_ENEMIES; i++) {
    if (enemies[i].active) {
      // Рисуем робота-жука
      display.drawBitmap((int)enemies[i].x - 4, (int)enemies[i].y - 4, bmp_enemy, 8, 8, 1);
      
      // Полоска здоровья над врагом
      int barW = 8;
      int hpW = (int)((enemies[i].hp / enemies[i].maxHp) * barW);
      if (hpW < 0) hpW = 0;
      display.drawRect((int)enemies[i].x - 4, (int)enemies[i].y - 7, barW, 2, 1);
      display.fillRect((int)enemies[i].x - 4, (int)enemies[i].y - 7, hpW, 2, 1);
    }
  }

  // 5. Отрисовка летящих пуль
  for (int b = 0; b < MAX_BULLETS; b++) {
    if (bullets[b].active) {
      display.drawPixel((int)bullets[b].x, (int)bullets[b].y, 1);
      display.drawPixel((int)bullets[b].x - 1, (int)bullets[b].y, 1); 
    }
  }

  // 6. Курсор игрока
  int cx = cursorX * 16 + 8;
  int cy = cursorY * 16 + 8;
  
  if ((millis() / 200) % 2 == 0) {
    display.drawRect(cursorX * 16, cursorY * 16, 16, 16, 1);
  }
  
  if (gold >= 40) {
    display.drawCircle(cx, cy, 30, 1);
  } else {
    display.drawLine(cx - 2, cy - 2, cx + 2, cy + 2, 1);
    display.drawLine(cx - 2, cy + 2, cx + 2, cy - 2, 1);
  }

  display.display();
}