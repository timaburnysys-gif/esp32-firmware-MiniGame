#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Preferences.h>
#include <WiFi.h>
#include <WebServer.h>
#include <LittleFS.h>
#include <Update.h>
#include "esp_sleep.h"
#include "pins.h"

#ifndef PIN_BAT
#define PIN_BAT 4
#endif
#define BAT_CAL 1.00f

extern const char* CUSTOM_GAME_NAME;
extern void customReset();
extern void customUpdate();
extern void customDraw();

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

const int BTN_PINS[7] = {PIN_UP, PIN_DOWN, PIN_LEFT, PIN_RIGHT, PIN_SELECT, PIN_BOOT, PIN_BACK};
bool btnLast[7] = {1,1,1,1,1,1,1}, btnStable[7] = {1,1,1,1,1,1,1}, btnPressed[7];
unsigned long btnLastChange[7] = {0,0,0,0,0,0,0};
#define BTN_UP 0
#define BTN_DOWN 1
#define BTN_LEFT 2
#define BTN_RIGHT 3
#define BTN_SELECT 4
#define BTN_BOOT 5
#define BTN_BACK 6

void updateButtons() {
  unsigned long now = millis();
  for (int i = 0; i < 7; i++) {
    bool cur = digitalRead(BTN_PINS[i]);
    btnPressed[i] = false;
    if (cur != btnLast[i]) { btnLastChange[i] = now; btnLast[i] = cur; }
    if ((now - btnLastChange[i]) > 30 && cur != btnStable[i]) { btnStable[i] = cur; if (cur == LOW) btnPressed[i] = true; }
  }
}
bool isHeld(int i) { return btnStable[i] == LOW; }
bool anyButtonPressed() { for (int i = 0; i < 7; i++) if (btnPressed[i]) return true; return false; }

// ---------- Settings ----------
Preferences prefs;
int difficulty = 1, shotIdx = 0, recIdx = 1, recLenIdx = 1, fpsIdx = 1;
bool batEn = false;
const char* diffNames[3] = {"Easy","Normal","Hard"};
const Combo shotC[3] = {{BTN_SELECT,BTN_BACK},{BTN_SELECT,BTN_UP},{BTN_BOOT,BTN_SELECT}};
const Combo recC[3]  = {{BTN_DOWN,BTN_SELECT},{BTN_LEFT,BTN_RIGHT},{BTN_BOOT,BTN_DOWN}};
const char* shotN[4] = {"SEL+BACK","SEL+UP","BOOT+SEL","OFF"};
const char* recN[4]  = {"DOWN+SEL","LEFT+RIGHT","BOOT+DOWN","OFF"};
const int recSec[7] = {3,5,7,10,20,30,60};
const int fpsVal[5] = {20,30,45,60,0};
bool comboHit(const Combo& c) { return (isHeld(c.a) && btnPressed[c.b]) || (isHeld(c.b) && btnPressed[c.a]); }
float diffLerp(float e, float n, float h) { return difficulty == 0 ? e : difficulty == 2 ? h : n; }
void loadSettings() { prefs.begin("minigame", true); difficulty = prefs.getInt("diff",1); shotIdx = prefs.getInt("shot",0); recIdx = prefs.getInt("rec",1); recLenIdx = prefs.getInt("rlen",1); fpsIdx = prefs.getInt("fps",1); batEn = prefs.getBool("bat",false); prefs.end();
  if (recLenIdx < 0 || recLenIdx > 6) recLenIdx = 1; if (fpsIdx < 0 || fpsIdx > 4) fpsIdx = 1; }
void saveSettings() { prefs.begin("minigame", false); prefs.putInt("diff",difficulty); prefs.putInt("shot",shotIdx); prefs.putInt("rec",recIdx); prefs.putInt("rlen",recLenIdx); prefs.putInt("fps",fpsIdx); prefs.putBool("bat",batEn); prefs.end(); }

enum Mode { MODE_SPLASH, MODE_MENU, MODE_SETTINGS, MODE_GAME, MODE_GAMEOVER, MODE_BIN_SERVER, MODE_OTA_PREPARE, MODE_OTA_UPDATING, MODE_FORMAT_CONFIRM, MODE_CONFIRM };
Mode mode = MODE_SPLASH;
int currentGame = 0, lastScore = 0;

#define GAME_COUNT 17
const char* gameNames[GAME_COUNT] = {"Flappy Bird","Snake","Pong vs AI","Dino Run","Tetris","Space Invaders","Breakout","Pac-Man","Monster Hunt 3D","Bot Duel 3D","3D FPS Test","Custom","Bin: Upload","Bin: Play","Gallery","EspBench","DOOM"};
const char* menuTags[GAME_COUNT] = {"2D","2D","2D","2D","2D","2D","2D","2D","3D","3D","3D","2D","SYS","SYS","MEDIA","SYS","3D"};
#define MENU_ITEMS (GAME_COUNT + 1)
int menuIndex = 0;
unsigned long splashStart = 0;
void startGame(int idx);
bool checkExitToMenu() { if (btnPressed[BTN_BOOT] || btnPressed[BTN_BACK]) { mode = MODE_MENU; return true; } return false; }

// ---------- Toast / stars / battery icon ----------
char toastTxt[24]; unsigned long toastUntil = 0, warnUntil = 0;
void toast(const char* s, unsigned ms = 1300) { strncpy(toastTxt, s, 23); toastTxt[23] = 0; toastUntil = millis() + ms; }
void drawStars(int n) {
  unsigned long t = millis() / 250;
  for (int i = 0; i < n; i++) { if (((t + i * 3) % 7) == 0) continue; int x = (i * 37 + 11) % 128, y = (i * 53 + 7) % 64; display.drawPixel(x, y, 1); if (i % 6 == 0) display.drawPixel(x + 1, y, 1); }
}
void batIcon(int x, int y, int w, int h, int pct, bool cross) {
  display.drawRect(x, y, w, h, 1); display.fillRect(x + w, y + h / 4, 2, h / 2, 1);
  int f = (w - 4) * pct / 100; if (f > 0) display.fillRect(x + 2, y + 2, f, h - 4, 1);
  if (cross) { display.drawLine(x, y, x + w, y + h, 1); display.drawLine(x + 1, y, x + w + 1, y + h, 1); display.drawLine(x, y + h, x + w, y, 1); display.drawLine(x + 1, y + h, x + w + 1, y, 1); }
}

// ---------- PSRAM maps ----------
#define BD_N 10
uint8_t *bd_map = nullptr, *dm_map = nullptr;
const uint8_t BD_DEF[BD_N * BD_N] = {
  2,2,2,2,2,2,2,2,2,2, 2,0,0,0,0,0,0,0,0,2, 2,0,1,1,0,3,3,0,0,2, 2,0,1,0,0,0,3,0,4,2, 2,0,0,0,1,0,0,0,0,2,
  2,2,0,3,3,0,1,1,0,2, 2,0,0,0,0,0,1,0,0,2, 2,0,4,4,0,1,1,0,3,2, 2,0,0,0,0,0,0,0,0,2, 2,2,2,2,2,2,2,2,2,2 };
void initPsramMap() {
  bool ps = psramFound();
  bd_map = (uint8_t*)(ps ? ps_malloc(BD_N * BD_N) : malloc(BD_N * BD_N));
  dm_map = (uint8_t*)(ps ? ps_malloc(256) : malloc(256));
  memcpy(bd_map, BD_DEF, BD_N * BD_N);
}

// ================= LIGHT TEXTURED RAYCASTER =================
float rc_z[128];
bool solidAt(const uint8_t* m, int mw, int mh, float x, float y) { int ix = (int)x, iy = (int)y; if (x < 0 || y < 0 || ix >= mw || iy >= mh) return true; return m[iy * mw + ix] != 0; }
void moveTry(const uint8_t* m, int mw, int mh, float& px, float& py, float nx, float ny) { if (!solidAt(m,mw,mh,nx,py)) px = nx; if (!solidAt(m,mw,mh,px,ny)) py = ny; }
bool losClear(const uint8_t* m, int mw, int mh, float x0, float y0, float x1, float y1) {
  float dx = x1 - x0, dy = y1 - y0, d = sqrtf(dx * dx + dy * dy); int n = (int)(d / 0.15f) + 1;
  for (int i = 1; i < n; i++) { float t = (float)i / n; if (solidAt(m,mw,mh,x0 + dx * t, y0 + dy * t)) return false; }
  return true;
}
void entSpawn(Ent& e, const uint8_t* m, int mw, int mh, float px, float py) {
  for (int t = 0; t < 40; t++) { int x = random(1, mw - 1), y = random(1, mh - 1);
    if (!m[y * mw + x]) { float dx = x + .5f - px, dy = y + .5f - py; if (dx * dx + dy * dy > 6) { e.x = x + .5f; e.y = y + .5f; e.alive = true; return; } } }
  e.x = 5.5f; e.y = 5.5f; e.alive = true;
}
void rcRender(const uint8_t* m, int mw, int mh, float px, float py, float ang) {
  float dx = cosf(ang), dy = sinf(ang), plx = -dy * 0.66f, ply = dx * 0.66f;
  for (int x = 0; x < 128; x += 2) {
    float cam = 2.0f * x / 128 - 1, rdx = dx + plx * cam, rdy = dy + ply * cam;
    int mx = (int)px, my = (int)py;
    float ddx = rdx == 0 ? 1e9f : fabsf(1 / rdx), ddy = rdy == 0 ? 1e9f : fabsf(1 / rdy), sdx, sdy; int sx, sy;
    if (rdx < 0) { sx = -1; sdx = (px - mx) * ddx; } else { sx = 1; sdx = (mx + 1 - px) * ddx; }
    if (rdy < 0) { sy = -1; sdy = (py - my) * ddy; } else { sy = 1; sdy = (my + 1 - py) * ddy; }
    int side = 0, g = 0, tex = 2;
    while (g++ < 40) {
      if (sdx < sdy) { sdx += ddx; mx += sx; side = 0; } else { sdy += ddy; my += sy; side = 1; }
      if (mx < 0 || my < 0 || mx >= mw || my >= mh) break;
      if (m[my * mw + mx]) { tex = m[my * mw + mx]; break; }
    }
    float pd = side == 0 ? sdx - ddx : sdy - ddy; if (pd < 0.05f) pd = 0.05f;
    rc_z[x] = rc_z[x + 1] = pd;
    int h = (int)(64 / pd); if (h > 64) h = 64; int top = 32 - h / 2;
    bool dim = pd > 6.5f || (side && pd > 3.5f);
    if (!(dim && (x & 2))) {
      if (dim) display.drawFastVLine(x, top, h, 1); else display.fillRect(x, top, 2, h, 1);
      if (h >= 10 && !dim) {
        float wx = side == 0 ? py + pd * rdy : px + pd * rdx; wx -= floorf(wx); int u = (int)(wx * 8) & 7;
        switch (tex) {
          case 1: display.drawFastHLine(x, top + h / 2, 2, 0); if (h >= 24) { display.drawFastHLine(x, top + h / 4, 2, 0); display.drawFastHLine(x, top + 3 * h / 4, 2, 0); }
                  if (u == 0) display.drawFastVLine(x, top, h / 2, 0); else if (u == 4) display.drawFastVLine(x, top + h / 2, h - h / 2, 0); break;
          case 2: display.drawPixel(x, top + h * ((u * 5) % 8) / 8, 0); display.drawPixel(x + 1, top + h * ((u * 3 + 4) % 8) / 8, 0); break;
          case 3: display.drawFastHLine(x, top + h / 6, 2, 0); display.drawFastHLine(x, top + h - h / 6, 2, 0); if (u == 3) display.drawFastVLine(x, top + h / 3, h / 3, 0); break;
          default: if (!(u & 3)) display.drawFastVLine(x, top, h, 0); else if (u == 2) display.drawPixel(x, top + h / 2, 0); break;
        }
      }
    }
    if (!(x & 3)) { int o = ((x >> 2) & 1) * 2; display.drawPixel(x + o, 44, 1); display.drawPixel(x + 2 - o, 56, 1); }
  }
}
inline int mb(const uint8_t* M, int u, int v) { return (u < 0 || u > 7 || v < 0 || v > 7) ? 0 : ((M[v] >> (7 - u)) & 1); }
int sprPix(const uint8_t* M, const uint8_t* F, int u, int v) {
  if (!mb(M,u,v)) return -1;
  if (!mb(M,u-1,v) || !mb(M,u+1,v) || !mb(M,u,v-1) || !mb(M,u,v+1)) return 1;
  return mb(F,u,v);
}
void rcSprite(float sx, float sy, float px, float py, float ang, const uint8_t* M, const uint8_t* F, float sc) {
  float dx = cosf(ang), dy = sinf(ang), plx = -dy * 0.66f, ply = dx * 0.66f, rx = sx - px, ry = sy - py;
  float inv = 1.0f / (plx * dy - dx * ply), tx = inv * (dy * rx - dx * ry), ty = inv * (-ply * rx + plx * ry);
  if (ty < 0.2f) return;
  int scr = (int)(64 * (1 + tx / ty)), sz = (int)(64 / ty * sc); if (sz < 2) return; if (sz > 40) sz = 40;
  int yTop = 32 + (int)(32 / ty) - sz, xL = scr - sz / 2;
  for (int x = xL; x < xL + sz; x++) {
    if (x < 0 || x >= 128 || rc_z[x] < ty) continue;
    int u = (x - xL) * 8 / sz;
    for (int y = yTop; y < yTop + sz; y++) { if (y < 0 || y >= 64) continue; int p = sprPix(M, F, u, (y - yTop) * 8 / sz); if (p >= 0) display.drawPixel(x, y, p); }
  }
}
void drawEnts(Ent* e, int n, float px, float py, float ang, const uint8_t* M, const uint8_t* F, float sc) {
  int idx[8]; float d[8]; int c = 0;
  for (int i = 0; i < n && i < 8; i++) if (e[i].alive) { idx[c] = i; d[c] = (e[i].x - px) * (e[i].x - px) + (e[i].y - py) * (e[i].y - py); c++; }
  for (int i = 0; i < c; i++) for (int j = 0; j < c - 1 - i; j++) if (d[j] < d[j+1]) { float t = d[j]; d[j] = d[j+1]; d[j+1] = t; int k = idx[j]; idx[j] = idx[j+1]; idx[j+1] = k; }
  for (int i = 0; i < c; i++) rcSprite(e[idx[i]].x, e[idx[i]].y, px, py, ang, M, F, sc);
}
bool aimAt(float ex, float ey, float px, float py, float ang, float tol, float& dist) {
  float dx = cosf(ang), dy = sinf(ang), plx = -dy * 0.66f, ply = dx * 0.66f, rx = ex - px, ry = ey - py;
  float inv = 1.0f / (plx * dy - dx * ply), tx = inv * (dy * rx - dx * ry), ty = inv * (-ply * rx + plx * ry);
  if (ty < 0.2f) return false; float lat = tx / ty; if (fabsf(lat) > tol) return false;
  int col = (int)(64 * (1 + lat)); if (col < 0) col = 0; if (col > 127) col = 127;
  if (ty > rc_z[col] + 0.3f) return false; dist = ty; return true;
}
const uint8_t SP_IMP_M[8] = {0x3C,0x7E,0xFF,0x7E,0xFF,0xFF,0x7E,0x66}, SP_IMP_F[8] = {0,0,0x24,0,0x18,0,0,0};
const uint8_t SP_SOL_M[8] = {0x3C,0x3C,0x18,0x7E,0x7E,0x7E,0x66,0x66}, SP_SOL_F[8] = {0,0x3C,0,0,0x18,0,0,0};
const uint8_t SP_HP_M[8]  = {0,0x18,0x18,0x7E,0x7E,0x18,0x18,0}, SP_HP_F[8] = {0,0,0x18,0x3C,0x3C,0x18,0,0};
const uint8_t SP_AM_M[8]  = {0,0,0x7E,0x7E,0x7E,0x7E,0x7E,0}, SP_AM_F[8] = {0,0,0,0x5A,0x5A,0,0,0};
void drawGun(int type, bool firing) {
  int y = firing ? 50 : 54, cx = 64;
  if (type == 0) { display.fillRect(cx-5,y-2,10,16,0); display.fillRect(cx-3,y,6,14,1); display.fillRect(cx-1,y-6,2,7,1); }
  else { display.fillRect(cx-7,y-2,14,18,0); display.fillRect(cx-6,y,5,16,1); display.fillRect(cx+1,y,5,16,1); display.fillRect(cx-6,y-4,4,5,1); display.fillRect(cx+2,y-4,4,5,1); }
  if (firing) { display.fillTriangle(cx-7,y-5,cx+7,y-5,cx,y-17,1); display.fillTriangle(cx-3,y-9,cx+3,y-9,cx,y-15,0); }
}

// ================= PNG =================
#define GALLERY_DIR "/gallery"
#define VIDEO_DIR "/video"
uint32_t png_crc[256]; bool png_crcReady = false;
uint32_t pngCrc32(const uint8_t* b, size_t n) {
  if (!png_crcReady) { for (uint32_t i = 0; i < 256; i++) { uint32_t c = i; for (int k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >> 1)) : (c >> 1); png_crc[i] = c; } png_crcReady = true; }
  uint32_t c = 0xFFFFFFFF; for (size_t i = 0; i < n; i++) c = png_crc[(c ^ b[i]) & 0xFF] ^ (c >> 8); return c ^ 0xFFFFFFFF;
}
uint32_t pngAdler(const uint8_t* b, size_t n) { uint32_t a = 1, s = 0; for (size_t i = 0; i < n; i++) { a = (a + b[i]) % 65521; s = (s + a) % 65521; } return (s << 16) | a; }
void be32(uint8_t* o, uint32_t v) { o[0] = v >> 24; o[1] = v >> 16; o[2] = v >> 8; o[3] = v; }
void pngChunk(File& f, const char* type, const uint8_t* d, uint32_t len) {
  uint8_t l[4]; be32(l, len); f.write(l, 4); f.write((const uint8_t*)type, 4); if (len) f.write(d, len);
  uint8_t* cb = (uint8_t*)malloc(4 + len); memcpy(cb, type, 4); if (len) memcpy(cb + 4, d, len);
  uint8_t c[4]; be32(c, pngCrc32(cb, 4 + len)); free(cb); f.write(c, 4);
}
bool savePng(uint8_t* src, const char* path) {
  const int w = 128, h = 64, rb = 16, rawLen = h * (1 + rb); bool ps = psramFound();
  uint8_t* raw = (uint8_t*)(ps ? ps_malloc(rawLen) : malloc(rawLen)); if (!raw) return false; memset(raw, 0, rawLen);
  for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) if ((src[x + (y / 8) * 128] >> (y & 7)) & 1) raw[y * (1 + rb) + 1 + x / 8] |= 1 << (7 - (x % 8));
  int zl = 2 + 5 + rawLen + 4; uint8_t* z = (uint8_t*)(ps ? ps_malloc(zl) : malloc(zl)); if (!z) { free(raw); return false; }
  int p = 0; z[p++] = 0x78; z[p++] = 1; z[p++] = 1; z[p++] = rawLen & 255; z[p++] = rawLen >> 8; uint16_t nl = ~rawLen; z[p++] = nl & 255; z[p++] = nl >> 8;
  memcpy(z + p, raw, rawLen); p += rawLen; be32(z + p, pngAdler(raw, rawLen)); free(raw);
  File f = LittleFS.open(path, "w"); if (!f) { free(z); return false; }
  const uint8_t sig[8] = {137,80,78,71,13,10,26,10}; f.write(sig, 8); uint8_t ih[13] = {0,0,0,128,0,0,0,64,1,0,0,0,0};
  pngChunk(f, "IHDR", ih, 13); pngChunk(f, "IDAT", z, zl); pngChunk(f, "IEND", nullptr, 0); f.close(); free(z); return true;
}
bool loadPng(const char* path, uint8_t* dst) {
  File f = LittleFS.open(path, "r"); if (!f) return false; uint8_t sig[8]; f.read(sig, 8); uint8_t* idat = nullptr;
  while (f.available()) {
    uint8_t lb[4]; if (f.read(lb, 4) != 4) break; uint32_t len = ((uint32_t)lb[0] << 24) | (lb[1] << 16) | (lb[2] << 8) | lb[3]; char ty[5] = {0}; f.read((uint8_t*)ty, 4);
    if (!strcmp(ty, "IDAT")) { idat = (uint8_t*)(psramFound() ? ps_malloc(len) : malloc(len)); if (!idat) { f.close(); return false; } f.read(idat, len); f.seek(f.position() + 4); }
    else f.seek(f.position() + len + 4);
    if (!strcmp(ty, "IEND")) break;
  }
  f.close(); if (!idat) return false; uint8_t* raw = idat + 7;
  for (int y = 0; y < 64; y++) for (int x = 0; x < 128; x++) { bool on = (raw[y * 17 + 1 + x / 8] >> (7 - (x % 8))) & 1; int i = x + (y / 8) * 128; if (on) dst[i] |= 1 << (y & 7); else dst[i] &= ~(1 << (y & 7)); }
  free(idat); return true;
}
int nextIndex(const char* dirPath) {
  if (!LittleFS.exists(dirPath)) LittleFS.mkdir(dirPath);
  int mx = 0; File d = LittleFS.open(dirPath); File e = d.openNextFile();
  while (e) { String n = e.name(); int us = n.lastIndexOf('_'), dot = n.lastIndexOf('.'); if (us >= 0 && dot > us) { int i = n.substring(us + 1, dot).toInt(); if (i > mx) mx = i; } e = d.openNextFile(); }
  return mx + 1;
}
void captureScreenshot() { char p[48]; snprintf(p, sizeof(p), "%s/shot_%04d.png", GALLERY_DIR, nextIndex(GALLERY_DIR)); toast(savePng(display.getBuffer(), p) ? "Screenshot saved" : "Shot FAILED"); }

// ================= VIDEO =================
#define VID_INT 100
bool vid_on = false; File vid_file; int vid_frames = 0, vid_max = 50; unsigned long vid_t = 0;
bool vidStart() {
  if (!LittleFS.exists(VIDEO_DIR) && !LittleFS.mkdir(VIDEO_DIR)) return false;
  char p[48]; snprintf(p, sizeof(p), "%s/vid_%04d.mgv", VIDEO_DIR, nextIndex(VIDEO_DIR));
  vid_file = LittleFS.open(p, "w"); if (!vid_file) return false;
  uint8_t h[8] = {'M','G','V','D',128,64,VID_INT & 255, VID_INT >> 8}; vid_file.write(h, 8);
  vid_max = recSec[recLenIdx] * 10; vid_frames = 0; vid_on = true; vid_t = millis(); return true;
}
void vidStop(bool ok = true) { if (vid_file) vid_file.close(); vid_on = false; toast(ok ? "Video saved" : "Disk full"); }
void vidToggle() { if (vid_on) vidStop(); else { char b[24]; snprintf(b, 24, "REC start (%ds)", recSec[recLenIdx]); toast(vidStart() ? b : "REC FAIL: no FS"); } }
void vidTick() {
  if (!vid_on || millis() - vid_t < VID_INT) return; vid_t = millis();
  if (LittleFS.totalBytes() - LittleFS.usedBytes() < 30000) { vidStop(false); return; }
  if (vid_file.write(display.getBuffer(), 1024) != 1024) { vidStop(false); return; }
  if (++vid_frames >= vid_max) vidStop();
}

// ================= BATTERY =================
float batV = 0; int batRaw = 100, batLow = 0; bool batWarned = false; unsigned long batT = 0;
float readBatV() { uint32_t s = 0; for (int i = 0; i < 8; i++) s += analogReadMilliVolts(PIN_BAT); return s / 8000.0f * 2.0f * BAT_CAL; }
int rawPct(float v) { int p = (int)((v - 3.30f) / 0.90f * 100 + 0.5f); return p < 0 ? 0 : p > 100 ? 100 : p; }
int shownPct() { if (batRaw <= 10) return 0; int p = (batRaw - 10) * 100 / 90; return p > 100 ? 100 : p; }
void batShutdown() {
  if (vid_on) vidStop();
  display.invertDisplay(false); display.clearDisplay(); drawStars(30); batIcon(44, 10, 40, 20, 0, true);
  display.setTextSize(1); display.setTextColor(1, 0); display.setCursor(22, 38); display.print(F("Charge battery")); display.setCursor(22, 50); display.print(F("Shutting down.."));
  display.display(); delay(3500); display.ssd1306_command(SSD1306_DISPLAYOFF);
  esp_sleep_enable_timer_wakeup(60ULL * 1000000ULL); esp_deep_sleep_start();
}
void batTick() {
  if (!batEn || millis() - batT < 2000) return; batT = millis();
  float v = readBatV(); batV = batV == 0 ? v : batV * 0.7f + v * 0.3f; batRaw = rawPct(batV);
  if (batRaw <= 10) { if (++batLow >= 3) batShutdown(); } else batLow = 0;
  if (batRaw <= 20 && !batWarned) { batWarned = true; warnUntil = millis() + 4000; }
  if (batRaw > 25) batWarned = false;
}
void drawOverlays() {
  bool t = millis() < toastUntil, w = millis() < warnUntil; if (!t && !w) return;
  display.setTextSize(1);
  if (w) { display.fillRect(6, 14, 116, 34, 0); display.drawRect(6, 14, 116, 34, 1); display.setTextColor(1, 0);
    display.setCursor(10, 18); display.print(F("Battery low: ")); display.print(shownPct()); display.print('%');
    display.setCursor(10, 28); display.print(F("Device will turn")); display.setCursor(10, 38); display.print(F("off at 0%. Charge!")); }
  if (t) { display.fillRect(0, 55, 128, 9, 0); display.setTextColor(1, 0); display.setCursor(2, 56); display.print(toastTxt); }
  display.setTextColor(1); display.display();
}

// ================= GALLERY =================
#define GMAX 64
struct MediaItem { String path; bool isVideo; };
MediaItem gItems[GMAX]; int gCount, gIndex; bool gView; uint8_t* gBuf = nullptr; File gVid; unsigned long gVidT; int gVidIv = 100;
void galleryScan(const char* d, bool isVid) {
  if (!LittleFS.exists(d)) return; File dir = LittleFS.open(d); File e = dir.openNextFile();
  while (e && gCount < GMAX) { if (!e.isDirectory()) { gItems[gCount].path = String(e.path()); gItems[gCount].isVideo = isVid; gCount++; } e = dir.openNextFile(); }
}
void galleryReset() {
  gCount = 0; gIndex = 0; gView = false;
  if (!LittleFS.exists(GALLERY_DIR)) LittleFS.mkdir(GALLERY_DIR); if (!LittleFS.exists(VIDEO_DIR)) LittleFS.mkdir(VIDEO_DIR);
  galleryScan(GALLERY_DIR, false); galleryScan(VIDEO_DIR, true); if (!gBuf) gBuf = (uint8_t*)(psramFound() ? ps_malloc(1024) : malloc(1024));
}
void galleryUpdate() {
  if (checkExitToMenu()) return;
  if (gView) {
    if (gItems[gIndex].isVideo && gVid && millis() - gVidT >= (unsigned long)gVidIv) { gVidT = millis(); if (gVid.available() < 1024) gVid.seek(8); gVid.read(gBuf, 1024); }
    if (btnPressed[BTN_SELECT]) { if (gVid) gVid.close(); gView = false; } return;
  }
  if (!gCount) return;
  if (btnPressed[BTN_UP]) gIndex = (gIndex + gCount - 1) % gCount; if (btnPressed[BTN_DOWN]) gIndex = (gIndex + 1) % gCount;
  if (btnPressed[BTN_SELECT]) {
    if (gItems[gIndex].isVideo) { gVid = LittleFS.open(gItems[gIndex].path.c_str(), "r"); if (gVid) { uint8_t h[8]; gVid.read(h, 8); gVidIv = h[6] | (h[7] << 8); if (gVidIv < 30) gVidIv = 100; memset(gBuf, 0, 1024); gVidT = 0; gView = true; } }
    else if (loadPng(gItems[gIndex].path.c_str(), gBuf)) gView = true;
  }
}
void galleryDraw() {
  display.clearDisplay();
  String full = gCount ? gItems[gIndex].path : String(""); int sl = full.lastIndexOf('/'); String nm = sl >= 0 ? full.substring(sl + 1) : full;
  if (gView) { memcpy(display.getBuffer(), gBuf, 1024); display.fillRect(0, 0, 128, 9, 0); display.setTextColor(1, 0); display.setCursor(2, 1); display.print(nm); display.setTextColor(1); display.display(); return; }
  drawStars(20); display.setTextSize(1); display.setTextColor(1, 0); display.setCursor(40, 0); display.print(F("GALLERY")); display.drawFastHLine(0, 9, 128, 1);
  if (!gCount) { display.setCursor(24, 28); display.print(F("No media yet")); }
  else { display.setCursor(2, 14); display.print(gIndex + 1); display.print(F(" / ")); display.print(gCount); display.setCursor(2, 26); display.print(nm);
    display.setCursor(2, 36); display.print(gItems[gIndex].isVideo ? F("[VIDEO]") : F("[PHOTO]")); display.setCursor(2, 46); display.print(F("SELECT: view")); }
  display.setCursor(2, 56); display.print(F("BOOT/BACK: exit")); display.setTextColor(1); display.display();
}

// ================= ESPBENCH =================
enum BenchStage { B_IDLE, B_CPU, B_MEM, B_PSRAM, B_FLASH, B_DONE };
BenchStage bStage = B_IDLE; long bCpu, bMem, bPs, bFl;
void benchReset() { bStage = B_IDLE; bCpu = bMem = bPs = bFl = 0; }
long benchCpu(unsigned long d) { unsigned long s = millis(); long c = 0; volatile float x = 1.0001f; while (millis() - s < d) for (int i = 0; i < 1000; i++) { x = x * 1.0000001f + 0.0000001f; c++; } return c; }
long benchMem(unsigned long d) { unsigned long s = millis(); long c = 0; uint8_t* b = (uint8_t*)malloc(4096); if (!b) return 0; while (millis() - s < d) { for (int i = 0; i < 4096; i++) b[i] = i ^ c; c++; } free(b); return c; }
long benchPs(unsigned long d) { if (!psramFound()) return -1; unsigned long s = millis(); long c = 0; uint8_t* b = (uint8_t*)ps_malloc(65536); if (!b) return 0; while (millis() - s < d) { for (int i = 0; i < 65536; i += 64) b[i] = i ^ c; c++; } free(b); return c; }
long benchFl(unsigned long d) { unsigned long s = millis(); long c = 0; uint8_t ch[512]; memset(ch, 7, 512); while (millis() - s < d) { File f = LittleFS.open("/bench.tmp", "w"); if (!f) break; f.write(ch, 512); f.close(); c++; } LittleFS.remove("/bench.tmp"); return c; }
void benchUpdate() {
  if (checkExitToMenu()) return;
  if (bStage == B_IDLE) { if (btnPressed[BTN_SELECT]) bStage = B_CPU; return; }
  if (bStage == B_DONE) { if (btnPressed[BTN_SELECT]) benchReset(); return; }
  switch (bStage) { case B_CPU: bCpu = benchCpu(1000); bStage = B_MEM; break; case B_MEM: bMem = benchMem(1000); bStage = B_PSRAM; break; case B_PSRAM: bPs = benchPs(1000); bStage = B_FLASH; break; case B_FLASH: bFl = benchFl(800); bStage = B_DONE; break; default: break; }
}
void benchDraw() {
  display.clearDisplay(); drawStars(16); display.setTextSize(1); display.setTextColor(1, 0); display.setCursor(34, 0); display.print(F("ESPBENCH")); display.drawFastHLine(0, 9, 128, 1);
  if (bStage == B_IDLE) { display.setCursor(5, 22); display.print(F("SELECT: run test")); display.setCursor(5, 34); display.print(F("CPU/RAM/PSRAM/Flash")); }
  else if (bStage == B_DONE) { display.setCursor(2, 12); display.print(F("CPU:   ")); display.print(bCpu); display.setCursor(2, 22); display.print(F("RAM:   ")); display.print(bMem);
    display.setCursor(2, 32); display.print(F("PSRAM: ")); if (bPs < 0) display.print(F("N/A")); else display.print(bPs); display.setCursor(2, 42); display.print(F("Flash: ")); display.print(bFl); display.setCursor(2, 53); display.print(F("SELECT: again")); }
  else { display.setCursor(30, 28); display.print(F("Running...")); }
  display.setTextColor(1); display.display();
}

// ================= SPLASH (старая иконка) / MENU =================
void drawGamepadIcon(int cx, int cy) {
  display.fillRoundRect(cx - 24, cy - 10, 48, 22, 6, 1);
  display.fillRect(cx - 16, cy - 4, 3, 9, 0); display.fillRect(cx - 19, cy - 1, 9, 3, 0);
  display.fillCircle(cx + 12, cy - 3, 2, 0); display.fillCircle(cx + 18, cy + 2, 2, 0);
}
void drawSplash() { display.clearDisplay(); drawGamepadIcon(64, 24); display.setTextSize(2); display.setTextColor(1, 0); display.setCursor(4, 44); display.print(F("MiniGame")); display.setTextSize(1); display.setTextColor(1); display.display(); }
void updateSplash() { drawSplash(); if (millis() - splashStart > 2000 || anyButtonPressed()) mode = MODE_MENU; }

float mHi = 12, mTgt = 12; unsigned long mAnim = 0;
void drawMenu() {
  display.clearDisplay(); drawStars(26); display.setTextSize(1);
  display.setTextColor(1, 0); display.setCursor(2, 0); display.print(F("* MiniGame *")); display.drawFastHLine(0, 9, 128, 1);
  if (batEn) { batIcon(106, 0, 18, 8, shownPct(), false); display.setCursor(84, 0); if (shownPct() < 100) display.print(' '); if (shownPct() < 10) display.print(' '); display.print(shownPct()); }
  else { display.setCursor(104, 0); display.print(F("USB")); }
  int vis = 4, sc = menuIndex >= vis ? menuIndex - vis + 1 : 0; if (sc > MENU_ITEMS - vis) sc = MENU_ITEMS - vis;
  mTgt = 12 + (menuIndex - sc) * 10;
  if (millis() - mAnim > 10) { mAnim = millis(); float d = mTgt - mHi; mHi = fabsf(d) < 0.5f ? mTgt : mHi + d * 0.45f; }
  display.fillRoundRect(2, (int)mHi, 120, 9, 2, 1);
  for (int i = 0; i < vis && sc + i < MENU_ITEMS; i++) {
    int idx = sc + i, ry = 12 + i * 10; bool sel = idx == menuIndex;
    const char* lb = idx < GAME_COUNT ? (idx == 11 ? CUSTOM_GAME_NAME : gameNames[idx]) : "Settings"; const char* tg = idx < GAME_COUNT ? menuTags[idx] : "SYS";
    display.setTextColor(sel ? 0 : 1, sel ? 1 : 0); display.setCursor(8, ry + 1); display.print(lb); display.setCursor(96, ry + 1); display.print(tg);
  }
  int barH = 40, th = barH * vis / MENU_ITEMS; if (th < 4) th = 4; int ty = 12 + (barH - th) * sc / (MENU_ITEMS - vis);
  display.drawFastVLine(126, 12, barH, 1); display.fillRect(125, ty, 3, th, 1);
  display.drawFastHLine(0, 55, 128, 1); display.setTextColor(1, 0); display.setCursor(2, 56); display.print(F("SEL:open  BOOT/BACK:exit")); display.setTextColor(1); display.display();
}
void updateMenu() {
  if (btnPressed[BTN_UP]) menuIndex = (menuIndex + MENU_ITEMS - 1) % MENU_ITEMS; if (btnPressed[BTN_DOWN]) menuIndex = (menuIndex + 1) % MENU_ITEMS;
  if (btnPressed[BTN_SELECT]) { if (menuIndex < GAME_COUNT) startGame(menuIndex); else mode = MODE_SETTINGS; }
  drawMenu();
}

// ================= SETTINGS =================
#define S_ROWS 7
int sCur = 0, pendingRec = 1; bool confirmYes = false;
void drawSettings() {
  display.clearDisplay(); drawStars(12); display.setTextSize(1); display.setTextColor(1, 0); display.setCursor(40, 0); display.print(F("SETTINGS")); display.drawFastHLine(0, 9, 128, 1);
  char b[S_ROWS][24];
  snprintf(b[0], 24, "Difficulty: %s", diffNames[difficulty]); snprintf(b[1], 24, "Shot: %s", shotN[shotIdx]); snprintf(b[2], 24, "Rec:  %s", recN[recIdx]);
  snprintf(b[3], 24, "Rec len: %d sec", recSec[recLenIdx]);
  if (fpsVal[fpsIdx]) snprintf(b[4], 24, "FPS cap: %d", fpsVal[fpsIdx]); else snprintf(b[4], 24, "FPS cap: unlimited");
  if (batEn) snprintf(b[5], 24, "Battery: ON %d%%", shownPct()); else snprintf(b[5], 24, "Battery: OFF");
  snprintf(b[6], 24, "Format storage");
  int sc = sCur > 4 ? sCur - 4 : 0;
  for (int i = 0; i < 5; i++) { display.setCursor(2, 12 + i * 9); display.print(sc + i == sCur ? "> " : "  "); display.print(b[sc + i]); }
  display.setCursor(2, 56); display.print(F("L/R:change  BACK:save")); display.setTextColor(1); display.display();
}
void settingsChange(int dir) {
  if (sCur == 0) difficulty = (difficulty + 3 + dir) % 3;
  else if (sCur == 1) shotIdx = (shotIdx + 4 + dir) % 4;
  else if (sCur == 2) recIdx = (recIdx + 4 + dir) % 4;
  else if (sCur == 3) { int n = (recLenIdx + 7 + dir) % 7; if (recSec[n] > 7) { pendingRec = n; confirmYes = false; mode = MODE_CONFIRM; } else recLenIdx = n; }
  else if (sCur == 4) fpsIdx = (fpsIdx + 5 + dir) % 5;
  else if (sCur == 5) { batEn = !batEn; batV = 0; batLow = 0; batT = 0; }
}
void updateSettings() {
  if (btnPressed[BTN_UP]) sCur = (sCur + S_ROWS - 1) % S_ROWS; if (btnPressed[BTN_DOWN]) sCur = (sCur + 1) % S_ROWS;
  if (btnPressed[BTN_LEFT]) settingsChange(-1); if (btnPressed[BTN_RIGHT]) settingsChange(1);
  if (btnPressed[BTN_SELECT]) { if (sCur == 6) mode = MODE_FORMAT_CONFIRM; else settingsChange(1); }
  if (mode == MODE_SETTINGS && (btnPressed[BTN_BOOT] || btnPressed[BTN_BACK])) { saveSettings(); mode = MODE_MENU; }
  if (mode == MODE_SETTINGS) drawSettings();
}
void updateConfirm() {
  if (btnPressed[BTN_LEFT] || btnPressed[BTN_RIGHT] || btnPressed[BTN_UP] || btnPressed[BTN_DOWN]) confirmYes = !confirmYes;
  if (btnPressed[BTN_SELECT]) { if (confirmYes) recLenIdx = pendingRec; mode = MODE_SETTINGS; return; }
  if (btnPressed[BTN_BOOT] || btnPressed[BTN_BACK]) { mode = MODE_SETTINGS; return; }
  display.clearDisplay(); display.setTextSize(1); display.setTextColor(1, 0);
  display.setCursor(4, 2); display.print(F("Device can lag and it")); display.setCursor(4, 12); display.print(F("need more mb,")); display.setCursor(4, 22); display.print(F("continue?"));
  display.setCursor(4, 34); display.print(recSec[pendingRec]); display.print(F(" sec video"));
  if (confirmYes) { display.fillRect(8, 46, 44, 14, 1); display.setTextColor(0, 1); } else display.drawRect(8, 46, 44, 14, 1);
  display.setCursor(21, 50); display.print(F("YES")); display.setTextColor(1, 0);
  if (!confirmYes) { display.fillRect(76, 46, 44, 14, 1); display.setTextColor(0, 1); } else display.drawRect(76, 46, 44, 14, 1);
  display.setCursor(93, 50); display.print(F("NO")); display.setTextColor(1); display.display();
}
void formatDeleteDir(const char* d) {
  if (!LittleFS.exists(d)) return;
  for (int pass = 0; pass < 20; pass++) {
    String p[GMAX]; int n = 0; File dir = LittleFS.open(d); File e = dir.openNextFile();
    while (e && n < GMAX) { if (!e.isDirectory()) p[n++] = String(e.path()); e = dir.openNextFile(); }
    dir.close(); if (!n) break; for (int i = 0; i < n; i++) LittleFS.remove(p[i]);
  }
}
void updateFormatConfirm() {
  if (btnPressed[BTN_SELECT]) { if (vid_on) vidStop(); formatDeleteDir(GALLERY_DIR); formatDeleteDir(VIDEO_DIR); toast("Formatted!"); mode = MODE_SETTINGS; return; }
  if (btnPressed[BTN_BOOT] || btnPressed[BTN_BACK]) { mode = MODE_SETTINGS; return; }
  display.clearDisplay(); display.setTextSize(1); display.setCursor(10, 10); display.print(F("Delete ALL photos")); display.setCursor(10, 20); display.print(F("and videos?"));
  display.setCursor(4, 38); display.print(F("SELECT: confirm")); display.setCursor(4, 48); display.print(F("BOOT/BACK: cancel")); display.display();
}
void updateGameOver() {
  if (btnPressed[BTN_SELECT]) { startGame(currentGame); return; }
  if (btnPressed[BTN_BOOT] || btnPressed[BTN_BACK]) { mode = MODE_MENU; return; }
  display.clearDisplay(); drawStars(24); display.setTextSize(1); display.setTextColor(1, 0);
  display.setCursor(35, 8); display.print(F("GAME OVER")); display.setCursor(30, 24); display.print(F("Score: ")); display.print(lastScore);
  display.setCursor(4, 44); display.print(F("SELECT - restart")); display.setCursor(4, 54); display.print(F("BOOT/BACK - menu")); display.setTextColor(1); display.display();
}

// ================= FLAPPY =================
float f_y, f_v; int f_score; struct FPipe { float x; int gap; } f_p[3]; bool f_passed[3]; unsigned long f_last; int F_GAP; float F_SPD;
void flappyReset() { f_y = 32; f_v = 0; f_score = 0; F_GAP = (int)diffLerp(34, 26, 20); F_SPD = diffLerp(1.2, 1.6, 2.2);
  for (int i = 0; i < 3; i++) { f_p[i].x = 128 + i * 50; f_p[i].gap = random(6, 58 - F_GAP); f_passed[i] = false; } f_last = millis(); }
void flappyUpdate() {
  if (checkExitToMenu()) return; if (btnPressed[BTN_SELECT]) f_v = -3.2;
  if (millis() - f_last < 30) return; f_last = millis(); f_v += 0.35; f_y += f_v;
  for (int i = 0; i < 3; i++) { f_p[i].x -= F_SPD; if (!f_passed[i] && f_p[i].x + 10 < 20) { f_score++; f_passed[i] = true; }
    if (f_p[i].x + 10 < 0) { float mx = 0; for (int j = 0; j < 3; j++) if (f_p[j].x > mx) mx = f_p[j].x; f_p[i].x = mx + 50; f_p[i].gap = random(6, 58 - F_GAP); f_passed[i] = false; } }
  bool hit = f_y < 0 || f_y + 3 > 64;
  for (int i = 0; i < 3; i++) if (23 > f_p[i].x && 20 < f_p[i].x + 10 && (f_y < f_p[i].gap || f_y + 3 > f_p[i].gap + F_GAP)) hit = true;
  if (hit) { lastScore = f_score; mode = MODE_GAMEOVER; }
}
void flappyDraw() {
  display.clearDisplay(); for (int i = 0; i < 3; i++) { int px = (int)f_p[i].x; display.fillRect(px, 0, 10, f_p[i].gap, 1); display.fillRect(px, f_p[i].gap + F_GAP, 10, 64 - f_p[i].gap - F_GAP, 1); }
  display.fillRect(20, (int)f_y, 3, 3, 1); display.setCursor(2, 2); display.print(f_score); display.display();
}

// ================= SNAKE =================
#define CELL 8
#define GRID_W 16
#define GRID_H 7
#define GOY 8
#define SNAKE_MAX 100
int sx_[SNAKE_MAX], sy_[SNAKE_MAX], s_dx, s_dy, s_len, s_fx, s_fy, s_score, s_iv; unsigned long s_last;
void snakeFood() { bool ok; do { ok = true; s_fx = random(0, GRID_W); s_fy = random(0, GRID_H); for (int i = 0; i < s_len; i++) if (sx_[i] == s_fx && sy_[i] == s_fy) ok = false; } while (!ok); }
void snakeReset() { s_len = 3; for (int i = 0; i < 3; i++) { sx_[i] = 5 - i; sy_[i] = 3; } s_dx = 1; s_dy = 0; s_score = 0; s_iv = (int)diffLerp(180, 130, 90); snakeFood(); s_last = millis(); }
void snakeUpdate() {
  if (checkExitToMenu()) return;
  if (btnPressed[BTN_UP] && s_dy == 0) { s_dx = 0; s_dy = -1; } if (btnPressed[BTN_DOWN] && s_dy == 0) { s_dx = 0; s_dy = 1; }
  if (btnPressed[BTN_LEFT] && s_dx == 0) { s_dx = -1; s_dy = 0; } if (btnPressed[BTN_RIGHT] && s_dx == 0) { s_dx = 1; s_dy = 0; }
  if (millis() - s_last < (unsigned long)s_iv) return; s_last = millis();
  int nx = sx_[0] + s_dx, ny = sy_[0] + s_dy; bool dead = nx < 0 || nx >= GRID_W || ny < 0 || ny >= GRID_H;
  for (int i = 0; i < s_len && !dead; i++) if (sx_[i] == nx && sy_[i] == ny) dead = true;
  if (dead) { lastScore = s_score; mode = MODE_GAMEOVER; return; }
  bool grow = nx == s_fx && ny == s_fy;
  for (int i = s_len - 1; i > 0; i--) { sx_[i] = sx_[i-1]; sy_[i] = sy_[i-1]; } sx_[0] = nx; sy_[0] = ny;
  if (grow) { if (s_len < SNAKE_MAX) { sx_[s_len] = sx_[s_len-1]; sy_[s_len] = sy_[s_len-1]; s_len++; } s_score++; if (s_iv > 60) s_iv -= 2; snakeFood(); }
}
void snakeDraw() {
  display.clearDisplay(); display.drawRect(0, GOY - 1, GRID_W * CELL + 1, GRID_H * CELL + 2, 1);
  for (int i = 1; i < s_len; i++) display.fillRect(sx_[i] * CELL + 1, GOY + sy_[i] * CELL + 1, CELL - 2, CELL - 2, 1);
  int hx = sx_[0] * CELL, hy = GOY + sy_[0] * CELL; display.fillRect(hx, hy, CELL, CELL, 1);
  int ex = s_dx == 1 ? CELL - 3 : s_dx == -1 ? 1 : CELL / 2 - 1, ey = s_dy == 1 ? CELL - 3 : s_dy == -1 ? 1 : CELL / 2 - 1;
  if (s_dx) { display.drawPixel(hx + ex, hy + 2, 0); display.drawPixel(hx + ex, hy + CELL - 3, 0); } else { display.drawPixel(hx + 2, hy + ey, 0); display.drawPixel(hx + CELL - 3, hy + ey, 0); }
  int fx = s_fx * CELL + 4, fy = GOY + s_fy * CELL + 4; display.fillTriangle(fx, fy - 3, fx - 3, fy, fx + 3, fy, 1); display.fillTriangle(fx, fy + 3, fx - 3, fy, fx + 3, fy, 1);
  display.setCursor(2, 0); display.print(F("Score: ")); display.print(s_score); display.display();
}

// ================= PONG =================
float p_bx, p_by, p_vx, p_vy, p_py, p_ay, p_ai; int p_score; unsigned long p_last;
void pongServe(int d) { p_bx = 64; p_by = random(16, 48); p_vx = 1.6 * d; p_vy = random(0, 2) ? 1.0 : -1.0; }
void pongReset() { p_py = 25; p_ay = 25; p_score = 0; p_ai = diffLerp(1.1, 1.6, 2.3); pongServe(-1); p_last = millis(); }
void pongUpdate() {
  if (checkExitToMenu()) return;
  if (isHeld(BTN_UP)) p_py -= 2.2; if (isHeld(BTN_DOWN)) p_py += 2.2; if (p_py < 0) p_py = 0; if (p_py + 14 > 64) p_py = 50;
  if (millis() - p_last < 25) return; p_last = millis();
  float c = p_ay + 7; if (c < p_by - 2) p_ay += p_ai; else if (c > p_by + 2) p_ay -= p_ai; if (p_ay < 0) p_ay = 0; if (p_ay + 14 > 64) p_ay = 50;
  p_bx += p_vx; p_by += p_vy; if (p_by <= 0 || p_by >= 62) p_vy = -p_vy;
  if (p_vx < 0 && p_bx <= 7 && p_bx >= 4 && p_by + 2 >= p_py && p_by <= p_py + 14) { p_vx = -p_vx; p_vy += (p_by - (p_py + 7)) / 7 * 0.8; p_vx *= 1.03; }
  if (p_vx > 0 && p_bx + 2 >= 121 && p_bx <= 124 && p_by + 2 >= p_ay && p_by <= p_ay + 14) { p_vx = -p_vx; p_vy += (p_by - (p_ay + 7)) / 7 * 0.8; }
  if (p_bx < 0) { lastScore = p_score; mode = MODE_GAMEOVER; return; } if (p_bx > 128) { p_score++; pongServe(-1); }
}
void pongDraw() {
  display.clearDisplay(); display.fillRect(4, (int)p_py, 3, 14, 1); display.fillRect(121, (int)p_ay, 3, 14, 1); display.fillRect((int)p_bx, (int)p_by, 2, 2, 1);
  for (int y = 0; y < 64; y += 6) display.drawPixel(64, y, 1); display.setCursor(54, 2); display.print(p_score); display.display();
}

// ================= DINO =================
float d_y, d_v; bool d_jmp; float d_ox[2]; int d_score, d_gmin, d_gmax; float d_spd; unsigned long d_last, d_st;
void dinoReset() { d_y = 48; d_v = 0; d_jmp = false; d_ox[0] = 148; d_ox[1] = 208; d_score = 0; d_spd = diffLerp(1.7, 2.2, 2.9); d_gmin = (int)diffLerp(50, 40, 30); d_gmax = (int)diffLerp(90, 80, 65); d_last = d_st = millis(); }
void dinoUpdate() {
  if (checkExitToMenu()) return; if (btnPressed[BTN_SELECT] && !d_jmp) { d_v = -4.5; d_jmp = true; }
  if (millis() - d_last < 30) return; d_last = millis();
  if (d_jmp) { d_v += 0.4; d_y += d_v; if (d_y >= 48) { d_y = 48; d_jmp = false; d_v = 0; } }
  for (int i = 0; i < 2; i++) { d_ox[i] -= d_spd; if (d_ox[i] < -6) { float mx = max(d_ox[0], d_ox[1]); d_ox[i] = mx + random(d_gmin, d_gmax); }
    if (d_ox[i] < 16 && d_ox[i] + 4 > 10 && d_y + 6 > 48) { lastScore = d_score; mode = MODE_GAMEOVER; return; } }
  if (millis() - d_st > 200) { d_score++; d_st = millis(); }
}
void dinoDraw() { display.clearDisplay(); display.drawLine(0, 54, 128, 54, 1); display.fillRect(10, (int)d_y, 6, 6, 1); for (int i = 0; i < 2; i++) display.fillRect((int)d_ox[i], 48, 4, 6, 1); display.setCursor(2, 2); display.print(d_score); display.display(); }

// ================= TETRIS =================
#define T_COLS 10
#define T_ROWS 18
uint8_t t_grid[T_ROWS][T_COLS]; int t_type, t_rot, t_px, t_py, t_next, t_score, t_iv; unsigned long t_fall;
const int8_t TET[7][4][4][2] = {
  {{{0,1},{1,1},{2,1},{3,1}},{{2,0},{2,1},{2,2},{2,3}},{{0,2},{1,2},{2,2},{3,2}},{{1,0},{1,1},{1,2},{1,3}}},
  {{{1,0},{2,0},{1,1},{2,1}},{{1,0},{2,0},{1,1},{2,1}},{{1,0},{2,0},{1,1},{2,1}},{{1,0},{2,0},{1,1},{2,1}}},
  {{{1,0},{0,1},{1,1},{2,1}},{{1,0},{1,1},{2,1},{1,2}},{{0,1},{1,1},{2,1},{1,2}},{{1,0},{0,1},{1,1},{1,2}}},
  {{{1,0},{2,0},{0,1},{1,1}},{{1,0},{1,1},{2,1},{2,2}},{{1,0},{2,0},{0,1},{1,1}},{{1,0},{1,1},{2,1},{2,2}}},
  {{{0,0},{1,0},{1,1},{2,1}},{{2,0},{1,1},{2,1},{1,2}},{{0,0},{1,0},{1,1},{2,1}},{{2,0},{1,1},{2,1},{1,2}}},
  {{{0,0},{0,1},{1,1},{2,1}},{{1,0},{2,0},{1,1},{1,2}},{{0,1},{1,1},{2,1},{2,2}},{{1,0},{1,1},{0,2},{1,2}}},
  {{{2,0},{0,1},{1,1},{2,1}},{{1,0},{1,1},{1,2},{2,2}},{{0,1},{1,1},{2,1},{0,2}},{{0,0},{1,0},{1,1},{1,2}}}};
bool tFits(int ty, int r, int px, int py) { for (int c = 0; c < 4; c++) { int gx = px + TET[ty][r][c][0], gy = py + TET[ty][r][c][1]; if (gx < 0 || gx >= T_COLS || gy >= T_ROWS) return false; if (gy >= 0 && t_grid[gy][gx]) return false; } return true; }
void tSpawn() { t_type = t_next; t_next = random(0, 7); t_rot = 0; t_px = 3; t_py = 0; if (!tFits(t_type, 0, 3, 0)) { lastScore = t_score; mode = MODE_GAMEOVER; } }
void tetrisReset() { memset(t_grid, 0, sizeof(t_grid)); t_score = 0; t_iv = (int)diffLerp(650, 500, 350); t_next = random(0, 7); tSpawn(); t_fall = millis(); }
void tLock() {
  for (int c = 0; c < 4; c++) { int gx = t_px + TET[t_type][t_rot][c][0], gy = t_py + TET[t_type][t_rot][c][1]; if (gy >= 0) t_grid[gy][gx] = 1; }
  int cl = 0; for (int y = T_ROWS - 1; y >= 0; y--) { bool f = true; for (int x = 0; x < T_COLS; x++) if (!t_grid[y][x]) { f = false; break; }
    if (f) { cl++; for (int yy = y; yy > 0; yy--) for (int x = 0; x < T_COLS; x++) t_grid[yy][x] = t_grid[yy-1][x]; for (int x = 0; x < T_COLS; x++) t_grid[0][x] = 0; y++; } }
  t_score += cl == 1 ? 100 : cl == 2 ? 300 : cl == 3 ? 500 : cl >= 4 ? 800 : 0; if (t_iv > 150) t_iv -= cl * 10; tSpawn();
}
void tetrisUpdate() {
  if (checkExitToMenu()) return;
  if (btnPressed[BTN_LEFT] && tFits(t_type, t_rot, t_px - 1, t_py)) t_px--; if (btnPressed[BTN_RIGHT] && tFits(t_type, t_rot, t_px + 1, t_py)) t_px++;
  if (btnPressed[BTN_SELECT]) { int nr = (t_rot + 1) % 4; if (tFits(t_type, nr, t_px, t_py)) t_rot = nr; else if (tFits(t_type, nr, t_px - 1, t_py)) { t_rot = nr; t_px--; } else if (tFits(t_type, nr, t_px + 1, t_py)) { t_rot = nr; t_px++; } }
  if (btnPressed[BTN_UP]) { while (tFits(t_type, t_rot, t_px, t_py + 1)) t_py++; tLock(); t_fall = millis(); return; }
  if (millis() - t_fall < (unsigned long)(isHeld(BTN_DOWN) ? 50 : t_iv)) return; t_fall = millis();
  if (tFits(t_type, t_rot, t_px, t_py + 1)) t_py++; else tLock();
}
void tetrisDraw() {
  display.clearDisplay(); int fx = 2, fy = 9;
  for (int y = 0; y < T_ROWS; y++) for (int x = 0; x < T_COLS; x++) if (t_grid[y][x]) display.fillRect(fx + x * 3, fy + y * 3, 2, 2, 1);
  for (int c = 0; c < 4; c++) { int gy = t_py + TET[t_type][t_rot][c][1]; if (gy >= 0) display.fillRect(fx + (t_px + TET[t_type][t_rot][c][0]) * 3, fy + gy * 3, 2, 2, 1); }
  display.drawRect(fx - 1, fy - 1, 32, 56, 1); display.setCursor(46, 0); display.print(F("Sc:")); display.print(t_score); display.setCursor(46, 12); display.print(F("Next:"));
  display.drawRect(45, 21, 14, 14, 1); for (int c = 0; c < 4; c++) display.fillRect(46 + TET[t_next][0][c][0] * 3, 22 + TET[t_next][0][c][1] * 3, 2, 2, 1); display.display();
}

// ================= SPACE INVADERS =================
#define SI_C 6
#define SI_R 3
bool si_al[SI_R][SI_C]; float si_fx; int si_fy, si_dir, si_px, si_score; unsigned long si_lm, si_la; bool si_b; float si_bx, si_by; bool si_ab[2]; float si_abx[2], si_aby[2]; bool si_sh[3][6]; float si_mul;
int siAlive() { int c = 0; for (int r = 0; r < SI_R; r++) for (int x = 0; x < SI_C; x++) if (si_al[r][x]) c++; return c; }
void siWave() { for (int r = 0; r < SI_R; r++) for (int x = 0; x < SI_C; x++) si_al[r][x] = true; si_fx = 8; si_fy = 8; si_dir = 1; for (int b = 0; b < 3; b++) for (int i = 0; i < 6; i++) si_sh[b][i] = true; }
void siReset() { si_score = 0; si_px = 60; si_b = false; si_ab[0] = si_ab[1] = false; si_mul = diffLerp(1.3, 1.0, 0.7); si_lm = si_la = millis(); siWave(); }
bool siShield(float bx, float by) { for (int b = 0; b < 3; b++) for (int i = 0; i < 6; i++) { if (!si_sh[b][i]) continue; int kx = 14 + b * 40 + (i % 3) * 4, ky = 50 + (i / 3) * 3; if (bx + 1 >= kx && bx <= kx + 4 && by + 1 >= ky && by <= ky + 3) { si_sh[b][i] = false; return true; } } return false; }
void siUpdate() {
  if (checkExitToMenu()) return;
  if (isHeld(BTN_LEFT)) si_px -= 2; if (isHeld(BTN_RIGHT)) si_px += 2; if (si_px < 0) si_px = 0; if (si_px > 121) si_px = 121;
  if (btnPressed[BTN_SELECT] && !si_b) { si_b = true; si_bx = si_px + 3; si_by = 58; }
  if (si_b) { si_by -= 3; if (si_by < 0 || siShield(si_bx, si_by)) si_b = false; else for (int r = 0; r < SI_R && si_b; r++) for (int c = 0; c < SI_C && si_b; c++) { if (!si_al[r][c]) continue; float ax = si_fx + c * 10, ay = si_fy + r * 8;
      if (si_bx + 1 >= ax && si_bx <= ax + 6 && si_by + 1 >= ay && si_by <= ay + 4) { si_al[r][c] = false; si_b = false; si_score += r == 0 ? 30 : r == 1 ? 20 : 10; } } }
  int al = siAlive(); if (!al) { siWave(); al = 18; }
  if (millis() - si_lm >= (unsigned long)((80 + al * 320 / 18) * si_mul)) { si_lm = millis(); int lm = SI_C, rm = -1;
    for (int r = 0; r < SI_R; r++) for (int c = 0; c < SI_C; c++) if (si_al[r][c]) { if (c < lm) lm = c; if (c > rm) rm = c; }
    float mn = si_fx + lm * 10, mx = si_fx + rm * 10 + 6;
    if ((si_dir > 0 && mx >= 126) || (si_dir < 0 && mn <= 2)) { si_dir = -si_dir; si_fy += 4; } else si_fx += si_dir * 2;
    if (si_fy + 24 >= 58) { lastScore = si_score; mode = MODE_GAMEOVER; return; } }
  if (millis() - si_la > 700) { si_la = millis(); for (int t = 0; t < 6; t++) { int c = random(0, SI_C), r = -1; for (int rr = 2; rr >= 0; rr--) if (si_al[rr][c]) { r = rr; break; }
      if (r >= 0) { for (int i = 0; i < 2; i++) if (!si_ab[i]) { si_ab[i] = true; si_abx[i] = si_fx + c * 10 + 3; si_aby[i] = si_fy + r * 8 + 4; break; } break; } } }
  for (int i = 0; i < 2; i++) { if (!si_ab[i]) continue; si_aby[i] += 2; if (si_aby[i] > 64 || siShield(si_abx[i], si_aby[i])) { si_ab[i] = false; continue; }
    if (si_aby[i] + 1 >= 60 && si_aby[i] <= 63 && si_abx[i] + 1 >= si_px && si_abx[i] <= si_px + 7) { lastScore = si_score; mode = MODE_GAMEOVER; return; } }
}
void siDraw() {
  display.clearDisplay(); for (int r = 0; r < SI_R; r++) for (int c = 0; c < SI_C; c++) if (si_al[r][c]) display.fillRect(si_fx + c * 10, si_fy + r * 8, 6, 4, 1);
  for (int b = 0; b < 3; b++) for (int i = 0; i < 6; i++) if (si_sh[b][i]) display.fillRect(14 + b * 40 + (i % 3) * 4, 50 + (i / 3) * 3, 3, 2, 1);
  display.fillRect(si_px, 60, 7, 3, 1); if (si_b) display.fillRect((int)si_bx, (int)si_by, 1, 3, 1); for (int i = 0; i < 2; i++) if (si_ab[i]) display.fillRect((int)si_abx[i], (int)si_aby[i], 1, 3, 1);
  display.setCursor(0, 0); display.print(F("Sc:")); display.print(si_score); display.display();
}

// ================= BREAKOUT =================
bool br_b[4][8]; float br_px, br_bx, br_by, br_vx, br_vy, br_pwx, br_pwy; int br_pw, br_score; bool br_go, br_pw_on; unsigned long br_wide, br_last;
void brBricks() { for (int r = 0; r < 4; r++) for (int c = 0; c < 8; c++) br_b[r][c] = true; }
void brBall() { br_bx = br_px + br_pw / 2; br_by = 57; br_vx = br_vy = 0; br_go = false; }
void brReset() { br_px = 54; br_pw = 20; br_score = 0; br_pw_on = false; br_wide = 0; brBricks(); brBall(); br_last = millis(); }
void brUpdate() {
  if (checkExitToMenu()) return;
  if (isHeld(BTN_LEFT)) br_px -= 2.5; if (isHeld(BTN_RIGHT)) br_px += 2.5; if (br_px < 0) br_px = 0; if (br_px > 128 - br_pw) br_px = 128 - br_pw;
  if (br_wide && millis() > br_wide) { br_wide = 0; br_pw = 20; }
  if (!br_go) { br_bx = br_px + br_pw / 2; if (btnPressed[BTN_SELECT]) { br_go = true; float s = diffLerp(0.85, 1.0, 1.3); br_vx = 1.2 * s; br_vy = -1.6 * s; } }
  if (millis() - br_last < 20) return; br_last = millis();
  if (br_pw_on) { br_pwy += 1.2; if (br_pwy > 64) br_pw_on = false; else if (br_pwy + 3 >= 60 && br_pwx + 3 >= br_px && br_pwx <= br_px + br_pw) { br_pw_on = false; br_pw = 30; br_wide = millis() + 8000; if (br_px > 128 - br_pw) br_px = 128 - br_pw; } }
  if (!br_go) return; br_bx += br_vx; br_by += br_vy;
  if (br_bx <= 0 || br_bx >= 126) br_vx = -br_vx; if (br_by <= 0) br_vy = -br_vy;
  if (br_by + 2 >= 60 && br_by <= 63 && br_bx + 2 >= br_px && br_bx <= br_px + br_pw && br_vy > 0) { br_vy = -br_vy; br_vx = (br_bx - (br_px + br_pw / 2)) / (br_pw / 2.0) * 2.0; }
  if (br_by > 64) { lastScore = br_score; mode = MODE_GAMEOVER; return; }
  bool hit = false; for (int r = 0; r < 4 && !hit; r++) for (int c = 0; c < 8 && !hit; c++) { if (!br_b[r][c]) continue; int bx = c * 16, by = 4 + r * 7;
    if (br_bx + 2 >= bx && br_bx <= bx + 15 && br_by + 2 >= by && br_by <= by + 4) { br_b[r][c] = false; br_vy = -br_vy; br_score += 10; if (!random(0, 6) && !br_pw_on) { br_pw_on = true; br_pwx = bx + 7; br_pwy = by; } hit = true; } }
  bool any = false; for (int r = 0; r < 4; r++) for (int c = 0; c < 8; c++) if (br_b[r][c]) any = true; if (!any) { brBricks(); brBall(); }
}
void brDraw() {
  display.clearDisplay(); for (int r = 0; r < 4; r++) for (int c = 0; c < 8; c++) if (br_b[r][c]) display.fillRect(c * 16, 4 + r * 7, 15, 4, 1);
  display.fillRect((int)br_px, 60, br_pw, 3, 1); display.fillRect((int)br_bx, (int)br_by, 2, 2, 1); if (br_pw_on) display.drawRect((int)br_pwx, (int)br_pwy, 3, 3, 1); display.setCursor(0, 0); display.print(br_score); display.display();
}

// ================= PAC-MAN =================
const char* PML[7] = {"################","#..............#","#.####.##.####.#","#..............#","#.####.##.####.#","#..............#","################"};
char pm[7][17]; int pm_x, pm_y, pm_dx, pm_dy, pm_g[2][4], pm_score, pm_giv; unsigned long pm_lm, pm_lg;
bool pmW(int x, int y) { return x < 0 || x >= 16 || y < 0 || y >= 7 || pm[y][x] == '#'; }
void pmDots() { for (int y = 0; y < 7; y++) strcpy(pm[y], PML[y]); }
void pmReset() { pmDots(); pm_x = 1; pm_y = 1; pm_dx = 1; pm_dy = 0; int g[2][4] = {{14,1,-1,0},{1,5,1,0}}; memcpy(pm_g, g, sizeof(g)); pm_score = 0; pm_giv = (int)diffLerp(300, 220, 150); pm_lm = pm_lg = millis(); }
void pmGhost(int* g) {
  int o[4][2] = {{1,0},{-1,0},{0,1},{0,-1}}, v[4][2], n = 0;
  for (int i = 0; i < 4; i++) { if (o[i][0] == -g[2] && o[i][1] == -g[3]) continue; if (!pmW(g[0] + o[i][0], g[1] + o[i][1])) { v[n][0] = o[i][0]; v[n][1] = o[i][1]; n++; } }
  if (!n) { g[2] = -g[2]; g[3] = -g[3]; if (!pmW(g[0] + g[2], g[1] + g[3])) { g[0] += g[2]; g[1] += g[3]; } return; }
  int p = random(0, n); g[2] = v[p][0]; g[3] = v[p][1]; g[0] += g[2]; g[1] += g[3];
}
void pmUpdate() {
  if (checkExitToMenu()) return;
  if (btnPressed[BTN_UP] && !pmW(pm_x, pm_y - 1)) { pm_dx = 0; pm_dy = -1; } if (btnPressed[BTN_DOWN] && !pmW(pm_x, pm_y + 1)) { pm_dx = 0; pm_dy = 1; }
  if (btnPressed[BTN_LEFT] && !pmW(pm_x - 1, pm_y)) { pm_dx = -1; pm_dy = 0; } if (btnPressed[BTN_RIGHT] && !pmW(pm_x + 1, pm_y)) { pm_dx = 1; pm_dy = 0; }
  if (millis() - pm_lm > 160) { pm_lm = millis(); if (!pmW(pm_x + pm_dx, pm_y + pm_dy)) { pm_x += pm_dx; pm_y += pm_dy; if (pm[pm_y][pm_x] == '.') { pm[pm_y][pm_x] = ' '; pm_score += 10; } } }
  if (millis() - pm_lg > (unsigned long)pm_giv) { pm_lg = millis(); pmGhost(pm_g[0]); pmGhost(pm_g[1]); }
  for (int i = 0; i < 2; i++) if (pm_x == pm_g[i][0] && pm_y == pm_g[i][1]) { lastScore = pm_score; mode = MODE_GAMEOVER; return; }
  bool d = false; for (int y = 0; y < 7; y++) for (int x = 0; x < 16; x++) if (pm[y][x] == '.') d = true; if (!d) pmDots();
}
void pmDraw() {
  display.clearDisplay(); for (int y = 0; y < 7; y++) for (int x = 0; x < 16; x++) { char c = pm[y][x]; int px = x * 8, py = 8 + y * 8; if (c == '#') display.drawRect(px, py, 8, 8, 1); else if (c == '.') display.fillRect(px + 3, py + 3, 2, 2, 1); }
  display.fillCircle(pm_x * 8 + 4, 12 + pm_y * 8, 3, 1); for (int i = 0; i < 2; i++) display.drawCircle(pm_g[i][0] * 8 + 4, 12 + pm_g[i][1] * 8, 3, 1);
  display.setCursor(0, 0); display.print(pm_score); display.display();
}

// ================= MONSTER HUNT 3D =================
const uint8_t MH_MAP[64] = {2,2,2,2,2,2,2,2, 2,0,0,0,1,0,0,2, 2,0,3,0,1,0,3,2, 2,0,3,0,0,0,0,2, 2,0,1,1,1,0,1,2, 2,0,0,0,1,0,0,2, 2,2,0,4,0,0,2,2, 2,2,2,2,2,2,2,2};
Ent mh_m[5]; int mh_n, mh_hp, mh_score, mh_dmg; float mh_px, mh_py, mh_a, mh_spd; unsigned long mh_lai, mh_ldm, mh_fire;
void mhReset() {
  mh_px = 1.5; mh_py = 1.5; mh_a = 0; mh_hp = 100; mh_score = 0; mh_n = (int)diffLerp(3, 4, 5); mh_spd = diffLerp(0.012, 0.02, 0.03); mh_dmg = (int)diffLerp(5, 8, 12);
  for (int i = 0; i < 5; i++) { mh_m[i].alive = false; if (i < mh_n) entSpawn(mh_m[i], MH_MAP, 8, 8, mh_px, mh_py); } mh_lai = mh_ldm = millis(); mh_fire = 0;
}
void mhUpdate() {
  if (checkExitToMenu()) return;
  if (isHeld(BTN_LEFT)) mh_a -= 0.06; if (isHeld(BTN_RIGHT)) mh_a += 0.06;
  if (isHeld(BTN_UP)) moveTry(MH_MAP, 8, 8, mh_px, mh_py, mh_px + cosf(mh_a) * 0.05f, mh_py + sinf(mh_a) * 0.05f);
  if (isHeld(BTN_DOWN)) moveTry(MH_MAP, 8, 8, mh_px, mh_py, mh_px - cosf(mh_a) * 0.05f, mh_py - sinf(mh_a) * 0.05f);
  if (btnPressed[BTN_SELECT]) { mh_fire = millis(); int best = -1; float bd = 99;
    for (int i = 0; i < mh_n; i++) { float d; if (mh_m[i].alive && aimAt(mh_m[i].x, mh_m[i].y, mh_px, mh_py, mh_a, 0.14f, d) && d < bd) { bd = d; best = i; } }
    if (best >= 0) { mh_m[best].alive = false; mh_score += 10; bool any = false; for (int i = 0; i < mh_n; i++) if (mh_m[i].alive) any = true; if (!any) for (int i = 0; i < mh_n; i++) entSpawn(mh_m[i], MH_MAP, 8, 8, mh_px, mh_py); } }
  if (millis() - mh_lai > 40) { mh_lai = millis(); for (int i = 0; i < mh_n; i++) { if (!mh_m[i].alive) continue; float dx = mh_px - mh_m[i].x, dy = mh_py - mh_m[i].y, l = sqrtf(dx * dx + dy * dy);
      if (l > 0.3f) moveTry(MH_MAP, 8, 8, mh_m[i].x, mh_m[i].y, mh_m[i].x + dx / l * mh_spd, mh_m[i].y + dy / l * mh_spd); } }
  if (millis() - mh_ldm > 500) { mh_ldm = millis(); for (int i = 0; i < mh_n; i++) { if (!mh_m[i].alive) continue; float dx = mh_px - mh_m[i].x, dy = mh_py - mh_m[i].y; if (dx * dx + dy * dy < 0.36f) mh_hp -= mh_dmg; }
    if (mh_hp <= 0) { lastScore = mh_score; mode = MODE_GAMEOVER; } }
}
void mhDraw() {
  display.clearDisplay(); rcRender(MH_MAP, 8, 8, mh_px, mh_py, mh_a); drawEnts(mh_m, mh_n, mh_px, mh_py, mh_a, SP_IMP_M, SP_IMP_F, 0.8f);
  display.drawFastHLine(61, 32, 6, 1); display.drawFastVLine(64, 29, 6, 1); drawGun(0, millis() - mh_fire < 100);
  display.fillRect(0, 0, 44, 8, 0); display.setTextColor(1, 0); display.setCursor(0, 0); display.print(F("HP:")); display.print(mh_hp); display.setCursor(88, 0); display.print(F("Sc:")); display.print(mh_score); display.setTextColor(1); display.display();
}

// ================= BOT DUEL 3D =================
float bd_px, bd_py, bd_a, bd_tx, bd_ty, bd_spd; Ent bd_bot; int bd_hp, bd_score, bd_dmg, bd_acc; unsigned long bd_fire, bd_lai, bd_ls, bd_bf, bd_fint;
void bdPatrol() { for (int t = 0; t < 40; t++) { int x = random(1, 9), y = random(1, 9); if (!bd_map[y * 10 + x]) { bd_tx = x + .5f; bd_ty = y + .5f; return; } } bd_tx = bd_bot.x; bd_ty = bd_bot.y; }
void bdSpawn() { entSpawn(bd_bot, bd_map, 10, 10, bd_px, bd_py); bd_bot.hp = 100; bdPatrol(); }
void bdReset() { bd_px = 1.5; bd_py = 1.5; bd_a = 0; bd_hp = 100; bd_score = 0; bd_spd = diffLerp(0.012, 0.018, 0.025); bd_dmg = (int)diffLerp(5, 8, 12); bd_fint = (unsigned long)diffLerp(1600, 1100, 700); bd_acc = (int)diffLerp(45, 65, 85); bdSpawn(); bd_lai = bd_ls = millis(); bd_fire = bd_bf = 0; }
void bdUpdate() {
  if (checkExitToMenu()) return;
  if (isHeld(BTN_LEFT)) bd_a -= 0.06; if (isHeld(BTN_RIGHT)) bd_a += 0.06;
  if (isHeld(BTN_UP)) moveTry(bd_map, 10, 10, bd_px, bd_py, bd_px + cosf(bd_a) * 0.05f, bd_py + sinf(bd_a) * 0.05f);
  if (isHeld(BTN_DOWN)) moveTry(bd_map, 10, 10, bd_px, bd_py, bd_px - cosf(bd_a) * 0.05f, bd_py - sinf(bd_a) * 0.05f);
  if (btnPressed[BTN_SELECT]) { bd_fire = millis(); float d; if (aimAt(bd_bot.x, bd_bot.y, bd_px, bd_py, bd_a, 0.12f, d)) { bd_bot.hp -= 20; if (bd_bot.hp <= 0) { bd_score++; bdSpawn(); } } }
  if (millis() - bd_lai > 60) { bd_lai = millis();
    float dx = bd_px - bd_bot.x, dy = bd_py - bd_bot.y, d = sqrtf(dx * dx + dy * dy);
    if (d < 7 && losClear(bd_map, 10, 10, bd_bot.x, bd_bot.y, bd_px, bd_py)) { if (millis() - bd_ls > bd_fint) { bd_ls = millis(); bd_bf = millis(); if (random(0, 100) < bd_acc) bd_hp -= bd_dmg; } }
    else { float tx = bd_tx - bd_bot.x, ty = bd_ty - bd_bot.y, td = sqrtf(tx * tx + ty * ty); if (td < 0.3f) bdPatrol(); else moveTry(bd_map, 10, 10, bd_bot.x, bd_bot.y, bd_bot.x + tx / td * bd_spd * 1.5f, bd_bot.y + ty / td * bd_spd * 1.5f); } }
  if (bd_hp <= 0) { lastScore = bd_score; mode = MODE_GAMEOVER; }
}
void bdDraw() {
  display.clearDisplay(); rcRender(bd_map, 10, 10, bd_px, bd_py, bd_a); drawEnts(&bd_bot, 1, bd_px, bd_py, bd_a, SP_SOL_M, SP_SOL_F, 0.9f);
  if (millis() - bd_bf < 100) display.fillCircle(64, 4, 2, 1);
  display.drawFastHLine(61, 32, 6, 1); display.drawFastVLine(64, 29, 6, 1); drawGun(0, millis() - bd_fire < 100);
  display.fillRect(0, 0, 48, 8, 0); display.fillRect(80, 0, 48, 8, 0); display.setTextColor(1, 0); display.setCursor(0, 0); display.print(F("You:")); display.print(bd_hp); display.setCursor(84, 0); display.print(F("Bot:")); display.print(bd_bot.hp > 0 ? bd_bot.hp : 0);
  display.setCursor(52, 9); display.print(F("W:")); display.print(bd_score); display.setTextColor(1); display.display();
}

// ================= 3D FPS TEST =================
float fp_x, fp_y, fp_a; unsigned long fp_cnt, fp_t; int fp_fps;
void fpsReset() { fp_x = 1.5; fp_y = 1.5; fp_a = 0; fp_cnt = 0; fp_t = millis(); fp_fps = 0; }
void fpsUpdate() {
  if (checkExitToMenu()) return;
  if (isHeld(BTN_LEFT)) fp_a -= 0.06; if (isHeld(BTN_RIGHT)) fp_a += 0.06;
  if (isHeld(BTN_UP)) moveTry(bd_map, 10, 10, fp_x, fp_y, fp_x + cosf(fp_a) * 0.05f, fp_y + sinf(fp_a) * 0.05f);
  if (isHeld(BTN_DOWN)) moveTry(bd_map, 10, 10, fp_x, fp_y, fp_x - cosf(fp_a) * 0.05f, fp_y - sinf(fp_a) * 0.05f);
  fp_cnt++; if (millis() - fp_t >= 1000) { fp_fps = fp_cnt; fp_cnt = 0; fp_t = millis(); }
}
void fpsDraw() { display.clearDisplay(); rcRender(bd_map, 10, 10, fp_x, fp_y, fp_a); display.fillRect(0, 0, 60, 8, 0); display.setTextColor(1, 0); display.setCursor(0, 0); display.print(F("FPS: ")); display.print(fp_fps); display.setTextColor(1); display.display(); }

// ================= DOOM =================
const char* DM_L[16] = {
  "1111111111111111","1p....1.....a..1","1.....1..e.....1","1..22.1.....33.1","1..2.....1.....1","1.....e..1..h..1","1111.1111111.111","1....1.......1.1",
  "1.h..1..44...1.1","1....1..4..e.1.1","1.e..........1.1","1....1..33...1a1","1111.1111.1111.1","1.a..........e.1","1.....22...h...1","1111111111111111"};
#define DM_E 8
#define DM_I 8
Ent dm_e[DM_E]; int dm_en; struct Item { float x, y; uint8_t type; bool on; } dm_i[DM_I]; int dm_in;
float dm_px, dm_py, dm_a; int dm_hp, dm_sh, dm_score, dm_lvl; unsigned long dm_ns, dm_fl, dm_hurt, dm_lai; int dm_wpn; bool dm_inv = false;
void dmLoad() {
  dm_en = dm_in = 0;
  for (int y = 0; y < 16; y++) for (int x = 0; x < 16; x++) { char c = DM_L[y][x]; dm_map[y * 16 + x] = (c >= '1' && c <= '4') ? c - '0' : 0;
    if (c == 'p') { dm_px = x + .5f; dm_py = y + .5f; }
    else if (c == 'e' && dm_en < DM_E) { dm_e[dm_en++] = {x + .5f, y + .5f, true, 30 + dm_lvl * 6, 0}; }
    else if ((c == 'h' || c == 'a') && dm_in < DM_I) { dm_i[dm_in++] = {x + .5f, y + .5f, (uint8_t)(c == 'h' ? 0 : 1), true}; } }
  for (int k = 0; k < dm_lvl - 1 && k < 3 && dm_en < DM_E; k++) { entSpawn(dm_e[dm_en], dm_map, 16, 16, dm_px, dm_py); dm_e[dm_en].hp = 30 + dm_lvl * 6; dm_e[dm_en].t = 0; dm_en++; }
  dm_a = 0;
}
void dmReset() { dm_lvl = 1; dm_hp = 100; dm_sh = 8; dm_score = 0; dm_wpn = 1; dm_ns = dm_fl = dm_hurt = 0; dm_lai = millis(); dmLoad(); }
void dmUpdate() {
  if (checkExitToMenu()) return;
  if (isHeld(BTN_LEFT)) dm_a -= 0.06; if (isHeld(BTN_RIGHT)) dm_a += 0.06;
  if (isHeld(BTN_UP)) moveTry(dm_map, 16, 16, dm_px, dm_py, dm_px + cosf(dm_a) * 0.06f, dm_py + sinf(dm_a) * 0.06f);
  if (isHeld(BTN_DOWN)) moveTry(dm_map, 16, 16, dm_px, dm_py, dm_px - cosf(dm_a) * 0.06f, dm_py - sinf(dm_a) * 0.06f);
  for (int i = 0; i < dm_in; i++) if (dm_i[i].on) { float dx = dm_i[i].x - dm_px, dy = dm_i[i].y - dm_py; if (dx * dx + dy * dy < 0.3f) { dm_i[i].on = false; if (dm_i[i].type == 0) { dm_hp += 25; if (dm_hp > 100) dm_hp = 100; } else dm_sh += 6; } }
  if (btnPressed[BTN_SELECT] && millis() > dm_ns) {
    dm_wpn = dm_sh > 0 ? 1 : 0; dm_fl = millis(); dm_ns = millis() + (dm_wpn ? 650 : 280); if (dm_wpn) dm_sh--;
    for (int i = 0; i < dm_en; i++) { float d; if (!dm_e[i].alive || !aimAt(dm_e[i].x, dm_e[i].y, dm_px, dm_py, dm_a, dm_wpn ? 0.28f : 0.10f, d)) continue;
      int dmg = dm_wpn ? (int)(48 - d * 4) : 12; if (dmg < 12) dmg = 12; dm_e[i].hp -= dmg; if (dm_e[i].hp <= 0) { dm_e[i].alive = false; dm_score += 100; } }
    bool any = false; for (int i = 0; i < dm_en; i++) if (dm_e[i].alive) any = true;
    if (!any) { dm_lvl++; dm_hp = dm_hp + 30 > 100 ? 100 : dm_hp + 30; dm_sh += 4; dm_score += 500; dmLoad(); }
  }
  if (millis() - dm_lai > 50) { dm_lai = millis(); float sp = 0.02f + dm_lvl * 0.004f; if (sp > 0.045f) sp = 0.045f;
    for (int i = 0; i < dm_en; i++) { Ent& e = dm_e[i]; if (!e.alive) continue;
      float dx = dm_px - e.x, dy = dm_py - e.y, d = sqrtf(dx * dx + dy * dy); bool los = losClear(dm_map, 16, 16, e.x, e.y, dm_px, dm_py);
      if (d > 1.1f) moveTry(dm_map, 16, 16, e.x, e.y, e.x + dx / d * sp * (los ? 1 : 0.5f), e.y + dy / d * sp * (los ? 1 : 0.5f));
      unsigned long fi = 1500 - dm_lvl * 100; if (fi < 700) fi = 700;
      if (los && d < 8 && d > 1.4f && millis() - e.t > fi) { e.t = millis(); int ch = 45 + dm_lvl * 5; if (ch > 80) ch = 80; if (random(0, 100) < ch) { dm_hp -= 7 + dm_lvl; dm_hurt = millis() + 120; } }
      else if (d <= 1.1f && millis() - e.t > 700) { e.t = millis(); dm_hp -= 10; dm_hurt = millis() + 120; } }
    if (dm_hp <= 0) { lastScore = dm_score; mode = MODE_GAMEOVER; }
  }
}
void dmDraw() {
  display.clearDisplay(); rcRender(dm_map, 16, 16, dm_px, dm_py, dm_a);
  for (int i = 0; i < dm_in; i++) if (dm_i[i].on) rcSprite(dm_i[i].x, dm_i[i].y, dm_px, dm_py, dm_a, dm_i[i].type ? SP_AM_M : SP_HP_M, dm_i[i].type ? SP_AM_F : SP_HP_F, 0.4f);
  drawEnts(dm_e, dm_en, dm_px, dm_py, dm_a, SP_IMP_M, SP_IMP_F, 0.85f);
  display.drawFastHLine(61, 32, 6, 1); display.drawFastVLine(64, 29, 6, 1); drawGun(dm_sh > 0 ? 1 : 0, millis() - dm_fl < 110);
  display.fillRect(0, 56, 128, 8, 0); display.drawFastHLine(0, 55, 128, 1); display.setTextColor(1, 0); display.setCursor(1, 57);
  display.print(F("HP")); display.print(dm_hp); display.print(F(" SH")); display.print(dm_sh); display.print(F(" L")); display.print(dm_lvl); display.print(' '); display.print(dm_score); display.setTextColor(1);
  bool inv = millis() < dm_hurt; if (inv != dm_inv) { display.invertDisplay(inv); dm_inv = inv; } display.display();
}

// ================= WEB =================
WebServer srv(80); File upFile; const char* AP_SSID = "MiniGame-Upload"; const char* AP_PASS = "12345678";
void hView() {
  if (!srv.hasArg("f")) { srv.send(400, "text/plain", "missing f"); return; }
  String fn = srv.arg("f"); bool v = fn.endsWith(".mgv"); File f = LittleFS.open((v ? String(VIDEO_DIR) : String(GALLERY_DIR)) + "/" + fn, "r");
  if (!f) { srv.send(404, "text/plain", "not found"); return; }
  srv.streamFile(f, v ? "application/octet-stream" : "image/png"); f.close();
}
void listDir(String& h, const char* d, bool vid) {
  if (!LittleFS.exists(d)) return; File dir = LittleFS.open(d); File e = dir.openNextFile();
  while (e) { String b = String(e.name()); int s = b.lastIndexOf('/'); if (s >= 0) b = b.substring(s + 1);
    if (vid) h += "<div class='shot'><span>[VIDEO]<br>" + b + "<br><a href='/player?f=" + b + "'>watch / MP4</a></span></div>";
    else h += "<div class='shot' onclick=\"openLb('/view?f=" + b + "','" + b + "')\"><img src='/view?f=" + b + "'><span>" + b + "</span></div>";
    e = dir.openNextFile(); }
}
void hRoot() {
  String h = F("<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>MiniGame</title><style>"
  "body{font-family:Arial;background:radial-gradient(#1b1b4b,#05050f);color:#eee;margin:0;padding:20px}h3{color:#7df;text-align:center}h4{color:#ccc;border-bottom:2px solid #7df;padding-bottom:5px}"
  ".box{background:#16213e;padding:15px;border-radius:10px;margin-bottom:20px;text-align:center}input[type=file]{color:#eee}"
  "input[type=submit]{background:#7df;border:0;padding:8px 16px;border-radius:6px;font-weight:bold}.g{display:flex;flex-wrap:wrap;gap:12px;justify-content:center}"
  ".shot{background:#16213e;padding:8px;border-radius:8px;text-align:center;cursor:pointer}.shot img{image-rendering:pixelated;width:192px;border:2px solid #7df;border-radius:4px}"
  ".shot span{display:block;margin-top:6px;font-size:12px;color:#aaa}a{color:#7df}#lb{display:none;position:fixed;inset:0;background:#000d;z-index:9;justify-content:center;align-items:center;flex-direction:column}"
  "#lb img{image-rendering:pixelated;max-width:90%;max-height:80%;border:3px solid #7df}</style></head><body><h3>MiniGame Control Panel</h3>"
  "<div class='box'><h4>Upload game (.bin)</h4><form method='POST' action='/upload' enctype='multipart/form-data'><input type='file' name='file'> <input type='submit' value='Upload'></form></div>"
  "<div class='box'><h4>Firmware OTA</h4><form method='POST' action='/ota' enctype='multipart/form-data'><input type='file' name='firmware' accept='.bin'> <input type='submit' value='Flash' style='background:#f55'></form></div>"
  "<h4>Gallery</h4><div class='g'>");
  listDir(h, GALLERY_DIR, false); listDir(h, VIDEO_DIR, true);
  h += F("</div><div id='lb' onclick=\"this.style.display='none'\"><img id='li'><span id='ln'></span></div><script>function openLb(s,n){li.src=s;ln.textContent=n;lb.style.display='flex'}</script></body></html>");
  srv.send(200, "text/html", h);
}
const char PLAYER_HTML[] PROGMEM = R"HTML(<!DOCTYPE html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<style>body{background:#05050f;color:#eee;font-family:Arial;text-align:center}canvas{image-rendering:pixelated;border:2px solid #7df;max-width:96%}button{background:#7df;border:0;padding:10px 18px;border-radius:6px;font-weight:bold;margin:6px}</style></head><body>
<h3>MiniGame video</h3><canvas id=c width=512 height=256></canvas><br><button onclick='play()'>Play</button><button onclick='conv()'>Convert &amp; download</button><p id=s></p>
<script>
const f=new URLSearchParams(location.search).get('f');let d,iv,n;const c=document.getElementById('c'),x=c.getContext('2d'),t=document.createElement('canvas');t.width=128;t.height=64;
const tx=t.getContext('2d'),img=tx.createImageData(128,64);x.imageSmoothingEnabled=false;
function draw(i){const o=8+i*1024;for(let y=0;y<64;y++)for(let X=0;X<128;X++){const on=(d[o+X+(y>>3)*128]>>(y&7))&1,p=(y*128+X)*4;img.data[p]=img.data[p+1]=img.data[p+2]=on?255:0;img.data[p+3]=255}tx.putImageData(img,0,0);x.drawImage(t,0,0,512,256)}
function play(cb){let i=0;const h=setInterval(()=>{if(i>=n){clearInterval(h);if(cb)cb();return}draw(i++)},iv)}
function conv(){const m=['video/mp4','video/webm;codecs=vp9','video/webm'].find(t=>MediaRecorder.isTypeSupported(t));if(!m){s.textContent='Browser cannot record';return}
const r=new MediaRecorder(c.captureStream(30),{mimeType:m,videoBitsPerSecond:2000000}),ch=[];r.ondataavailable=e=>ch.push(e.data);
r.onstop=()=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(ch,{type:m}));a.download='minigame.'+(m.includes('mp4')?'mp4':'webm');a.click();s.textContent='Done: '+a.download};
r.start();s.textContent='Recording...';play(()=>setTimeout(()=>r.stop(),200))}
fetch('/view?f='+f).then(r=>r.arrayBuffer()).then(b=>{d=new Uint8Array(b);iv=(d[6]|(d[7]<<8))||100;n=(d.length-8)>>10;draw(0);play()});
</script></body></html>)HTML";
void hPlayer() { srv.send_P(200, "text/html", PLAYER_HTML); }
void hUpload() { HTTPUpload& u = srv.upload(); if (u.status == UPLOAD_FILE_START) upFile = LittleFS.open("/game.bin", "w"); else if (u.status == UPLOAD_FILE_WRITE) { if (upFile) upFile.write(u.buf, u.currentSize); } else if (u.status == UPLOAD_FILE_END) { if (upFile) upFile.close(); } }
bool otaErr = false; String otaMsg; size_t otaTot = 0, otaGot = 0; unsigned long otaStart = 0;
void otaChunk() {
  HTTPUpload& u = srv.upload();
  if (u.status == UPLOAD_FILE_START) { otaErr = false; otaGot = 0; otaTot = u.totalSize; otaStart = millis(); mode = MODE_OTA_PREPARE; if (!Update.begin(UPDATE_SIZE_UNKNOWN)) { otaErr = true; otaMsg = "begin failed"; } }
  else if (u.status == UPLOAD_FILE_WRITE && !otaErr) { while (millis() - otaStart < 5000) delay(10); mode = MODE_OTA_UPDATING; if (Update.write(u.buf, u.currentSize) != u.currentSize) { otaErr = true; otaMsg = "write failed"; } otaGot += u.currentSize; }
  else if (u.status == UPLOAD_FILE_END && !otaErr) { if (!Update.end(true)) { otaErr = true; otaMsg = "end failed"; } }
}
void otaDone() { if (otaErr) { srv.send(500, "text/plain", "OTA failed: " + otaMsg); mode = MODE_MENU; } else { srv.send(200, "text/plain", "OK, rebooting..."); delay(500); ESP.restart(); } }
void updateOtaPrepare() {
  display.clearDisplay(); display.setTextSize(2); String t = "Updating"; int n = ((millis() - otaStart) / 400) % 4; for (int i = 0; i < n; i++) t += ".";
  display.setCursor(4, 24); display.print(t); display.setTextSize(1); display.display(); srv.handleClient();
}
void updateOtaUpdating() {
  display.clearDisplay(); display.setTextSize(1); display.setCursor(20, 10); display.print(F("Flashing firmware")); int p = otaTot ? (int)(otaGot * 100 / otaTot) : 0; if (p > 100) p = 100;
  display.setCursor(54, 30); display.print(p); display.print('%'); display.drawRect(10, 42, 108, 10, 1); display.fillRect(11, 43, 106 * p / 100, 8, 1);
  display.setCursor(2, 56); display.print(F("Do not power off!")); display.display(); srv.handleClient();
}
void binServerStart() {
  WiFi.mode(WIFI_AP); WiFi.softAP(AP_SSID, AP_PASS);
  srv.on("/", HTTP_GET, hRoot); srv.on("/upload", HTTP_POST, []() { srv.send(200, "text/plain", "OK"); }, hUpload);
  srv.on("/view", HTTP_GET, hView); srv.on("/player", HTTP_GET, hPlayer); srv.on("/ota", HTTP_POST, otaDone, otaChunk); srv.begin(); mode = MODE_BIN_SERVER;
}
void updateBinServer() {
  srv.handleClient(); display.clearDisplay(); drawStars(16); display.setTextSize(1); display.setTextColor(1, 0); display.setCursor(0, 0);
  display.println(F("Bin Upload Mode")); display.print(F("SSID: ")); display.println(AP_SSID); display.print(F("Pass: ")); display.println(AP_PASS);
  display.print(F("http://")); display.println(WiFi.softAPIP()); display.println(); display.println(F("BOOT/BACK: stop")); display.setTextColor(1); display.display();
  if (btnPressed[BTN_BOOT] || btnPressed[BTN_BACK]) { srv.stop(); WiFi.softAPdisconnect(true); WiFi.mode(WIFI_OFF); mode = MODE_MENU; }
}

// ================= BIN VM =================
uint8_t* vm = nullptr; size_t vmLen = 0, vmPc = 0; uint16_t vmLoop = 0; int16_t vv[8]; bool vmErr = false; String vmMsg;
uint8_t vb() { if (vmPc >= vmLen) { vmErr = true; return 0; } return vm[vmPc++]; }
int16_t vi() { uint8_t l = vb(), h = vb(); return (int16_t)(l | (h << 8)); }
bool vmLoad() {
  if (!LittleFS.exists("/game.bin")) { vmMsg = "No game.bin"; return false; }
  File f = LittleFS.open("/game.bin", "r"); if (!f) { vmMsg = "Cannot open"; return false; }
  vmLen = f.size(); if (vmLen < 7) { vmMsg = "File too small"; f.close(); return false; }
  if (vm) { free(vm); vm = nullptr; } vm = (uint8_t*)(psramFound() ? ps_malloc(vmLen) : malloc(vmLen)); if (!vm) { vmMsg = "No memory"; f.close(); return false; }
  f.read(vm, vmLen); f.close(); if (memcmp(vm, "MGVM", 4)) { vmMsg = "Bad format"; return false; }
  vmLoop = vm[5] | (vm[6] << 8); vmPc = 7; for (int i = 0; i < 8; i++) vv[i] = 0; vmErr = false; return true;
}
void binPlayReset() { if (!vmLoad()) { display.clearDisplay(); display.setTextSize(1); display.setCursor(10, 20); display.print(F("No custom game!")); display.setCursor(5, 32); display.print(vmMsg); display.setCursor(5, 48); display.print(F("Use Bin: Upload")); display.display(); delay(2000); mode = MODE_MENU; } }
void binPlayUpdate() {
  if (checkExitToMenu()) return; if (!vm || vmErr) { lastScore = 0; mode = MODE_GAMEOVER; return; }
  bool y = false;
  while (!y && !vmErr) { uint8_t op = vb();
    switch (op) {
      case 0x00: break; case 0x01: display.clearDisplay(); break; case 0x02: display.display(); y = true; break;
      case 0x03: { int x = vb(), yy = vb(), w = vb(), h = vb(), fl = vb(); if (fl) display.fillRect(x, yy, w, h, 1); else display.drawRect(x, yy, w, h, 1); } break;
      case 0x04: { int x = vb(), yy = vb(); display.drawPixel(x, yy, 1); } break;
      case 0x05: { int x = vb(), yy = vb(), n = vb(); char b[33]; if (n > 32) n = 32; for (int i = 0; i < n; i++) b[i] = vb(); b[n] = 0; display.setTextSize(1); display.setCursor(x, yy); display.print(b); } break;
      case 0x06: { int r = vb() & 7; vv[r] = vi(); } break; case 0x07: { int r = vb() & 7; vv[r] += vi(); } break;
      case 0x08: { int d = vb() & 7, s = vb() & 7; vv[d] = vv[s]; } break;
      case 0x09: { int rx = vb() & 7, ry = vb() & 7, w = vb(), h = vb(), fl = vb(); if (fl) display.fillRect(vv[rx], vv[ry], w, h, 1); else display.drawRect(vv[rx], vv[ry], w, h, 1); } break;
      case 0x0A: { uint8_t b = vb(); uint16_t a = vi(); if (b < 5 && isHeld(b)) vmPc = a; } break;
      case 0x0B: { int r = vb() & 7; int16_t v = vi(); uint16_t a = vi(); if (vv[r] < v) vmPc = a; } break;
      case 0x0C: { int r = vb() & 7; int16_t v = vi(); uint16_t a = vi(); if (vv[r] > v) vmPc = a; } break;
      case 0x0D: { uint16_t a = vi(); vmPc = a; } break; case 0x0E: { uint8_t ms = vb(); delay(ms); } break;
      case 0x0F: vmPc = vmLoop; break; case 0xFF: mode = MODE_MENU; y = true; break; default: vmErr = true; break; } }
  if (vmErr) { lastScore = 0; mode = MODE_GAMEOVER; }
}

// ================= MAIN =================
void startGame(int i) {
  currentGame = i; mode = MODE_GAME;
  switch (i) { case 0: flappyReset(); break; case 1: snakeReset(); break; case 2: pongReset(); break; case 3: dinoReset(); break; case 4: tetrisReset(); break; case 5: siReset(); break;
    case 6: brReset(); break; case 7: pmReset(); break; case 8: mhReset(); break; case 9: bdReset(); break; case 10: fpsReset(); break; case 11: customReset(); break;
    case 12: binServerStart(); return; case 13: binPlayReset(); break; case 14: galleryReset(); break; case 15: benchReset(); break; case 16: dmReset(); break; }
}
void setup() {
  Serial.begin(115200); pinsInit(); pinMode(PIN_BAT, INPUT);
  bool ok = false; for (int i = 0; i < 3 && !ok; i++) { ok = display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR); if (!ok) delay(200); } if (!ok) for (;;);
  display.setTextColor(1); display.clearDisplay(); display.display();
  if (!LittleFS.begin(true)) Serial.println(F("LittleFS mount failed"));
  loadSettings(); initPsramMap(); randomSeed(analogRead(1));
  if (digitalRead(PIN_BACK) == LOW) { batEn = false; saveSettings(); }
  if (batEn) { float v = 0; for (int i = 0; i < 3; i++) { v += readBatV(); delay(30); } v /= 3; batV = v; batRaw = rawPct(v); if (batRaw <= 10) batShutdown(); }
  splashStart = millis();
}
void loop() {
  static unsigned long lastFrameUs = 0;
  updateButtons();
  if (shotIdx < 3 && comboHit(shotC[shotIdx])) { btnPressed[shotC[shotIdx].a] = btnPressed[shotC[shotIdx].b] = false; captureScreenshot(); }
  if (recIdx < 3 && comboHit(recC[recIdx])) { btnPressed[recC[recIdx].a] = btnPressed[recC[recIdx].b] = false; vidToggle(); }
  batTick();
  if (mode != MODE_GAME && dm_inv) { display.invertDisplay(false); dm_inv = false; }
  switch (mode) {
    case MODE_SPLASH: updateSplash(); break; case MODE_MENU: updateMenu(); break; case MODE_SETTINGS: updateSettings(); break;
    case MODE_CONFIRM: updateConfirm(); break; case MODE_FORMAT_CONFIRM: updateFormatConfirm(); break;
    case MODE_GAME:
      switch (currentGame) {
        case 0: flappyUpdate(); if (mode == MODE_GAME) flappyDraw(); break; case 1: snakeUpdate(); if (mode == MODE_GAME) snakeDraw(); break;
        case 2: pongUpdate(); if (mode == MODE_GAME) pongDraw(); break; case 3: dinoUpdate(); if (mode == MODE_GAME) dinoDraw(); break;
        case 4: tetrisUpdate(); if (mode == MODE_GAME) tetrisDraw(); break; case 5: siUpdate(); if (mode == MODE_GAME) siDraw(); break;
        case 6: brUpdate(); if (mode == MODE_GAME) brDraw(); break; case 7: pmUpdate(); if (mode == MODE_GAME) pmDraw(); break;
        case 8: mhUpdate(); if (mode == MODE_GAME) mhDraw(); break; case 9: bdUpdate(); if (mode == MODE_GAME) bdDraw(); break;
        case 10: fpsUpdate(); if (mode == MODE_GAME) fpsDraw(); break; case 11: customUpdate(); if (mode == MODE_GAME) customDraw(); break;
        case 13: binPlayUpdate(); break; case 14: galleryUpdate(); if (mode == MODE_GAME) galleryDraw(); break;
        case 15: benchUpdate(); if (mode == MODE_GAME) benchDraw(); break; case 16: dmUpdate(); if (mode == MODE_GAME) dmDraw(); break; }
      break;
    case MODE_BIN_SERVER: updateBinServer(); break; case MODE_OTA_PREPARE: updateOtaPrepare(); break; case MODE_OTA_UPDATING: updateOtaUpdating(); break;
    case MODE_GAMEOVER: updateGameOver(); break;
  }
  vidTick();
  if (mode != MODE_OTA_PREPARE && mode != MODE_OTA_UPDATING) drawOverlays();
  if (fpsVal[fpsIdx] && mode != MODE_BIN_SERVER && mode != MODE_OTA_PREPARE && mode != MODE_OTA_UPDATING) {   // ограничение FPS
    unsigned long gap = 1000000UL / fpsVal[fpsIdx];
    while (micros() - lastFrameUs < gap) delayMicroseconds(200);
  }
  lastFrameUs = micros();
}