// pins.cpp — распиновка проекта MiniGame (ESP32-S3 N16R8)
//
// | Устройство  | GPIO | Примечание                        |
// |-------------|------|-----------------------------------|
// | OLED SDA    | 20   | I2C                               |
// | OLED SCL    | 21   | I2C                               |
// | UP          | 18   | кнопка на GND                     |
// | DOWN        | 10   | кнопка на GND                     |
// | LEFT        | 15   | кнопка на GND                     |
// | RIGHT       | 12   | кнопка на GND                     |
// | SELECT      | 2    | кнопка на GND (strapping-пин)     |
// | BOOT        | 0    | кнопка на плате                   |
// | BACK        | 40   | кнопка на GND                     |
//
// Питание OLED: 3.3V / GND. При длинных проводах I2C (>15 см)
// добавьте подтяжки 4.7 кОм от SDA и SCL к 3.3V.

#include "pins.h"
#include <Wire.h>

void pinsInit() {
  pinMode(PIN_UP,     INPUT_PULLUP);
  pinMode(PIN_DOWN,   INPUT_PULLUP);
  pinMode(PIN_LEFT,   INPUT_PULLUP);
  pinMode(PIN_RIGHT,  INPUT_PULLUP);
  pinMode(PIN_SELECT, INPUT_PULLUP);
  pinMode(PIN_BOOT,   INPUT_PULLUP);
  pinMode(PIN_BACK,   INPUT_PULLUP);

  Wire.begin(PIN_SDA, PIN_SCL);
  Wire.setClock(400000);
}